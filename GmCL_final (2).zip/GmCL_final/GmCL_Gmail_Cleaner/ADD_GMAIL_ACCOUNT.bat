@echo off
setlocal EnableExtensions
pushd "%~dp0"
if errorlevel 1 exit /b 1
title Connect Gmail to GmCL

set "GMCL_PYTHON=%LOCALAPPDATA%\GmCL\Runtime\venv\Scripts\python.exe"
if not exist "%GMCL_PYTHON%" (
  echo GmCL is not set up yet. Running the one-time setup first...
  call "%~dp0ONE_CLICK_START.bat"
  if errorlevel 1 exit /b 2
)

set "PERSISTENT_OAUTH=%LOCALAPPDATA%\GmCL\ServerData\oauth\client_secret.json"
if not exist "config\client_secret.json" if exist "%PERSISTENT_OAUTH%" (
  copy /Y "%PERSISTENT_OAUTH%" "config\client_secret.json" >nul
)
if not exist "config\client_secret.json" if not exist "%PERSISTENT_OAUTH%" (
  echo Missing Google Desktop OAuth JSON.
  echo Run ONE_CLICK_START.bat and place the downloaded client_secret JSON in Downloads.
  start "" notepad.exe "%~dp0README_FIRST.txt"
  pause
  exit /b 2
)

"%GMCL_PYTHON%" "%~dp0add_account.py"
set "ADD_RESULT=%errorlevel%"
pause
exit /b %ADD_RESULT%
