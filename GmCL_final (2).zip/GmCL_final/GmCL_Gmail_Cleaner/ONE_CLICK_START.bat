@echo off
setlocal EnableExtensions
title GmCL - Smart Setup
pushd "%~dp0" >nul 2>nul
if errorlevel 1 (
  echo ERROR: Could not open the package folder.
  echo Extract the ZIP to a local folder and run this file again.
  pause
  exit /b 1
)
set "CLEANER_ROOT=%CD%"
if not exist "%CLEANER_ROOT%\launcher\Smart-Setup.ps1" (
  echo ERROR: launcher\Smart-Setup.ps1 is missing.
  echo Extract the complete ZIP, not individual files.
  popd
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%CLEANER_ROOT%\launcher\Smart-Setup.ps1"
set "SETUP_RESULT=%errorlevel%"
popd
if "%SETUP_RESULT%"=="0" exit /b 0
if "%SETUP_RESULT%"=="2" (
  echo.
  echo Only the Google OAuth credential step remains.
  echo After downloading the Desktop OAuth JSON, run ONE_CLICK_START.bat again.
  pause
  exit /b 2
)
echo.
echo Setup stopped. Review the error shown above.
pause
exit /b %SETUP_RESULT%
