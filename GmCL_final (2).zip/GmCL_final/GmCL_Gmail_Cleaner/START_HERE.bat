@echo off
setlocal
pushd "%~dp0"
if errorlevel 1 exit /b 1
title GmCL
:menu
cls
echo ==========================================================
echo       GmCL - SERVER READY
echo ==========================================================
echo.
echo  1. One-click smart setup and start
echo  2. Start dashboard on this PC
echo  3. Connect another Gmail
echo  4. Install automatic start at Windows sign-in
echo  5. Stop server
echo  6. Read instructions
echo  7. Run system tests
echo  8. Show / recreate client access link
echo  9. MAKE THIS PC THE SERVER (first time)
echo  0. Exit
echo.
choice /c 1234567890 /n /m "Choose 0-9: "
if errorlevel 10 goto option0
if errorlevel 9 goto option9
if errorlevel 8 goto option8
if errorlevel 7 goto option7
if errorlevel 6 goto option6
if errorlevel 5 goto option5
if errorlevel 4 goto option4
if errorlevel 3 goto option3
if errorlevel 2 goto option2
if errorlevel 1 goto option1
goto menu
:option1
call "%~dp0ONE_CLICK_START.bat"
goto menu
:option2
call "%~dp0START_DASHBOARD.bat"
goto menu
:option3
call "%~dp0ADD_GMAIL_ACCOUNT.bat"
goto menu
:option4
call "%~dp0INSTALL_AUTO_START.bat"
goto menu
:option5
call "%~dp0STOP_LOCAL_SERVER.bat"
goto menu
:option6
start "" notepad.exe "%~dp0README_FIRST.txt"
goto menu
:option7
call "%~dp0RUN_TESTS.bat"
goto menu
:option8
call "%~dp0SHOW_CLIENT_LINK.bat"
goto menu
:option9
call "%~dp0MAKE_THIS_PC_SERVER.bat"
goto menu
:option0
exit /b 0
