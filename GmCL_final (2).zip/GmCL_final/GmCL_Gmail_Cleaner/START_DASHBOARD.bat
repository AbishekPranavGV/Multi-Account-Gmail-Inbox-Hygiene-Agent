@echo off
setlocal EnableExtensions
pushd "%~dp0" >nul 2>nul
if errorlevel 1 exit /b 1
set "GMCL_PYTHON=%LOCALAPPDATA%\GmCL\Runtime\venv\Scripts\python.exe"
if not exist "%GMCL_PYTHON%" (
  call "%~dp0ONE_CLICK_START.bat"
  exit /b %errorlevel%
)
for /f "usebackq delims=" %%V in ("%~dp0VERSION.txt") do set "GMCL_EXPECTED=%%V"
powershell.exe -NoProfile -Command "$expected='%GMCL_EXPECTED%'; try { $raw=Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:8795/api/state?startup_probe=1' -TimeoutSec 1; $r=$raw.Content|ConvertFrom-Json; if([string]$r.version -eq $expected){exit 0}else{exit 2} } catch { exit 1 }"
if not errorlevel 1 (
  start "" "http://127.0.0.1:8795/?ui=%GMCL_EXPECTED%"
  popd
  exit /b 0
)
rem Missing or older server: Smart-Setup starts/restarts the exact package version.
call "%~dp0ONE_CLICK_START.bat"
set "RESULT=%errorlevel%"
popd
exit /b %RESULT%
