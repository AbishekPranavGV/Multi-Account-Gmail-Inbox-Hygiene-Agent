@echo off
setlocal
pushd "%~dp0"
if errorlevel 1 exit /b 1
title GmCL - Remove Client Network Access
powershell.exe -NoProfile -Command "$p=New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent()); if($p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){exit 0}else{exit 1}" >nul 2>&1
if errorlevel 1 (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b 0
)
netsh advfirewall firewall delete rule name="GmCL Server" >nul 2>nul
netsh advfirewall firewall delete rule name="VelocityX Gmail Cleaner Server" >nul 2>nul
if exist "%LOCALAPPDATA%\GmCL\ServerData\server_mode.enabled" del /q "%LOCALAPPDATA%\GmCL\ServerData\server_mode.enabled" >nul 2>nul
echo GmCL client network access disabled.
echo Restart GmCL to return to localhost-only mode at http://127.0.0.1:8795
echo.
pause
exit /b 0
