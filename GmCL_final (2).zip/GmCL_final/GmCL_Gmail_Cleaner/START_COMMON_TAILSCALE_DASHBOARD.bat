@echo off
setlocal EnableExtensions
pushd "%~dp0" >nul 2>nul
if errorlevel 1 (
  echo ERROR: Could not open the GmCL Common folder.
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0launcher\Open-Shared-Command-Center.ps1"
set "RC=%errorlevel%"
popd
if not "%RC%"=="0" pause
exit /b %RC%
