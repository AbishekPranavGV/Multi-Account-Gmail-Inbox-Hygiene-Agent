@echo off
setlocal
pushd "%~dp0"
if errorlevel 1 exit /b 1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0launcher\Create-Client-Links.ps1"
if errorlevel 1 (
  echo Could not create the client link.
  pause
  exit /b 1
)
echo.
type "%~dp0URL.txt"
echo.
pause
exit /b 0
