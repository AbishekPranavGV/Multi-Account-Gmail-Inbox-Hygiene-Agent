@echo off
setlocal EnableExtensions
title Remove GmCL Auto Start
choice /c YN /n /m "Remove GmCL automatic start for this Windows user? [Y/N]: "
if errorlevel 2 exit /b 0

set "GMCL_RUNTIME=%LOCALAPPDATA%\GmCL\Runtime"
set "GMCL_STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
del /Q "%GMCL_STARTUP%\GmCL_AutoStart.cmd" >nul 2>nul
del /Q "%GMCL_RUNTIME%\AutoStart-Runner.ps1" >nul 2>nul
del /Q "%GMCL_RUNTIME%\autostart_root.txt" >nul 2>nul

rem Remove older task-based installs when Windows allows it.
schtasks.exe /Delete /TN "GmCL" /F >nul 2>nul
schtasks.exe /Delete /TN "VelocityX Gmail Multi Cleaner" /F >nul 2>nul

echo GmCL automatic start was removed for this Windows user.
echo Gmail accounts and cleaner data were not changed.
pause
exit /b 0
