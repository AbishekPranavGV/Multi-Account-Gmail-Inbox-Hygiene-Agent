import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from itsdangerous import URLSafeTimedSerializer
from app import store, web, scheduler, cleaner

class ClientPrivacyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        for target, values in [(store, dict(ACCOUNTS_FILE=root/'accounts.json', TOKEN_DIR=root/'tokens')),
                               (web, dict(ACTIVITY_FILE=root/'activity.jsonl', NETWORK_ACCESS_KEY_FILE=root/'key', SESSION_SECRET_FILE=root/'secret'))]:
            p = patch.multiple(target, **values); p.start(); self.addCleanup(p.stop)
        store.upsert_account('one@example.com')
        store.upsert_account('two@example.com')
        web._write_activity('one@example.com','ONE','OK','own')
        web._write_activity('two@example.com','TWO','OK','private')
        self.app = web.create_app()
        self.client = self.app.test_client()
        self.remote = {'REMOTE_ADDR':'192.168.1.50'}
        self.signer = URLSafeTimedSerializer(self.app.secret_key, salt='gmcl-account-dashboard-v2')

    def login(self):
        token = self.signer.dumps({'email':'one@example.com'})
        response = self.client.get('/?account_access='+token, environ_base=self.remote)
        self.assertEqual(response.status_code,302)
        return self.client.get('/api/state',environ_base=self.remote).get_json()

    def test_client_only_sees_own_account_and_activity(self):
        state = self.login()
        self.assertEqual([a['email'] for a in state['accounts']],['one@example.com'])
        self.assertEqual([a['email'] for a in state['activity']],['one@example.com'])
        self.assertTrue(state['client_mode'])

    def test_cross_account_actions_denied_before_execution(self):
        state = self.login()
        for endpoint, method in [('/api/accounts/clean','POST'),('/api/accounts/scan','POST'),('/api/accounts/settings','POST'),('/api/accounts/start','POST'),('/api/accounts/stop','POST'),('/api/accounts/remove','DELETE'),('/api/candidates/trash','POST'),('/api/candidates/not-spam','POST'),('/api/candidates/permanent','POST'),('/api/purge','POST')]:
            result = self.client.open(endpoint,method=method,json={'email':'two@example.com'},headers={'X-CSRF-Token':state['csrf']},environ_base=self.remote)
            self.assertEqual(result.status_code,403,endpoint)
        self.assertEqual(self.client.get('/api/candidates?email=two@example.com',environ_base=self.remote).status_code,403)

    def test_client_scan_all_is_scoped(self):
        state = self.login()
        with patch.object(web,'scan_account',return_value={'counts':{}}) as scan:
            response=self.client.post('/api/accounts/scan-all',json={},headers={'X-CSRF-Token':state['csrf']},environ_base=self.remote)
            self.assertEqual(response.status_code,200)
            scan.assert_called_once_with('one@example.com')

    def test_old_shared_sessions_and_links_denied(self):
        with self.client.session_transaction() as session: session['network_access']=True
        self.assertEqual(self.client.get('/api/state',environ_base=self.remote).status_code,403)
        self.assertEqual(self.client.get('/?access='+web.NETWORK_ACCESS_KEY_FILE.read_text(),environ_base=self.remote).status_code,403)

    def test_forged_and_expired_grants_denied(self):
        self.assertEqual(self.client.get('/?account_access=forged',environ_base=self.remote).status_code,403)
        with patch('time.time',return_value=1): token=self.signer.dumps({'email':'one@example.com'})
        self.assertEqual(self.client.get('/?account_access='+token,environ_base=self.remote).status_code,403)

    def test_saved_client_resume_refreshes_dashboard_grant(self):
        key = web.NETWORK_ACCESS_KEY_FILE.read_text(encoding='ascii').strip()
        resume_signer = URLSafeTimedSerializer(self.app.secret_key, salt='gmcl-client-resume-v1')
        resume = resume_signer.dumps({'email':'one@example.com'})
        response = self.client.post('/api/client/resume', json={'resume_token':resume},
                                    headers={'X-GmCL-Access-Key':key}, environ_base=self.remote)
        self.assertEqual(response.status_code,200)
        fresh = response.get_json()['account_access']
        self.assertEqual(self.client.get('/?account_access='+fresh,environ_base=self.remote).status_code,302)

    def test_forged_saved_client_resume_denied(self):
        key = web.NETWORK_ACCESS_KEY_FILE.read_text(encoding='ascii').strip()
        response = self.client.post('/api/client/resume', json={'resume_token':'forged'},
                                    headers={'X-GmCL-Access-Key':key}, environ_base=self.remote)
        self.assertEqual(response.status_code,403)

    def test_common_tailscale_command_center_sees_all_accounts_and_activity(self):
        key = web.NETWORK_ACCESS_KEY_FILE.read_text(encoding='ascii').strip()
        response = self.client.get('/?command_access=' + key, environ_base=self.remote)
        self.assertEqual(response.status_code, 302)
        state = self.client.get('/api/state', environ_base=self.remote).get_json()
        self.assertEqual([a['email'] for a in state['accounts']], ['one@example.com', 'two@example.com'])
        self.assertEqual({a['email'] for a in state['activity']}, {'one@example.com', 'two@example.com'})
        self.assertTrue(state['client_mode'])
        self.assertTrue(state['shared_command_center'])

    def test_common_tailscale_command_center_can_manage_selected_central_account(self):
        key = web.NETWORK_ACCESS_KEY_FILE.read_text(encoding='ascii').strip()
        self.assertEqual(self.client.get('/?command_access=' + key, environ_base=self.remote).status_code, 302)
        state = self.client.get('/api/state', environ_base=self.remote).get_json()
        response = self.client.post(
            '/api/accounts/settings',
            json={
                'email': 'two@example.com', 'enabled': True, 'business_guard_enabled': False,
                'min_age_days': 7, 'protect_starred': True, 'protect_important': True,
                'max_per_run': 2000, 'every_hours': 1, 'schedule_mode': 'end_of_day',
                'end_of_day_time': '23:00', 'auto_purge_trash': False, 'trash_age_days': 30,
            },
            headers={'X-CSRF-Token': state['csrf']}, environ_base=self.remote,
        )
        self.assertEqual(response.status_code, 200)
        saved = store.get_account('two@example.com')['settings']
        self.assertTrue(saved['enabled'])
        self.assertEqual(saved['schedule_mode'], 'end_of_day')

    def test_invalid_common_tailscale_access_key_is_denied(self):
        response = self.client.get('/?command_access=wrong-key', environ_base=self.remote)
        self.assertEqual(response.status_code, 403)

    def test_local_admin_sees_all_accounts(self):
        state=self.client.get('/api/state').get_json()
        self.assertEqual(len(state['accounts']),2)
        self.assertFalse(state['client_mode'])
        self.assertFalse(state['shared_command_center'])

    def test_stopped_scheduler_does_not_purge(self):
        worker=scheduler.CleanupScheduler()
        account={'email':'one@example.com','settings':{'enabled':True,'auto_purge_trash':True}}
        def stopped(*args):
            worker.stop()
            return {'status':'STOPPED'}
        with patch.object(scheduler,'list_accounts',return_value=[account]), patch.object(scheduler,'clean_promotions_social',side_effect=stopped), patch.object(scheduler,'permanently_delete') as purge:
            worker._loop()
            purge.assert_not_called()

    def test_cancelled_permanent_delete_writes_nothing(self):
        import threading
        from test_system import FakeGmail
        cancel=threading.Event(); cancel.set()
        fake=FakeGmail([], 'one@example.com')
        with patch.object(cleaner,'services_for',return_value=(fake,None)), patch.object(cleaner,'_parallel_message_gets') as fetch:
            result=cleaner.permanently_delete('one@example.com','trash',cleaner.permanent_phrase('one@example.com'),selected_ids=['a'],cancel=cancel)
            self.assertEqual(result['status'],'STOPPED')
            self.assertEqual(result['deleted'],0)
            fetch.assert_not_called()
