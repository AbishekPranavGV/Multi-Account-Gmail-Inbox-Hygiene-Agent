@echo off
setlocal EnableExtensions
pushd "%~dp0" >nul 2>nul
if errorlevel 1 exit /b 1
powershell.exe -NoProfile -Command "$pidFile=Join-Path $env:LOCALAPPDATA 'GmCL\ServerData\server.pid'; if(!(Test-Path -LiteralPath $pidFile)){Write-Host 'GmCL server is not running.'; exit 0}; try{$serverPid=[int](Get-Content -LiteralPath $pidFile -Raw)}catch{Write-Host 'Invalid GmCL PID file.'; exit 1}; $p=Get-CimInstance Win32_Process -Filter ('ProcessId='+$serverPid) -ErrorAction SilentlyContinue; if($null -eq $p){Remove-Item -LiteralPath $pidFile -Force -ErrorAction SilentlyContinue; Remove-Item -LiteralPath (Join-Path $env:LOCALAPPDATA 'GmCL\ServerData\server.lock') -Force -ErrorAction SilentlyContinue; Write-Host 'Stale GmCL PID file removed.'; exit 0}; if(([string]$p.CommandLine) -notmatch '(?i)app\.py'){Write-Host 'Safety check failed: PID is not a GmCL Python app.'; exit 1}; Stop-Process -Id $serverPid -Force; Remove-Item -LiteralPath $pidFile -Force -ErrorAction SilentlyContinue; Remove-Item -LiteralPath (Join-Path $env:LOCALAPPDATA 'GmCL\ServerData\server.lock') -Force -ErrorAction SilentlyContinue; Write-Host 'GmCL local server stopped.'"
set "STOP_RESULT=%errorlevel%"
popd
if "%STOP_RESULT%"=="0" exit /b 0
echo.
echo Could not stop the GmCL server.
pause
exit /b %STOP_RESULT%
