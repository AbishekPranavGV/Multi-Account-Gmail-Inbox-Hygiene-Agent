param([switch]$Connect)
$ErrorActionPreference = 'Stop'
$source = $PSScriptRoot
$local = Join-Path $env:LOCALAPPDATA 'GmCL\Client'
New-Item -ItemType Directory -Path $local -Force | Out-Null
if ($source -ne $local) {
    foreach ($name in @('client_connect.py','client_config.json','client_secret.json','requirements-client.txt','Client-Setup.ps1','START_GMCL_CLIENT.bat','CONNECT_GMAIL.bat','CLIENT_CONNECT_GMAIL.bat')) {
        Copy-Item -LiteralPath (Join-Path $source $name) -Destination (Join-Path $local $name) -Force
    }
}
try {
    $python = $null
    foreach ($path in @(
        (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312\python.exe'),
        (Join-Path $env:ProgramFiles 'Python312\python.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python311\python.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python310\python.exe')
    )) {
        if (Test-Path -LiteralPath $path) { $python = $path; break }
    }
    if (-not $python) {
        try { $python = & py.exe -3.12 -c 'import sys; print(sys.executable)' 2>$null } catch {}
    }
    if (-not $python) {
        try { $python = & py.exe -3 -c 'import sys; assert sys.version_info >= (3,10); print(sys.executable)' 2>$null } catch {}
    }
    if (-not $python) {
        try { $python = & python.exe -c 'import sys; assert sys.version_info >= (3,10); print(sys.executable)' 2>$null } catch {}
    }
    if (-not $python) {
        Write-Host 'Installing Python 3.12 for this Windows user...'
        & winget.exe install --id Python.Python.3.12 --exact --scope user --silent --accept-package-agreements --accept-source-agreements
        if ($LASTEXITCODE -ne 0) { throw 'Python installation failed. Install Python 3.12 and retry.' }
        $python = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312\python.exe'
    }
    $venv = Join-Path $local '.client_venv'
    $exe = Join-Path $venv 'Scripts\python.exe'
    if (-not (Test-Path -LiteralPath $exe)) {
        & $python -m venv $venv
        if ($LASTEXITCODE -ne 0) { throw 'Could not create the client environment.' }
    }
    & $exe -c "import importlib.util,sys; sys.exit(0 if all(importlib.util.find_spec(n) is not None for n in ('google_auth_oauthlib','requests','cryptography')) else 1)"
    if ($LASTEXITCODE -ne 0) {
        & $exe -m pip install --disable-pip-version-check --prefer-binary --only-binary=:all: -r (Join-Path $local 'requirements-client.txt')
        if ($LASTEXITCODE -ne 0) {
            & $exe -m pip install --disable-pip-version-check --prefer-binary -r (Join-Path $local 'requirements-client.txt')
        }
        if ($LASTEXITCODE -ne 0) { throw 'Package installation failed. Check Internet access and retry.' }
    }
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'GmCL Client.lnk'))
    $shortcut.TargetPath = Join-Path $local 'START_GMCL_CLIENT.bat'
    $shortcut.WorkingDirectory = $local
    $shortcut.Save()
    $argsForClient = @((Join-Path $local 'client_connect.py'))
    if ($Connect) { $argsForClient += '--connect' }
    & $exe @argsForClient
    exit $LASTEXITCODE
} catch {
    Write-Host ('ERROR: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
