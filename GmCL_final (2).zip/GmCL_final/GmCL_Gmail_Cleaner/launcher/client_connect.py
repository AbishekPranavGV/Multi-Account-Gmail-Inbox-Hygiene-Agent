from __future__ import annotations

import json
import sys
import base64
import hashlib
import os
import time
import webbrowser
from pathlib import Path

import requests
from google_auth_oauthlib.flow import InstalledAppFlow
from cryptography.fernet import Fernet

ROOT = Path(__file__).resolve().parent
SCOPES = [
    "https://mail.google.com/",
    "https://www.googleapis.com/auth/drive.metadata.readonly",
]




def load_desktop_oauth_config(path: Path) -> dict:
    """Validate Desktop OAuth JSON before Google receives the request."""
    try:
        raw = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError("Google OAuth file is missing or invalid. Use a Google OAuth Client ID with Application type: Desktop app.") from exc
    installed = raw.get("installed")
    if not isinstance(installed, dict):
        kind = "Web application" if isinstance(raw.get("web"), dict) else "non-Desktop"
        raise RuntimeError(f"Wrong Google OAuth credential type ({kind}). Download a Desktop app OAuth JSON.")
    client_id = str(installed.get("client_id") or "").strip()
    client_secret = str(installed.get("client_secret") or "").strip()
    if not client_id.endswith(".apps.googleusercontent.com") or not client_secret:
        raise RuntimeError("Google Desktop OAuth JSON is incomplete. Download a fresh Desktop app OAuth JSON.")
    return {"installed": {
        "client_id": client_id,
        "project_id": str(installed.get("project_id") or "gmcl-desktop"),
        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
        "token_uri": "https://oauth2.googleapis.com/token",
        "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
        "client_secret": client_secret,
        "redirect_uris": ["http://localhost"],
    }}


def discover_server(config: dict, key: str) -> str:
    candidates = config.get("server_candidates") or []
    candidates = [config.get("server_url"), *candidates]
    seen: set[str] = set()
    for value in candidates:
        server = str(value or "").rstrip("/")
        if not server or server in seen:
            continue
        seen.add(server)
        try:
            response = requests.get(
                server + "/api/client/ping",
                headers={"X-GmCL-Access-Key": key}, timeout=3,
            )
            data = response.json()
            if response.ok and data.get("service") == "GmCL":
                return server
        except (requests.RequestException, ValueError):
            continue
    raise RuntimeError(
        "Main GmCL server was not found. On the server PC run MAKE_THIS_PC_SERVER.bat, "
        "then copy the newly generated client application again."
    )


def preferred_browser() -> str | None:
    candidates = [
        Path(os.environ.get("PROGRAMFILES", "")) / "Google/Chrome/Application/chrome.exe",
        Path(os.environ.get("PROGRAMFILES(X86)", "")) / "Google/Chrome/Application/chrome.exe",
        Path(os.environ.get("LOCALAPPDATA", "")) / "Google/Chrome/Application/chrome.exe",
    ]
    for path in candidates:
        if path.is_file():
            webbrowser.register("gmcl-chrome", None, webbrowser.BackgroundBrowser(str(path)))
            return "gmcl-chrome"
    return None


def main() -> int:
    try:
        config = json.loads((ROOT / "client_config.json").read_text(encoding="utf-8-sig"))
        key = str(config["access_key"])
        print("Finding the main GmCL server...")
        server = discover_server(config, key)
        print("Connected to:", server)
        state_root = Path(os.environ.get("LOCALAPPDATA", str(ROOT))) / "GmCL" / "ClientState"
        state_root.mkdir(parents=True, exist_ok=True)
        session_file = state_root / "dashboard_session.json"
        legacy_session_file = ROOT / "dashboard_session.json"
        if not session_file.exists() and legacy_session_file.exists():
            try:
                session_file.write_text(legacy_session_file.read_text(encoding="utf-8"), encoding="utf-8")
            except OSError:
                pass
        if "--connect" not in sys.argv and session_file.exists():
            try:
                saved = json.loads(session_file.read_text(encoding="utf-8"))
                resume_payload = {}
                if str(saved.get("resume_token", "")).strip():
                    resume_payload["resume_token"] = str(saved["resume_token"]).strip()
                elif str(saved.get("account_access", "")).strip():
                    # Upgrade existing v1.6.0/v1.6.1 saved sessions without Google login.
                    resume_payload["account_access"] = str(saved["account_access"]).strip()
                if resume_payload:
                    response = requests.post(
                        server + "/api/client/resume",
                        headers={"X-GmCL-Access-Key": key, "Content-Type": "application/json"},
                        json=resume_payload, timeout=20,
                    )
                    try:
                        data = response.json()
                    except ValueError:
                        data = {}
                    if response.ok and data.get("ok") and data.get("account_access"):
                        session_file.write_text(json.dumps({
                            "account_access": data["account_access"],
                            "resume_token": data.get("resume_token", ""),
                            "email": data.get("email", saved.get("email", "")),
                            "updated": time.time(),
                        }), encoding="utf-8")
                        url = server + "/?account_access=" + data["account_access"]
                        webbrowser.open(url)
                        print("Opened your saved Gmail dashboard. No Google login was needed.")
                        return 0
                    if response.status_code != 403:
                        # A temporary server problem must never force the user through
                        # Google OAuth again. Keep the saved session and retry later.
                        raise RuntimeError(data.get("error") or f"Server returned HTTP {response.status_code} while restoring saved login.")
                    print("This PC's saved dashboard grant is no longer valid. A one-time reconnect is required; the server's saved Gmail data is preserved.")
            except (OSError, ValueError, KeyError, requests.RequestException) as exc:
                raise RuntimeError(f"Could not restore the saved GmCL login: {exc}. Try START_GMCL_CLIENT.bat again; Google login was not cleared.") from exc
        print("Choose your Gmail and approve access once. The main server administrator will manage this account.")
        flow = InstalledAppFlow.from_client_config(load_desktop_oauth_config(ROOT / "client_secret.json"), SCOPES)
        oauth_prompt = "consent" if "--connect" in sys.argv else "select_account"
        credentials = flow.run_local_server(
            host="127.0.0.1", port=0, open_browser=True, prompt=oauth_prompt,
            access_type="offline", timeout_seconds=600,
            # Do not force a separate Chrome process/profile. The normal Windows
            # default browser is more likely to already have the user's Google
            # account signed in and avoids unnecessary password prompts.
            authorization_prompt_message="Opening Google sign-in in your normal browser. Choose this Gmail account once.",
            success_message="Authorization complete and being saved. Return to the GmCL client application.",
        )
        fernet_key = base64.urlsafe_b64encode(hashlib.sha256(key.encode("ascii")).digest())
        encrypted_token = Fernet(fernet_key).encrypt(credentials.to_json().encode("utf-8")).decode("ascii")
        response = None
        for attempt in range(3):
            try:
                response = requests.post(
                    server + "/api/client/register",
                    headers={"X-GmCL-Access-Key": key, "Content-Type": "application/json"},
                    json={"encrypted_token": encrypted_token}, timeout=45,
                )
                break
            except requests.RequestException:
                if attempt == 2:
                    raise
                time.sleep(1)
        assert response is not None
        data = response.json()
        if not response.ok or not data.get("ok"):
            raise RuntimeError(data.get("error") or f"Server returned HTTP {response.status_code}")
        print("\nSUCCESS:", data.get("message"))
        print("Gmail:", data.get("email"))
        session_file.write_text(json.dumps({"account_access": data["account_access"], "resume_token": data.get("resume_token", ""), "email": data.get("email", ""), "created": time.time()}), encoding="utf-8")
        webbrowser.open(server + "/?account_access=" + data["account_access"])
        return 0
    except Exception as exc:
        print(f"\nFAILED: {exc}", file=sys.stderr)
        print(
            "Saved GmCL/Gmail authorizations were not deleted. Confirm the server is ON and both PCs are on the same office network. "
            "If the Google page itself says 'Something went wrong', close that tab, sign in normally at gmail.com in the default browser, "
            "then run CONNECT_GMAIL.bat once.",
            file=sys.stderr,
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
