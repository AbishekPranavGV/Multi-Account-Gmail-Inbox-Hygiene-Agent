from __future__ import annotations

import sys
from importlib.metadata import PackageNotFoundError, version

REQUIRED = {
    "Flask": "3.1.3",
    "waitress": "3.0.2",
    "google-api-python-client": "2.200.0",
    "google-auth": "2.57.1",
    "google-auth-oauthlib": "1.4.1",
}


def main() -> int:
    mismatches: list[str] = []
    try:
        from cryptography.fernet import Fernet
    except ImportError:
        mismatches.append("cryptography: missing")
    for package, expected in REQUIRED.items():
        try:
            installed = version(package)
        except PackageNotFoundError:
            mismatches.append(f"{package}: missing (need {expected})")
            continue
        if installed != expected:
            mismatches.append(f"{package}: {installed} (need {expected})")

    if mismatches:
        for item in mismatches:
            print(item)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
