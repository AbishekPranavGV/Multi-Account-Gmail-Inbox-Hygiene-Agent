@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Client-Setup.ps1"
if errorlevel 1 pause
