[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$DataDir = if ($env:GMCL_DATA_DIR) { $env:GMCL_DATA_DIR } else { Join-Path $env:LOCALAPPDATA "GmCL\ServerData" }
$ConfigDir = Join-Path $Root "config"
$LogFile = Join-Path $DataDir "smart_setup.log"
$ClientSecret = Join-Path $ConfigDir "client_secret.json"
$PersistentClientSecret = Join-Path $DataDir "oauth\client_secret.json"
$PersistentOAuthDir = Split-Path -Parent $PersistentClientSecret
$RuntimeDir = if ($env:GMCL_RUNTIME_DIR) { $env:GMCL_RUNTIME_DIR } else { Join-Path $env:LOCALAPPDATA "GmCL\Runtime" }
New-Item -ItemType Directory -Path $PersistentOAuthDir -Force | Out-Null
New-Item -ItemType Directory -Path $RuntimeDir -Force | Out-Null

New-Item -ItemType Directory -Path $DataDir -Force | Out-Null
New-Item -ItemType Directory -Path $ConfigDir -Force | Out-Null

function Write-Step {
    param([string]$Message)
    $stamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$stamp] $Message"
    Add-Content -LiteralPath $LogFile -Value "[$stamp] $Message" -Encoding UTF8
}

function Get-PythonExecutable {
    $checks = @(
        @{ Command = "py.exe"; Arguments = @("-3.12", "-c", "import sys; print(sys.executable)") },
        @{ Command = "py.exe"; Arguments = @("-3", "-c", "import sys; assert sys.version_info >= (3,10); print(sys.executable)") },
        @{ Command = "python.exe"; Arguments = @("-c", "import sys; assert sys.version_info >= (3,10); print(sys.executable)") }
    )
    foreach ($check in $checks) {
        try {
            $command = $check.Command
            $checkArguments = $check.Arguments
            $result = & $command @checkArguments 2>$null | Select-Object -Last 1
            if ($LASTEXITCODE -eq 0 -and $result -and (Test-Path -LiteralPath $result.Trim())) {
                return $result.Trim()
            }
        } catch {
            continue
        }
    }
    $known = @(
        (Join-Path $env:ProgramFiles "Python312\python.exe"),
        (Join-Path $env:LOCALAPPDATA "Programs\Python\Python312\python.exe"),
        (Join-Path $env:LOCALAPPDATA "Programs\Python\Python311\python.exe"),
        (Join-Path $env:LOCALAPPDATA "Programs\Python\Python310\python.exe")
    )
    foreach ($path in $known) {
        if (Test-Path -LiteralPath $path) { return $path }
    }
    return $null
}

function Install-PythonIfNeeded {
    $python = Get-PythonExecutable
    if ($python) {
        Write-Step "Compatible Python found: $python"
        return $python
    }
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if (-not $winget) {
        Start-Process "https://www.python.org/downloads/windows/"
        throw "Python 3.10+ is missing and Windows Package Manager is unavailable. Install Python 3.12, then run this launcher again."
    }
    Write-Step "Python is missing. Installing Python 3.12 automatically with Windows Package Manager..."
    & $winget.Source install --id Python.Python.3.12 --exact --scope user --silent --accept-package-agreements --accept-source-agreements | Out-Host
    if ($LASTEXITCODE -ne 0) {
        throw "Automatic Python installation failed with code $LASTEXITCODE."
    }
    $python = Get-PythonExecutable
    if (-not $python) {
        throw "Python installation completed but python.exe was not detected. Restart Windows and run this launcher again."
    }
    Write-Step "Python installation completed: $python"
    return $python
}

function Get-LegacyVenv {
    # Fast upgrade path: reuse the already-installed v1.6/v1.7 runtime instead
    # of downloading and unpacking the same Google/Flask packages again.
    $candidateDirs = New-Object System.Collections.Generic.List[string]
    $localVenv = Join-Path $Root ".venv"
    if (Test-Path -LiteralPath (Join-Path $localVenv "Scripts\python.exe")) {
        $candidateDirs.Add($localVenv)
    }
    $downloads = Join-Path $env:USERPROFILE "Downloads"
    if (Test-Path -LiteralPath $downloads) {
        try {
            $packages = Get-ChildItem -LiteralPath $downloads -Directory -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -match "(?i)(GmCL|VelocityX)" } |
                Sort-Object LastWriteTime -Descending |
                Select-Object -First 12
            foreach ($package in $packages) {
                foreach ($relative in @("GmCL_Gmail_Cleaner\.venv", ".venv")) {
                    $candidate = Join-Path $package.FullName $relative
                    if (Test-Path -LiteralPath (Join-Path $candidate "Scripts\python.exe")) {
                        $candidateDirs.Add($candidate)
                    }
                }
            }
        } catch {}
    }
    foreach ($candidate in ($candidateDirs | Select-Object -Unique)) {
        try {
            $candidatePython = Join-Path $candidate "Scripts\python.exe"
            & $candidatePython -c "import sys; assert sys.version_info >= (3,10)" 2>$null
            if ($LASTEXITCODE -eq 0) { return $candidate }
        } catch {}
    }
    return $null
}

function Copy-LegacyVenvFast {
    param([string]$Source, [string]$Destination)
    if ([string]::IsNullOrWhiteSpace($Source)) { return $false }
    try {
        New-Item -ItemType Directory -Path $Destination -Force | Out-Null
        $null = & robocopy.exe $Source $Destination /E /NFL /NDL /NJH /NJS /NC /NS /NP
        if ($LASTEXITCODE -ge 8) { return $false }
        return (Test-Path -LiteralPath (Join-Path $Destination "Scripts\python.exe"))
    } catch {
        return $false
    }
}

function Test-DesktopOAuthJson {
    param([string]$Path)
    try {
        $json = Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json
        $clientId = [string]$json.installed.client_id
        $clientSecretValue = [string]$json.installed.client_secret
        return (
            $null -ne $json.installed -and
            $clientId -match "\.apps\.googleusercontent\.com$" -and
            $clientId -notmatch "PASTE|YOUR-" -and
            -not [string]::IsNullOrWhiteSpace($clientSecretValue) -and
            $clientSecretValue -notmatch "PASTE|YOUR-" -and
            -not [string]::IsNullOrWhiteSpace([string]$json.installed.token_uri)
        )
    } catch {
        return $false
    }
}

function Import-OAuthJsonIfAvailable {
    # A previously saved OAuth client always wins on normal upgrades. This keeps
    # every existing Gmail refresh token paired with the same Google client ID.
    if ((Test-Path -LiteralPath $PersistentClientSecret) -and (Test-DesktopOAuthJson $PersistentClientSecret)) {
        Copy-Item -LiteralPath $PersistentClientSecret -Destination $ClientSecret -Force
        Write-Step "Saved Google Desktop OAuth file restored from LocalAppData."
        return $true
    }
    if ((Test-Path -LiteralPath $ClientSecret) -and (Test-DesktopOAuthJson $ClientSecret)) {
        Copy-Item -LiteralPath $ClientSecret -Destination $PersistentClientSecret -Force
        Write-Step "Google Desktop OAuth file is ready and saved permanently."
        return $true
    }
    $searchFolders = @($Root, $ConfigDir, (Join-Path $env:USERPROFILE "Downloads"))
    $candidates = foreach ($folder in $searchFolders) {
        if (Test-Path -LiteralPath $folder) {
            Get-ChildItem -LiteralPath $folder -File -Filter "*.json" -ErrorAction SilentlyContinue |
                Where-Object {
                    $_.Name -match "^(client_secret|credentials).*\.json$" -and
                    $_.Name -notmatch "\.example\."
                }
        }
    }
    # Fast upgrade helper: inspect only prior GmCL/VelocityX package folders.
    # Avoid recursively scanning the user's entire Downloads folder.
    $downloads = Join-Path $env:USERPROFILE "Downloads"
    if (Test-Path -LiteralPath $downloads) {
        try {
            $legacyCandidates = @()
            $legacyPackages = Get-ChildItem -LiteralPath $downloads -Directory -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -match "(?i)(GmCL|VelocityX)" } |
                Sort-Object LastWriteTime -Descending |
                Select-Object -First 12
            foreach ($package in $legacyPackages) {
                foreach ($candidatePath in @(
                    (Join-Path $package.FullName "client_secret.json"),
                    (Join-Path $package.FullName "credentials.json"),
                    (Join-Path $package.FullName "GmCL_Gmail_Cleaner\config\client_secret.json"),
                    (Join-Path $package.FullName "GmCL_Gmail_Cleaner\config\credentials.json")
                )) {
                    if (Test-Path -LiteralPath $candidatePath) {
                        $legacyCandidates += Get-Item -LiteralPath $candidatePath
                    }
                }
            }
            $candidates = @($candidates) + @($legacyCandidates)
        } catch {}
    }
    foreach ($candidate in ($candidates | Sort-Object LastWriteTime -Descending -Unique)) {
        if (Test-DesktopOAuthJson $candidate.FullName) {
            Copy-Item -LiteralPath $candidate.FullName -Destination $PersistentClientSecret -Force
            Copy-Item -LiteralPath $PersistentClientSecret -Destination $ClientSecret -Force
            Write-Step "Imported and permanently saved Google Desktop OAuth JSON from: $($candidate.FullName)"
            return $true
        }
    }
    return $false
}

function Has-ConnectedAccount {
    $accountsFile = Join-Path $DataDir "accounts.json"
    if (-not (Test-Path -LiteralPath $accountsFile)) { return $false }
    try {
        $data = Get-Content -LiteralPath $accountsFile -Raw -Encoding UTF8 | ConvertFrom-Json
        return ($null -ne $data.accounts -and @($data.accounts.PSObject.Properties).Count -gt 0)
    } catch {
        return $false
    }
}

function Get-RunningServerVersion {
    param([int]$TimeoutSec = 1)
    try {
        $raw = Invoke-WebRequest -UseBasicParsing -Uri "http://127.0.0.1:8795/api/state?startup_probe=1" -TimeoutSec $TimeoutSec
        $response = $raw.Content | ConvertFrom-Json
        if ($response -and $response.version) { return [string]$response.version }
    } catch {}
    return $null
}

function Get-GmclServerProcessId {
    $pidFile = Join-Path $DataDir "server.pid"
    if (Test-Path -LiteralPath $pidFile) {
        try {
            $value = (Get-Content -LiteralPath $pidFile -Raw -Encoding ASCII).Trim()
            $parsed = 0
            if ([int]::TryParse($value, [ref]$parsed) -and $parsed -gt 0) { return $parsed }
        } catch {}
    }
    try {
        $connection = Get-NetTCPConnection -LocalPort 8795 -State Listen -ErrorAction Stop | Select-Object -First 1
        if ($connection -and $connection.OwningProcess) { return [int]$connection.OwningProcess }
    } catch {}
    return $null
}

function Stop-StaleGmclServer {
    param([string]$ExpectedVersion)
    $runningVersion = Get-RunningServerVersion -TimeoutSec 1
    if (-not $runningVersion -or $runningVersion -eq $ExpectedVersion) { return }

    Write-Step "Older GmCL v$runningVersion is still running. Restarting it so the v$ExpectedVersion File Manager UI is actually loaded..."
    $serverProcessId = Get-GmclServerProcessId
    if (-not $serverProcessId) {
        throw "GmCL v$runningVersion is still using port 8795, but its process could not be identified. Run STOP_LOCAL_SERVER.bat once, then retry."
    }

    $safeToStop = $false
    try {
        $processInfo = Get-CimInstance Win32_Process -Filter "ProcessId = $serverProcessId" -ErrorAction Stop
        $commandLine = [string]$processInfo.CommandLine
        $safeToStop = ($commandLine -match "(?i)app\.py")
    } catch {
        # The persistent GmCL PID file is itself strong evidence when the HTTP
        # endpoint above already reported a GmCL version.
        $pidFile = Join-Path $DataDir "server.pid"
        $safeToStop = Test-Path -LiteralPath $pidFile
    }
    if (-not $safeToStop) {
        throw "Port 8795 is occupied by a process that could not be safely confirmed as GmCL. Close that process, then retry."
    }

    try { Stop-Process -Id $serverProcessId -Force -ErrorAction Stop } catch {
        throw "The previous GmCL server could not be stopped automatically. Run STOP_LOCAL_SERVER.bat once, then retry."
    }
    for ($attempt = 0; $attempt -lt 20; $attempt++) {
        Start-Sleep -Milliseconds 100
        if (-not (Get-RunningServerVersion -TimeoutSec 1)) { break }
    }
    Remove-Item -LiteralPath (Join-Path $DataDir "server.pid") -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath (Join-Path $DataDir "server.lock") -Force -ErrorAction SilentlyContinue
}

function Start-LocalDashboard {
    param([string]$VenvPython)
    $expectedVersion = (Get-Content -LiteralPath (Join-Path $Root "VERSION.txt") -Raw).Trim()
    $uri = "http://127.0.0.1:8795"

    Stop-StaleGmclServer -ExpectedVersion $expectedVersion
    $runningVersion = Get-RunningServerVersion -TimeoutSec 1
    if ($runningVersion -eq $expectedVersion) {
        Start-Process "$uri/?ui=$expectedVersion"
        return
    }

    $pythonw = Join-Path (Split-Path -Parent $VenvPython) "pythonw.exe"
    if (-not (Test-Path -LiteralPath $pythonw)) { $pythonw = $VenvPython }
    $appPath = Join-Path $Root "app.py"
    $quotedAppPath = ([char]34) + $appPath + ([char]34)
    Start-Process -FilePath $pythonw -ArgumentList @($quotedAppPath, "--no-browser") -WorkingDirectory $Root
    for ($attempt = 0; $attempt -lt 30; $attempt++) {
        Start-Sleep -Milliseconds 150
        $runningVersion = Get-RunningServerVersion -TimeoutSec 1
        if ($runningVersion -eq $expectedVersion) {
            Start-Process "$uri/?ui=$expectedVersion"
            return
        }
    }
    throw "The v$expectedVersion dashboard did not start. Check $DataDir\server.log."
}

function Update-ExistingAutoStartTask {
    # Preserve an existing auto-start preference and repoint it to THIS package.
    # V1.8.8 uses the current-user Startup folder because some Windows profiles
    # are not allowed to create Scheduled Tasks.
    try {
        $startup = [Environment]::GetFolderPath("Startup")
        $startupFile = Join-Path $startup "GmCL_AutoStart.cmd"
        $runtimeRunner = Join-Path $RuntimeDir "AutoStart-Runner.ps1"
        $rootFile = Join-Path $RuntimeDir "autostart_root.txt"
        $sourceRunner = Join-Path $Root "launcher\AutoStart-Runner.ps1"

        if (Test-Path -LiteralPath $startupFile) {
            Copy-Item -LiteralPath $sourceRunner -Destination $runtimeRunner -Force
            Set-Content -LiteralPath $rootFile -Value ($Root + [IO.Path]::DirectorySeparatorChar) -Encoding ASCII
            Write-Step "Existing GmCL user auto-start updated to the current package."
            return
        }

        # Legacy V1.8.7 and earlier installations may already have a task.
        # If it is writable, keep it current. If Windows blocks task changes,
        # smart setup remains successful and INSTALL_AUTO_START.bat can switch
        # the user to the no-admin Startup method.
        $existingTask = Get-ScheduledTask -TaskName "GmCL" -ErrorAction SilentlyContinue
        if (-not $existingTask) { return }
        $pythonw = Join-Path $RuntimeDir "venv\Scripts\pythonw.exe"
        if (-not (Test-Path -LiteralPath $pythonw)) { return }
        $appPath = Join-Path $Root "app.py"
        $argument = ([char]34) + $appPath + ([char]34) + " --no-browser"
        $action = New-ScheduledTaskAction -Execute $pythonw -Argument $argument -WorkingDirectory $Root
        $trigger = New-ScheduledTaskTrigger -AtLogOn
        $user = [Security.Principal.WindowsIdentity]::GetCurrent().Name
        $principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
        Register-ScheduledTask -TaskName "GmCL" -Action $action -Trigger $trigger -Principal $principal -Description "Starts the current GmCL Gmail cleanup dashboard at Windows sign-in." -Force | Out-Null
        Write-Step "Existing GmCL auto-start task updated to the current package."
    } catch {
        Write-Step "Windows blocked the old task update. Use INSTALL_AUTO_START.bat once to switch to no-admin auto start."
    }
}

try {
    Write-Step "GmCL smart setup started."
    $Python = Install-PythonIfNeeded
    $VenvDir = Join-Path $RuntimeDir "venv"
    $VenvPython = Join-Path $VenvDir "Scripts\python.exe"
    $venvReady = $false
    if (Test-Path -LiteralPath $VenvPython) {
        try {
            & $VenvPython -c "import sys; assert sys.version_info >= (3,10)" 2>$null
            $venvReady = ($LASTEXITCODE -eq 0)
        } catch {
            $venvReady = $false
        }
    }
    if (-not $venvReady -and -not (Test-Path -LiteralPath $VenvPython)) {
        $legacyVenv = Get-LegacyVenv
        if ($legacyVenv) {
            Write-Step "Reusing the previously installed GmCL Python runtime for a faster upgrade..."
            if (Copy-LegacyVenvFast -Source $legacyVenv -Destination $VenvDir) {
                try {
                    & $VenvPython -c "import sys; assert sys.version_info >= (3,10)" 2>$null
                    $venvReady = ($LASTEXITCODE -eq 0)
                } catch { $venvReady = $false }
            }
        }
    }
    if (-not $venvReady) {
        if (Test-Path -LiteralPath $VenvDir) {
            Remove-Item -LiteralPath $VenvDir -Recurse -Force -ErrorAction SilentlyContinue
        }
        Write-Step "Creating the persistent private Python environment..."
        & $Python -m venv $VenvDir
        if ($LASTEXITCODE -ne 0) { throw "Could not create the private Python environment." }
    } else {
        Write-Step "Persistent Python runtime is ready - no reinstall needed."
    }

    # Use a real .py file for this check. Windows PowerShell 5.1 can mangle
    # quotes/newlines when a multi-line script is passed to python.exe via -c.
    # That caused the first-run "File <string>, line 3" SyntaxError on some PCs.
    $dependencyChecker = Join-Path $PSScriptRoot "Check-Dependencies.py"
    if (-not (Test-Path -LiteralPath $dependencyChecker)) {
        throw "launcher\Check-Dependencies.py is missing. Extract the complete ZIP and try again."
    }
    & $VenvPython $dependencyChecker 2>$null
    if ($LASTEXITCODE -eq 0) {
        Write-Step "Verified requirements already installed - skipping package download."
    } else {
        Write-Step "Installing verified requirements..."
        & $VenvPython -m pip install --disable-pip-version-check --prefer-binary --only-binary=:all: -r (Join-Path $Root "requirements.txt")
        if ($LASTEXITCODE -ne 0) {
            Write-Step "Fast wheel-only install was unavailable. Retrying with compatible binary preference..."
            & $VenvPython -m pip install --disable-pip-version-check --prefer-binary -r (Join-Path $Root "requirements.txt")
        }
        if ($LASTEXITCODE -ne 0) { throw "Required packages could not be installed." }
    }

    $version = (Get-Content -LiteralPath (Join-Path $Root "VERSION.txt") -Raw).Trim()
    $validationMarker = Join-Path $DataDir "validated_version.txt"
    $alreadyValidated = (Test-Path -LiteralPath $validationMarker) -and ((Get-Content -LiteralPath $validationMarker -Raw).Trim() -eq $version)
    if ($alreadyValidated) {
        Write-Step "Safety checks already passed for GmCL v$version - skipping repeat tests."
    } else {
        Write-Step "Running safety checks..."
        & $VenvPython -m unittest discover -s (Join-Path $Root "tests") -q
        if ($LASTEXITCODE -ne 0) { throw "Safety checks failed. Gmail was not changed." }
        [IO.File]::WriteAllText($validationMarker, $version, [Text.Encoding]::ASCII)
    }

    if (-not (Import-OAuthJsonIfAvailable)) {
        Write-Step "Google Desktop OAuth JSON is the only remaining required setup. Once supplied, GmCL saves it in LocalAppData for future ZIP updates."
        Start-Process "https://console.cloud.google.com/apis/credentials"
        Start-Process explorer.exe -ArgumentList (([char]34) + $ConfigDir + ([char]34))
        $readme = Join-Path $Root "README_FIRST.txt"
        Start-Process notepad.exe -ArgumentList (([char]34) + $readme + ([char]34))
        Write-Host ""
        Write-Host "CREATE/DOWNLOAD THE GOOGLE DESKTOP OAUTH JSON ONCE." -ForegroundColor Yellow
        Write-Host "Save it in Downloads. This launcher will detect it and keep a durable copy automatically on the next run."
        exit 2
    }

    if (-not (Has-ConnectedAccount)) {
        Write-Step "No Gmail is connected yet. Opening Google's secure account-consent window..."
        & $VenvPython (Join-Path $Root "add_account.py")
        if ($LASTEXITCODE -ne 0) { throw "Google account connection was not completed." }
    }

    Update-ExistingAutoStartTask
    Write-Step "Starting the local dashboard..."
    Start-LocalDashboard -VenvPython $VenvPython
    Write-Step "Setup complete. Future starts can use ONE_CLICK_START.bat."
    exit 0
} catch {
    Write-Step ("ERROR: " + $_.Exception.Message)
    Write-Host ""
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host "Details were saved to $LogFile."
    exit 1
}
