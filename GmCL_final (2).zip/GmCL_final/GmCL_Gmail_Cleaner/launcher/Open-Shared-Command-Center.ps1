[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$ConfigCandidates = @(
    (Join-Path $Root 'CLIENT_ACCESS\shared_command_center.json'),
    (Join-Path $Root 'shared_command_center.json'),
    # Upgrade fallback: V1.8.0/V1.8.1 already generated this central-server
    # client config, so the Common launcher can reuse it without reconnecting Gmail.
    (Join-Path $Root 'CLIENT_ACCESS\GmCL_CLIENT_APPLICATION\client_config.json')
)
$ConfigPath = $ConfigCandidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
if (-not $ConfigPath) {
    Write-Host 'ERROR: Shared Command Center is not configured yet.' -ForegroundColor Red
    Write-Host 'On the main GmCL server PC, run MAKE_THIS_PC_SERVER.bat once, then retry.'
    exit 1
}

$config = Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
$key = [string]$config.access_key
if ([string]::IsNullOrWhiteSpace($key)) { throw 'Shared access key is missing.' }
$candidates = @($config.server_candidates | ForEach-Object { ([string]$_).TrimEnd('/') } | Where-Object { $_ })
if (-not $candidates.Count) { throw 'No GmCL server address is configured.' }

$server = $null
foreach ($candidate in $candidates) {
    try {
        $headers = @{ 'X-GmCL-Access-Key' = $key }
        $response = Invoke-RestMethod -Method Get -Uri ($candidate + '/api/client/ping') -Headers $headers -TimeoutSec 3
        if ($response.ok -and $response.service -eq 'GmCL') {
            $server = $candidate
            break
        }
    } catch {}
}

if (-not $server) {
    Write-Host 'ERROR: The central GmCL server is not reachable.' -ForegroundColor Red
    Write-Host 'Keep the main server PC ON and connected to the office network/Tailscale.'
    Write-Host 'Then run this file again.'
    exit 1
}

$encoded = [Uri]::EscapeDataString($key)
$url = $server + '/?command_access=' + $encoded
Write-Host ('Opening central GmCL dashboard: ' + $server)
Start-Process $url
exit 0
