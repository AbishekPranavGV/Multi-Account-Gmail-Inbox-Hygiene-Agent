$ErrorActionPreference = 'SilentlyContinue'

$runtimeDir = Join-Path $env:LOCALAPPDATA 'GmCL\Runtime'
$rootFile = Join-Path $runtimeDir 'autostart_root.txt'
if (-not (Test-Path -LiteralPath $rootFile)) { exit 0 }

$root = (Get-Content -LiteralPath $rootFile -Raw).Trim()
if ([string]::IsNullOrWhiteSpace($root)) { exit 0 }

$startBat = Join-Path $root 'START_BACKGROUND.bat'

# Common/Tailscale/network folders may not be ready the instant Windows signs in.
# Wait quietly for up to five minutes, then start the same background cleaner.
for ($i = 0; $i -lt 60; $i++) {
    if (Test-Path -LiteralPath $startBat) {
        Start-Process -FilePath 'cmd.exe' -ArgumentList @('/c', ('"' + $startBat + '"')) -WindowStyle Hidden
        exit 0
    }
    Start-Sleep -Seconds 5
}
exit 0
