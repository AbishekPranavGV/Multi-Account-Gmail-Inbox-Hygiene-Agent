$ErrorActionPreference = 'Stop'
try {
    $root = Split-Path -Parent $PSScriptRoot
    $config = Get-Content -LiteralPath (Join-Path $root 'CLIENT_ACCESS\GmCL_CLIENT_APPLICATION\client_config.json') -Raw | ConvertFrom-Json
    $listeners = @(Get-NetTCPConnection -LocalPort 8795 -State Listen -ErrorAction Stop | Where-Object { $_.LocalAddress -eq '0.0.0.0' })
    if ($listeners.Count -eq 0) { throw 'GmCL is not listening on all network interfaces. Check port 8795 and data\server.log.' }
    $verified = $false
    foreach ($url in $config.server_candidates) {
        try {
            $reply = Invoke-RestMethod -Uri ($url + '/api/client/ping') -Headers @{'X-GmCL-Access-Key'=$config.access_key} -TimeoutSec 3
            if ($reply.service -eq 'GmCL') { $verified = $true; break }
        } catch {}
    }
    if (-not $verified) { throw 'GmCL could not be reached using its generated network addresses.' }
    Write-Host 'Network listener verified. Each client will test its own connection when opened.'
    exit 0
} catch { Write-Host $_.Exception.Message -ForegroundColor Red; exit 1 }
