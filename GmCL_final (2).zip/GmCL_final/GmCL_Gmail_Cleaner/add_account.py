from __future__ import annotations

import json
import sys

from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

from app.config import CLIENT_SECRET, SCOPES
from app.google_client import require_client_secret
from app.oauth_helpers import load_desktop_oauth_config
from app.store import get_account, load_token, save_token, upsert_account


def _merge_saved_refresh_token(email: str, token_value: dict) -> dict:
    """Keep a previously saved refresh token when Google omits it on re-consent.

    Google can return only a short-lived access token when the same OAuth client
    was already approved. Replacing the saved token in that case would make a
    previously persistent Gmail appear logged out later.
    """
    if token_value.get("refresh_token"):
        return token_value
    account = get_account(email) or {}
    # Never carry forward a refresh token that Google already rejected. A
    # reconnect must save the newly issued refresh token instead.
    if account.get("auth_reconnect_required") or "invalid_grant" in str(account.get("error", "")).lower() or "expired or revoked" in str(account.get("error", "")).lower():
        return token_value
    try:
        old = json.loads(load_token(email))
    except (OSError, ValueError, json.JSONDecodeError):
        return token_value
    if old.get("client_id") and old.get("client_id") == token_value.get("client_id") and old.get("refresh_token"):
        token_value["refresh_token"] = old["refresh_token"]
        if old.get("client_secret") and not token_value.get("client_secret"):
            token_value["client_secret"] = old["client_secret"]
        if old.get("token_uri") and not token_value.get("token_uri"):
            token_value["token_uri"] = old["token_uri"]
    return token_value


def main() -> int:
    try:
        require_client_secret()
        flow = InstalledAppFlow.from_client_config(load_desktop_oauth_config(CLIENT_SECRET), SCOPES)
        credentials = flow.run_local_server(
            host="127.0.0.1",
            port=0,
            open_browser=True,
            # Use the normal Windows default browser/profile. If that browser is
            # already signed in to Google, the user normally only chooses the
            # account and approves access; GmCL never needs the Google password.
            prompt="consent",
            access_type="offline",
            timeout_seconds=600,
            authorization_prompt_message="Opening Google sign-in in your browser. Choose the Gmail account and approve access once.",
            success_message="Gmail connected and saved. You may close this browser tab and return to GmCL.",
        )
        gmail = build("gmail", "v1", credentials=credentials, cache_discovery=False)
        profile = gmail.users().getProfile(userId="me").execute()
        email = str(profile.get("emailAddress", "")).strip().lower()
        if not email:
            raise RuntimeError("Google did not return the Gmail address.")

        token_value = json.loads(credentials.to_json())
        token_value = _merge_saved_refresh_token(email, token_value)
        if not token_value.get("refresh_token"):
            raise RuntimeError(
                "Google did not issue a reusable refresh token. Approve access once with this account. "
                "For long-term saving, publish the OAuth consent app in Google Cloud instead of leaving it in Testing."
            )

        save_token(email, json.dumps(token_value, separators=(",", ":")))
        upsert_account(email, connection="CONNECTED", error="", last_result="Account authorized and saved", auth_reconnect_required=False, auth_error_code="")
        print(f"\nSUCCESS: {email} was connected and saved.")
        print("Future GmCL starts reuse this saved authorization; Google sign-in is not required again unless access is revoked.")
        print("Return to the dashboard and click Refresh All Accounts.")
        return 0
    except Exception as exc:
        print(f"\nFAILED: {exc}", file=sys.stderr)
        print(
            "No saved Gmail authorization was overwritten. If Google itself shows 'Something went wrong', "
            "close that tab, confirm the account can sign in normally at gmail.com in your default browser, "
            "then run ADD_GMAIL_ACCOUNT.bat again.",
            file=sys.stderr,
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
