from __future__ import annotations

import ctypes
import hashlib
import json
import os
import platform
import tempfile
import threading
from contextlib import contextmanager
from ctypes import wintypes
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from .config import ACCOUNTS_FILE, DEFAULT_SETTINGS, TOKEN_DIR

_thread_lock = threading.RLock()


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def account_id(email: str) -> str:
    return hashlib.sha256(email.strip().lower().encode("utf-8")).hexdigest()[:20]


@contextmanager
def _file_lock(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    lock_path = path.with_suffix(path.suffix + ".lock")
    handle = open(lock_path, "a+b")
    try:
        if platform.system() == "Windows":
            import msvcrt

            handle.seek(0, os.SEEK_END)
            if handle.tell() == 0:
                handle.write(b"0")
                handle.flush()
            handle.seek(0)
            msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
        else:
            import fcntl

            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        yield
    finally:
        try:
            if platform.system() == "Windows":
                import msvcrt

                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        finally:
            handle.close()


def _read_json_unlocked(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return default


def _atomic_json_unlocked(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2, sort_keys=True)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name, path)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)


def load_accounts() -> dict[str, Any]:
    with _thread_lock, _file_lock(ACCOUNTS_FILE):
        data = _read_json_unlocked(ACCOUNTS_FILE, {"version": 1, "accounts": {}})
        if not isinstance(data, dict) or not isinstance(data.get("accounts"), dict):
            return {"version": 1, "accounts": {}}
        return data


def mutate_accounts(mutator: Callable[[dict[str, Any]], Any]) -> Any:
    with _thread_lock, _file_lock(ACCOUNTS_FILE):
        data = _read_json_unlocked(ACCOUNTS_FILE, {"version": 1, "accounts": {}})
        if not isinstance(data, dict) or not isinstance(data.get("accounts"), dict):
            data = {"version": 1, "accounts": {}}
        result = mutator(data)
        _atomic_json_unlocked(ACCOUNTS_FILE, data)
        return result


def upsert_account(email: str, **patch: Any) -> dict[str, Any]:
    email = email.strip().lower()
    key = account_id(email)
    changes = dict(patch)

    def apply(data: dict[str, Any]) -> dict[str, Any]:
        current = data["accounts"].get(key, {})
        current.setdefault("email", email)
        current.setdefault("created_at", utc_now())
        current.setdefault("settings", dict(DEFAULT_SETTINGS))
        current.setdefault("stats", {})
        settings_patch = changes.get("settings")
        if settings_patch is not None:
            current["settings"] = {
                **DEFAULT_SETTINGS,
                **current.get("settings", {}),
                **settings_patch,
            }
        current.update({key: value for key, value in changes.items() if key != "settings"})
        current["email"] = email
        current["updated_at"] = utc_now()
        data["accounts"][key] = current
        return current.copy()

    return mutate_accounts(apply)


def remove_account(email: str) -> bool:
    key = account_id(email)

    def apply(data: dict[str, Any]) -> bool:
        return data["accounts"].pop(key, None) is not None

    removed = mutate_accounts(apply)
    token_path(email).unlink(missing_ok=True)
    return removed


def get_account(email: str) -> dict[str, Any] | None:
    return load_accounts()["accounts"].get(account_id(email.strip().lower()))


def list_accounts() -> list[dict[str, Any]]:
    rows = list(load_accounts()["accounts"].values())
    return sorted(rows, key=lambda row: row.get("email", ""))


def token_path(email: str) -> Path:
    return TOKEN_DIR / f"{account_id(email)}.token"


class _DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]


def _dpapi_protect(data: bytes) -> bytes:
    if platform.system() != "Windows":
        return data
    source_buffer = ctypes.create_string_buffer(data)
    source = _DATA_BLOB(len(data), ctypes.cast(source_buffer, ctypes.POINTER(ctypes.c_char)))
    output = _DATA_BLOB()
    if not ctypes.windll.crypt32.CryptProtectData(
        ctypes.byref(source), "GmCL Gmail token", None, None, None, 0, ctypes.byref(output)
    ):
        raise ctypes.WinError()
    try:
        return ctypes.string_at(output.pbData, output.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(output.pbData)


def _dpapi_unprotect(data: bytes) -> bytes:
    if platform.system() != "Windows":
        return data
    source_buffer = ctypes.create_string_buffer(data)
    source = _DATA_BLOB(len(data), ctypes.cast(source_buffer, ctypes.POINTER(ctypes.c_char)))
    output = _DATA_BLOB()
    if not ctypes.windll.crypt32.CryptUnprotectData(
        ctypes.byref(source), None, None, None, None, 0, ctypes.byref(output)
    ):
        raise ctypes.WinError()
    try:
        return ctypes.string_at(output.pbData, output.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(output.pbData)


def save_token(email: str, token_json: str) -> None:
    path = token_path(email)
    path.parent.mkdir(parents=True, exist_ok=True)
    protected = _dpapi_protect(token_json.encode("utf-8"))
    fd, temp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(protected)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name, path)
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)


def load_token(email: str) -> str:
    path = token_path(email)
    if not path.exists():
        raise FileNotFoundError(f"No saved authorization for {email}. Reconnect this account.")
    return _dpapi_unprotect(path.read_bytes()).decode("utf-8")
