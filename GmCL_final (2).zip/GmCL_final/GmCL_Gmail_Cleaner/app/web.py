from __future__ import annotations

import ipaddress
import json
import logging
import secrets
import subprocess
import sys
import base64
import hashlib
from datetime import timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from flask import Flask, jsonify, redirect, render_template, request, session, url_for

from .cleaner import (
    clean_promotions_social,
    list_candidates,
    mark_selected_not_spam,
    move_selected_to_trash,
    permanent_phrase,
    permanently_delete,
    scan_account,
    search_messages,
)
from .config import ACTIVITY_FILE, CLIENT_SECRET, NETWORK_ACCESS_KEY_FILE, ROOT, SCOPES, SESSION_SECRET_FILE
from .google_client import require_client_secret
from .scheduler import CleanupScheduler
from .store import get_account, list_accounts, load_token, remove_account, save_token, upsert_account, utc_now

LOGGER = logging.getLogger("gmcl.web")

def _read_or_create_secret(path: Path, nbytes: int = 32) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        value = path.read_text(encoding="ascii").strip()
        if len(value) >= 32:
            return value
    except OSError:
        pass
    value = secrets.token_hex(nbytes)
    path.write_text(value, encoding="ascii")
    try:
        path.chmod(0o600)
    except OSError:
        pass
    return value


def _client_address() -> ipaddress._BaseAddress | None:
    raw = (request.remote_addr or "").strip()
    try:
        return ipaddress.ip_address(raw)
    except ValueError:
        return None


def _allowed_network_address(address: ipaddress._BaseAddress | None) -> bool:
    if address is None:
        return False
    if address.is_loopback or address.is_private or address.is_link_local:
        return True
    # Tailscale/CGNAT range. Access still requires the GmCL client key.
    if isinstance(address, ipaddress.IPv4Address) and address in ipaddress.ip_network("100.64.0.0/10"):
        return True
    return False


def _public_account(account: dict[str, Any]) -> dict[str, Any]:
    public = {
        key: value
        for key, value in account.items()
        if key not in {"auto_purge_confirmation"}
    }
    error_text = str(public.get("error", "") or "")
    lowered = error_text.lower()
    if "invalid_grant" in lowered or "expired or revoked" in lowered:
        # Older saved state may contain Google's raw OAuth exception. Present a
        # simple recovery message instead of technical token text.
        public["connection"] = "RECONNECT"
        public["auth_reconnect_required"] = True
        public["auth_error_code"] = "invalid_grant"
        public["error"] = "Google login expired or was revoked. Login again once to reconnect this Gmail."
    return public


def _write_activity(email: str, action: str, result: str, details: Any) -> None:
    ACTIVITY_FILE.parent.mkdir(parents=True, exist_ok=True)
    if ACTIVITY_FILE.exists() and ACTIVITY_FILE.stat().st_size > 2_000_000:
        backup = ACTIVITY_FILE.with_suffix(".jsonl.1")
        backup.unlink(missing_ok=True)
        ACTIVITY_FILE.replace(backup)
    entry = {
        "time": utc_now(),
        "email": email,
        "action": action,
        "result": result,
        "details": details,
    }
    with ACTIVITY_FILE.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(entry, ensure_ascii=False) + "\n")


def _recent_activity(limit: int = 80) -> list[dict[str, Any]]:
    if not ACTIVITY_FILE.exists():
        return []
    lines = ACTIVITY_FILE.read_text(encoding="utf-8", errors="replace").splitlines()[-limit:]
    rows = []
    for line in reversed(lines):
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return rows


def _payload() -> dict[str, Any]:
    value = request.get_json(silent=True)
    if not isinstance(value, dict):
        raise ValueError("A JSON object is required.")
    return value


def create_app(scheduler: CleanupScheduler | None = None) -> Flask:
    app = Flask(__name__, template_folder="templates", static_folder="static")
    app.secret_key = _read_or_create_secret(SESSION_SECRET_FILE)
    network_access_key = _read_or_create_secret(NETWORK_ACCESS_KEY_FILE)
    app.config.update(
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=False,
        PERMANENT_SESSION_LIFETIME=timedelta(days=30),
        MAX_CONTENT_LENGTH=256 * 1024,
    )
    scheduler = scheduler or CleanupScheduler()
    app.extensions["cleanup_scheduler"] = scheduler

    signer = URLSafeTimedSerializer(app.secret_key, salt="gmcl-account-dashboard-v2")
    resume_signer = URLSafeTimedSerializer(app.secret_key, salt="gmcl-client-resume-v1")

    def visible_accounts():
        rows = list_accounts()
        # The Common/Tailscale Command Center is an authenticated shared
        # administrator view of the ONE central server. Individual client
        # sessions keep the previous own-account-only privacy behavior.
        if session.get("client_email") and not session.get("shared_command_center"):
            rows = [row for row in rows if row["email"] == session["client_email"]]
        return rows

    @app.before_request
    def protect_network_and_actions():
        address = _client_address()
        if not _allowed_network_address(address):
            return "GmCL only accepts local/private network clients.", 403

        is_server_pc = bool(address and address.is_loopback)
        if request.path in {"/api/client/ping", "/api/client/register", "/api/client/resume"}:
            supplied_key = request.headers.get("X-GmCL-Access-Key", "")
            if supplied_key and secrets.compare_digest(supplied_key, network_access_key):
                return None
            return jsonify({"ok": False, "error": "Invalid GmCL client access key."}), 403
        if not is_server_pc:
            # Shared Command Center access is for the trusted Common/Tailscale
            # launcher only. It never copies Gmail tokens to the client PC; all
            # accounts and scheduled cleaning remain on this central server.
            command_access = request.args.get("command_access", "")
            if request.path == "/" and command_access:
                if not secrets.compare_digest(command_access, network_access_key):
                    return "Invalid GmCL Common/Tailscale dashboard access.", 403
                session.clear()
                session["shared_command_center"] = True
                session.permanent = True
                return redirect(url_for("index"))

            dashboard_token = request.args.get("account_access", "")
            if request.path == "/" and dashboard_token:
                try:
                    # Browser dashboard grants are intentionally temporary. Gmail OAuth
                    # credentials are persisted separately and can refresh this grant
                    # without asking the user to sign in to Google again.
                    grant = signer.loads(dashboard_token, max_age=30 * 86400)
                    email = grant["email"]
                    if not get_account(email):
                        raise ValueError("Account removed")
                except (BadSignature, SignatureExpired, KeyError, ValueError):
                    return "This dashboard link expired. Run START_GMCL_CLIENT.bat to refresh saved access automatically.", 403
                session.clear()
                session["client_email"] = email
                session.permanent = True
                return redirect(url_for("index"))

            shared_command_center = bool(session.get("shared_command_center"))
            client_email = str(session.get("client_email", "") or "").lower()
            individual_client_ready = bool(client_email and get_account(client_email))
            if not shared_command_center and not individual_client_ready:
                return "<h2>GmCL sign-in required</h2><p>From the Common/Tailscale folder run START_COMMON_TAILSCALE_DASHBOARD.bat, or run START_GMCL_CLIENT.bat for an individual Gmail view.</p>", 403

            # OAuth must be initiated on the PC that owns the Google browser
            # session. Never launch the server PC's browser from a remote page.
            if request.path == "/api/accounts/add":
                return jsonify(ok=False, error="Connect Gmail from this PC using CLIENT_ACCESS\\GmCL_CLIENT_APPLICATION\\CONNECT_GMAIL.bat."), 403

            # Individual client sessions remain scoped to their own Gmail. The
            # authenticated Common/Tailscale Command Center is intentionally
            # allowed to manage every account already stored on the central server.
            if (not shared_command_center and request.path.startswith("/api/")
                    and request.path not in {"/api/state", "/api/accounts/scan-all", "/api/search"}):
                data = request.get_json(silent=True) if request.method != "GET" else request.args
                email = str((data or {}).get("email", "")).lower()
                if not (request.path == "/api/candidates" and email == "__all__") and email != client_email:
                    return jsonify(ok=False, error="You can access only your own Gmail account."), 403
        else:
            # The server PC's local dashboard is the administrator view.
            session.pop("client_email", None)
            session.pop("shared_command_center", None)

        if request.method in {"POST", "PUT", "PATCH", "DELETE"}:
            expected = session.get("csrf")
            supplied = request.headers.get("X-CSRF-Token")
            if not expected or not supplied or not secrets.compare_digest(str(expected), str(supplied)):
                return jsonify({"ok": False, "error": "Security token expired. Refresh the dashboard."}), 403

    @app.after_request
    def security_headers(response):
        # UI assets are intentionally revalidated so an extracted upgrade cannot
        # keep showing an older cached dashboard after the GmCL server restarts.
        response.headers["Cache-Control"] = (
            "no-cache, max-age=0, must-revalidate" if request.path.startswith("/static/") else "no-store"
        )
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; style-src 'self'; script-src 'self'; "
            "img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'"
        )
        return response

    @app.errorhandler(Exception)
    def handle_error(exc):
        status = 400 if isinstance(exc, (ValueError, KeyError, FileNotFoundError)) else 500
        if status >= 500:
            LOGGER.exception("Request failed")
        else:
            LOGGER.info("Request rejected: %s", exc)
        return jsonify({"ok": False, "error": str(exc)}), status

    @app.get("/")
    def index():
        session.setdefault("csrf", secrets.token_urlsafe(32))
        return render_template("index.html", csrf=session["csrf"])

    @app.get("/api/state")
    def state():
        session.setdefault("csrf", secrets.token_urlsafe(32))
        accounts = [_public_account(row) for row in visible_accounts()]
        return jsonify(
            {
                "ok": True,
                "version": "1.9.0",
                "accounts": accounts,
                "activity": [
                    row for row in _recent_activity()
                    if session.get("shared_command_center")
                    or not session.get("client_email")
                    or row.get("email") == session["client_email"]
                ],
                # Remote Common/Tailscale view hides server-local OAuth launch
                # controls but otherwise has the same all-account command view.
                "client_mode": bool(session.get("client_email") or session.get("shared_command_center")),
                "shared_command_center": bool(session.get("shared_command_center")),
                "client_secret_ready": CLIENT_SECRET.exists(),
                "csrf": session["csrf"],
            }
        )

    @app.post("/api/accounts/add")
    def add_account():
        require_client_secret()
        kwargs: dict[str, Any] = {"cwd": str(ROOT)}
        if sys.platform == "win32":
            kwargs["creationflags"] = subprocess.CREATE_NEW_CONSOLE
        subprocess.Popen([sys.executable, str(ROOT / "add_account.py")], **kwargs)
        return jsonify({"ok": True, "message": "Google sign-in opened in a separate window. Refresh after it reports SUCCESS."})

    @app.post("/api/client/register")
    def register_client_account():
        """Validate and import a Gmail authorization created on a client PC."""
        from google.oauth2.credentials import Credentials
        from googleapiclient.discovery import build

        payload = _payload()
        encrypted_token = payload.get("encrypted_token")
        if not isinstance(encrypted_token, str):
            raise ValueError("Client authorization is missing or invalid.")
        from cryptography.fernet import Fernet, InvalidToken
        fernet_key = base64.urlsafe_b64encode(hashlib.sha256(network_access_key.encode("ascii")).digest())
        try:
            token_value = json.loads(Fernet(fernet_key).decrypt(encrypted_token.encode("ascii")).decode("utf-8"))
        except (InvalidToken, ValueError, json.JSONDecodeError) as exc:
            raise ValueError("Client authorization could not be verified.") from exc
        if not isinstance(token_value, dict):
            raise ValueError("Client authorization is missing or invalid.")
        token_json = json.dumps(token_value, separators=(",", ":"))
        if token_value.get("refresh_token"):
            credentials = Credentials.from_authorized_user_info(token_value)
        else:
            # A repeat OAuth response may contain a valid access token but omit
            # refresh_token. Use the access token only to identify the Gmail, then
            # merge the server's previously saved refresh token below.
            if not token_value.get("token"):
                raise ValueError("Google authorization did not include an access token.")
            credentials = Credentials(
                token=token_value.get("token"),
                refresh_token=None,
                token_uri=token_value.get("token_uri") or "https://oauth2.googleapis.com/token",
                client_id=token_value.get("client_id"),
                client_secret=token_value.get("client_secret"),
                scopes=token_value.get("scopes") or SCOPES,
            )
        gmail = build("gmail", "v1", credentials=credentials, cache_discovery=False)
        profile = gmail.users().getProfile(userId="me").execute()
        email = str(profile.get("emailAddress", "")).strip().lower()
        if not email:
            raise ValueError("Google did not return the Gmail address.")
        existing = get_account(email)

        # Google sometimes omits refresh_token on a repeat authorization because
        # the account already granted this OAuth client access. Never replace a
        # known-good saved refresh token with a short-lived access token.
        if not token_value.get("refresh_token"):
            # Only reuse the old refresh token when it has not already been
            # rejected by Google. invalid_grant must be repaired with a newly
            # issued token from the fresh consent flow.
            existing_error = str((existing or {}).get("error", "") or "").lower()
            reconnect_required = bool((existing or {}).get("auth_reconnect_required")) or "invalid_grant" in existing_error or "expired or revoked" in existing_error
            try:
                old_token = {} if reconnect_required else json.loads(load_token(email))
            except (OSError, ValueError, json.JSONDecodeError):
                old_token = {}
            same_client = (
                old_token.get("client_id")
                and token_value.get("client_id")
                and old_token.get("client_id") == token_value.get("client_id")
            )
            if same_client and old_token.get("refresh_token"):
                token_value["refresh_token"] = old_token["refresh_token"]
                token_value.setdefault("client_secret", old_token.get("client_secret"))
                token_value.setdefault("token_uri", old_token.get("token_uri"))
                token_json = json.dumps(token_value, separators=(",", ":"))

        if not token_value.get("refresh_token"):
            raise ValueError(
                "Google did not return a reusable login token. Choose the account, approve access once, "
                "and make sure this OAuth app is published rather than left in Google testing mode."
            )

        # Google has verified ownership; refresh authorization without resetting settings.
        save_token(email, token_json)
        upsert_account(email, connection="CONNECTED", error="", last_result="Reconnected from client" if existing else "Added from client", auth_reconnect_required=False, auth_error_code="")
        _write_activity(email, "CLIENT REGISTER", "SUCCESS", {"client": request.remote_addr})
        access = signer.dumps({"email": email})
        resume_token = resume_signer.dumps({"email": email})
        return jsonify(ok=True, status="reconnected" if existing else "added", email=email,
                       account_access=access, resume_token=resume_token,
                       message="Gmail connected and saved. Opening your private dashboard.")

    @app.post("/api/client/resume")
    def resume_client_account():
        """Exchange saved client state for a fresh temporary dashboard grant.

        This never performs Google OAuth. The Gmail refresh token remains stored on the
        server; this endpoint only refreshes the browser-dashboard authorization.
        """
        payload = _payload()
        email = ""
        resume_token = str(payload.get("resume_token", "") or "").strip()
        previous_access = str(payload.get("account_access", "") or "").strip()
        try:
            if resume_token:
                grant = resume_signer.loads(resume_token)
            elif previous_access:
                # One-time upgrade path for v1.6.0/v1.6.1 clients that only saved
                # the old 30-day dashboard grant.
                grant = signer.loads(previous_access, max_age=30 * 86400)
            else:
                raise BadSignature("Missing saved client grant")
            email = str(grant["email"]).strip().lower()
            if not get_account(email):
                raise ValueError("Account removed")
        except (BadSignature, SignatureExpired, KeyError, ValueError, TypeError):
            return jsonify(ok=False, error="Saved client access is no longer valid. Run CONNECT_GMAIL.bat once to reconnect this PC."), 403
        fresh_access = signer.dumps({"email": email})
        fresh_resume = resume_signer.dumps({"email": email})
        return jsonify(ok=True, email=email, account_access=fresh_access, resume_token=fresh_resume)

    @app.get("/api/client/ping")
    def client_ping():
        return jsonify({"ok": True, "service": "GmCL", "version": "1.9.0"})

    def _quota_cooldown_error(exc: Exception) -> bool:
        text = str(exc).lower()
        return any(marker in text for marker in (
            "quota exceeded", "ratelimitexceeded", "user rate limit exceeded",
            "units per minute per user", "usage limits",
        ))

    @app.post("/api/accounts/scan")
    def scan_one():
        email = str(_payload().get("email", "")).lower()
        if not get_account(email):
            raise KeyError("Account is not registered.")
        try:
            stats = scan_account(email)
        except Exception as exc:
            current = get_account(email) or {}
            message = str(exc)
            if _quota_cooldown_error(exc):
                public_message = "Google Gmail API is cooling down. GmCL will retry automatically; no Gmail login change is required."
                upsert_account(email, connection="CONNECTED", error="", last_result="API COOLING DOWN")
                _write_activity(email, "ANALYZE", "COOLING DOWN", public_message)
                return jsonify({"ok": False, "error": public_message, "quota_cooldown": True}), 429
            login_required = bool(current.get("auth_reconnect_required")) or current.get("connection") == "RECONNECT" or any(
                marker in message.lower() for marker in (
                    "invalid_grant", "expired or revoked", "login expired",
                    "login again", "invalid credentials", "reconnect this account",
                )
            )
            if login_required:
                public_message = "Google login needs to be renewed. Click Login Again for this Gmail."
                upsert_account(email, connection="RECONNECT", error=public_message, last_result="LOGIN REQUIRED", auth_reconnect_required=True)
                _write_activity(email, "ANALYZE", "LOGIN AGAIN", public_message)
                return jsonify({"ok": False, "error": public_message, "login_required": True}), 409
            _write_activity(email, "ANALYZE", "ERROR", message)
            raise
        _write_activity(email, "ANALYZE", "SUCCESS", {"counts": stats["counts"]})
        return jsonify({"ok": True, "stats": stats})

    @app.post("/api/accounts/scan-all")
    def scan_all():
        accounts = visible_accounts()
        results: dict[str, Any] = {}
        with ThreadPoolExecutor(max_workers=min(2, max(1, len(accounts)))) as pool:
            futures = {pool.submit(scan_account, row["email"]): row["email"] for row in accounts}
            for future in as_completed(futures):
                email = futures[future]
                try:
                    results[email] = {"ok": True, "stats": future.result()}
                    _write_activity(email, "ANALYZE", "SUCCESS", "Storage and cleanup opportunities refreshed.")
                except Exception as exc:
                    message = str(exc)
                    current = get_account(email) or {}
                    if _quota_cooldown_error(exc):
                        public_message = "Google Gmail API is cooling down. GmCL will retry automatically; no Gmail login change is required."
                        upsert_account(email, connection="CONNECTED", error="", last_result="API COOLING DOWN")
                        results[email] = {"ok": False, "error": public_message, "quota_cooldown": True}
                        _write_activity(email, "ANALYZE", "COOLING DOWN", public_message)
                        continue
                    login_required = bool(current.get("auth_reconnect_required")) or current.get("connection") == "RECONNECT" or any(
                        marker in message.lower() for marker in (
                            "invalid_grant", "expired or revoked", "login expired",
                            "login again", "invalid credentials", "reconnect this account",
                        )
                    )
                    if login_required:
                        public_message = "Google login needs to be renewed. Click Login Again for this Gmail."
                        upsert_account(
                            email, connection="RECONNECT", error=public_message,
                            last_result="LOGIN REQUIRED", auth_reconnect_required=True,
                        )
                        results[email] = {"ok": False, "error": public_message, "login_required": True}
                        _write_activity(email, "ANALYZE", "LOGIN AGAIN", public_message)
                    else:
                        results[email] = {"ok": False, "error": message}
                        upsert_account(email, connection="ERROR", error=message, last_result="Analysis failed")
                        _write_activity(email, "ANALYZE", "ERROR", message)
        return jsonify({"ok": True, "results": results})

    @app.post("/api/accounts/clean")
    def clean_one():
        email = str(_payload().get("email", "")).lower()
        result = clean_promotions_social(email)
        _write_activity(email, "CLEAN PROMOTIONS + SOCIAL", result["status"], result)
        return jsonify({"ok": True, **result})

    @app.post("/api/accounts/settings")
    def save_settings():
        data = _payload()
        email = str(data.get("email", "")).lower()
        current = get_account(email)
        if not current:
            raise KeyError("Account is not registered.")
        old = current.get("settings", {})
        settings = {
            "enabled": bool(data.get("enabled", old.get("enabled", False))),
            "business_guard_enabled": bool(data.get("business_guard_enabled", old.get("business_guard_enabled", False))),
            "min_age_days": int(data.get("min_age_days", 7)),
            "protect_starred": bool(data.get("protect_starred", True)),
            "protect_important": bool(data.get("protect_important", True)),
            "max_per_run": int(data.get("max_per_run", 2000)),
            "every_hours": int(data.get("every_hours", old.get("every_hours", 1))),
            "schedule_mode": str(data.get("schedule_mode", old.get("schedule_mode", "interval"))),
            "end_of_day_time": str(data.get("end_of_day_time", old.get("end_of_day_time", "23:00"))),
            "auto_purge_trash": bool(data.get("auto_purge_trash", old.get("auto_purge_trash", False))),
            "trash_age_days": int(data.get("trash_age_days", 30)),
        }
        if not 0 <= settings["min_age_days"] <= 3650:
            raise ValueError("Minimum age must be 0–3650 days.")
        if settings["max_per_run"] not in {100, 500, 1000, 2000, 5000}:
            raise ValueError("Run limit must be 100, 500, 1000, 2000, or 5000.")
        if settings["every_hours"] not in {1, 6, 12, 24}:
            raise ValueError("Schedule must be every 1, 6, 12, or 24 hours.")
        if settings["schedule_mode"] not in {"interval", "end_of_day"}:
            raise ValueError("Schedule mode must be interval or end_of_day.")
        try:
            eod_hour, eod_minute = [int(part) for part in settings["end_of_day_time"].split(":", 1)]
        except (ValueError, TypeError):
            raise ValueError("End-of-day time must use HH:MM.")
        if not 0 <= eod_hour <= 23 or not 0 <= eod_minute <= 59:
            raise ValueError("End-of-day time must use a valid 24-hour time.")
        settings["end_of_day_time"] = f"{eod_hour:02d}:{eod_minute:02d}"
        if not 1 <= settings["trash_age_days"] <= 3650:
            raise ValueError("Trash age must be 1–3650 days.")
        confirmation = permanent_phrase(email) if settings["auto_purge_trash"] else ""
        upsert_account(email, settings=settings, auto_purge_confirmation=confirmation, last_result="Settings saved")
        scheduler.wake()
        _write_activity(email, "SAVE SETTINGS", "SUCCESS", {**settings, "auto_purge_confirmation": "not stored in log"})
        return jsonify({"ok": True})

    @app.post("/api/accounts/guard")
    def set_business_guard():
        data = _payload()
        email = str(data.get("email", "")).lower()
        account = get_account(email)
        if not account:
            raise KeyError("Account is not registered.")
        enabled = bool(data.get("enabled", False))
        settings = {**account.get("settings", {}), "business_guard_enabled": enabled}
        upsert_account(email, settings=settings, last_result=f"Business Mail Guard {'ON' if enabled else 'OFF'}")
        _write_activity(email, "BUSINESS MAIL GUARD", "ON" if enabled else "OFF", "Manual protection setting changed.")
        return jsonify({"ok": True, "enabled": enabled})

    @app.post("/api/accounts/start")
    def start_account():
        email = str(_payload().get("email", "")).lower()
        account = get_account(email)
        if not account:
            raise KeyError("Account is not registered.")
        settings = {**account.get("settings", {}), "enabled": True}
        upsert_account(email, settings=settings, last_result="Automatic cleanup enabled", error="")
        scheduler.wake()
        schedule_text = (
            f"End of day at {settings.get('end_of_day_time', '23:00')}"
            if settings.get("schedule_mode") == "end_of_day"
            else f"Every {settings.get('every_hours', 1)} hour(s)"
        )
        _write_activity(email, "START AUTOMATION", "SUCCESS", schedule_text)
        return jsonify({"ok": True})

    @app.post("/api/accounts/stop")
    def stop_account():
        email = str(_payload().get("email", "")).lower()
        account = get_account(email)
        if not account:
            raise KeyError("Account is not registered.")
        settings = {**account.get("settings", {}), "enabled": False}
        upsert_account(email, settings=settings, last_result="Automatic cleanup stopped")
        scheduler.cancel_account(email)
        _write_activity(email, "STOP AUTOMATION", "SUCCESS", "Future runs disabled.")
        return jsonify({"ok": True})

    @app.delete("/api/accounts/remove")
    def remove():
        data = _payload()
        email = str(data.get("email", "")).lower()
        if str(data.get("confirmation", "")) != f"REMOVE {email}":
            raise ValueError("Confirmation text did not match.")
        scheduler.cancel_account(email)
        removed = remove_account(email)
        _write_activity(email, "REMOVE ACCOUNT", "SUCCESS" if removed else "NOT FOUND", "Local token and dashboard record removed.")
        return jsonify({"ok": True, "removed": removed})

    @app.get("/api/candidates")
    def candidates():
        email = str(request.args.get("email", "")).lower()
        candidate_type = str(request.args.get("type", "large"))
        from_date = str(request.args.get("from_date", ""))
        to_date = str(request.args.get("to_date", ""))
        if email != "__all__":
            return jsonify({
                "ok": True,
                **list_candidates(email, candidate_type, from_date=from_date, to_date=to_date),
            })

        accounts = visible_accounts()
        if not accounts:
            raise ValueError("Connect a Gmail account first.")
        items: list[dict[str, Any]] = []
        errors: list[str] = []
        results: list[dict[str, Any]] = []
        with ThreadPoolExecutor(max_workers=min(3, len(accounts))) as pool:
            futures = {
                pool.submit(list_candidates, row["email"], candidate_type, 100, from_date, to_date): row["email"]
                for row in accounts
            }
            for future in as_completed(futures):
                account_email = futures[future]
                try:
                    result = future.result()
                    results.append(result)
                    for item in result.get("items", []):
                        item["account"] = account_email
                        items.append(item)
                except Exception as exc:
                    errors.append(f"{account_email}: {exc}")
        items.sort(key=lambda row: str(row.get("date", "")), reverse=True)
        items = items[:300]
        return jsonify({
            "ok": True,
            "type": candidate_type,
            "query": "all connected Gmail accounts",
            "estimate": sum(int(row.get("estimate", 0) or 0) for row in results),
            "shown": len(items),
            "permanent": candidate_type in {"trash", "spam"},
            "allow_cleanup": any(bool(row.get("allow_cleanup")) for row in results) if results else True,
            "guard_enabled": any(bool(row.get("guard_enabled")) for row in results),
            "mixed_guard": len({bool(row.get("guard_enabled")) for row in results}) > 1,
            "from_date": from_date,
            "to_date": to_date,
            "errors": errors,
            "items": items,
        })

    @app.get("/api/search")
    def search_all_mail():
        query = str(request.args.get("q", "")).strip()
        requested_email = str(request.args.get("email", "__all__")).strip().lower()
        attachments_only = str(request.args.get("attachments_only", "0")).lower() in {"1", "true", "yes"}
        from_date = str(request.args.get("from_date", "")).strip()
        to_date = str(request.args.get("to_date", "")).strip()
        rows = visible_accounts()
        if requested_email and requested_email != "__all__":
            rows = [row for row in rows if row.get("email", "").lower() == requested_email]
        if not rows:
            raise ValueError("No connected Gmail account matches this search.")
        items: list[dict[str, Any]] = []
        errors: list[str] = []
        estimates = 0
        with ThreadPoolExecutor(max_workers=min(3, len(rows))) as pool:
            futures = {pool.submit(search_messages, row["email"], query, 80, attachments_only, from_date, to_date): row["email"] for row in rows}
            for future in as_completed(futures):
                account_email = futures[future]
                try:
                    result = future.result()
                    estimates += int(result.get("estimate", 0) or 0)
                    items.extend(result.get("items", []))
                except Exception as exc:
                    errors.append(f"{account_email}: {exc}")
        items.sort(key=lambda row: str(row.get("date", "")), reverse=True)
        items = items[:300]
        _write_activity(requested_email if requested_email != "__all__" else "ALL GMAIL", "SEARCH", "SUCCESS", {"query": query, "shown": len(items), "attachment_only": attachments_only, "from_date": from_date, "to_date": to_date})
        return jsonify({"ok": True, "query": query, "estimate": estimates, "shown": len(items), "from_date": from_date, "to_date": to_date, "errors": errors, "items": items})

    @app.post("/api/candidates/trash")
    def trash_selected():
        data = _payload()
        email = str(data.get("email", "")).lower()
        result = move_selected_to_trash(email, data.get("ids", []))
        _write_activity(email, "MOVE SELECTED TO TRASH", "SUCCESS", {**result, "ids": list(dict.fromkeys(map(str, data.get("ids", []))))[:100]})
        return jsonify({"ok": True, **result})

    @app.post("/api/candidates/not-spam")
    def restore_selected_from_spam():
        data = _payload()
        email = str(data.get("email", "")).lower()
        result = mark_selected_not_spam(email, data.get("ids", []))
        _write_activity(email, "MARK SELECTED NOT SPAM", "SUCCESS", result)
        return jsonify({"ok": True, **result})

    @app.post("/api/candidates/permanent")
    def delete_selected():
        data = _payload()
        email = str(data.get("email", "")).lower()
        result = permanently_delete(
            email,
            str(data.get("folder", "")),
            permanent_phrase(email),
            selected_ids=data.get("ids", []),
        )
        _write_activity(email, "PERMANENT DELETE SELECTED", result["status"], result)
        return jsonify({"ok": True, **result})

    @app.post("/api/purge")
    def purge():
        data = _payload()
        email = str(data.get("email", "")).lower()
        result = permanently_delete(
            email,
            str(data.get("folder", "")),
            permanent_phrase(email),
            selected_ids=None,
        )
        _write_activity(email, "PERMANENTLY EMPTY FOLDER", result["status"], result)
        return jsonify({"ok": True, **result})

    @app.post("/api/messages/action")
    def message_action():
        data = _payload()
        email = str(data.get("email", "")).lower()
        action = str(data.get("action", "")).lower()
        ids = list(dict.fromkeys(map(str, data.get("ids", []))))[:100]
        if not ids:
            raise ValueError("Select at least one message.")
        if not get_account(email):
            raise KeyError("Account is not registered.")
        from .google_client import services_for
        from .cleaner import retry
        gmail, _ = services_for(email)
        if action == "trash":
            result = move_selected_to_trash(email, ids)
            _write_activity(email, "MOVE SELECTED TO TRASH", "SUCCESS", {**result, "ids": ids})
            return jsonify({"ok": True, **result})
        labels_add, labels_remove = [], []
        label = ""
        if action == "archive":
            labels_remove = ["INBOX"]
            label = "ARCHIVE"
        elif action == "mark_read":
            labels_remove = ["UNREAD"]
            label = "MARK READ"
        elif action == "restore":
            labels_add, labels_remove = ["INBOX"], ["TRASH"]
            label = "RESTORE"
        else:
            raise ValueError("Unsupported message action.")
        for offset in range(0, len(ids), 100):
            batch = ids[offset:offset+100]
            retry(lambda values=batch: gmail.users().messages().batchModify(userId="me", body={"ids": values, "addLabelIds": labels_add, "removeLabelIds": labels_remove}).execute())
        _write_activity(email, label, "SUCCESS", {"count": len(ids), "ids": ids})
        return jsonify({"ok": True, "count": len(ids)})

    @app.get("/api/undo")
    def undo_list():
        rows = []
        for row in _recent_activity(200):
            details = row.get("details") if isinstance(row.get("details"), dict) else {}
            ids = details.get("ids") if isinstance(details, dict) else None
            if row.get("action") == "MOVE SELECTED TO TRASH" and isinstance(ids, list) and ids:
                rows.append({"time": row.get("time"), "email": row.get("email"), "count": int(details.get("moved", len(ids)) or len(ids)), "ids": ids})
            if len(rows) >= 25:
                break
        return jsonify({"ok": True, "items": rows})

    @app.get("/api/attachments")
    def attachment_explorer():
        requested_email = str(request.args.get("email", "__all__")).lower()
        kind = str(request.args.get("kind", "all")).lower()
        order = str(request.args.get("order", "largest")).lower()
        rows = visible_accounts()
        if requested_email != "__all__":
            rows = [r for r in rows if r.get("email", "").lower() == requested_email]
        if not rows:
            raise ValueError("No connected Gmail account matches this attachment view.")
        query_map = {
            "pdf": "has:attachment filename:pdf", "image": "has:attachment {filename:jpg filename:jpeg filename:png filename:webp filename:gif}",
            "excel": "has:attachment {filename:xls filename:xlsx filename:csv}", "word": "has:attachment {filename:doc filename:docx}",
            "zip": "has:attachment {filename:zip filename:rar filename:7z}", "video": "has:attachment {filename:mp4 filename:mov filename:avi filename:mkv}"
        }
        query = query_map.get(kind, "has:attachment")
        all_items=[]; errors=[]
        with ThreadPoolExecutor(max_workers=min(3, len(rows))) as pool:
            futures={pool.submit(search_messages, r["email"], query, 100, True, "", ""):r["email"] for r in rows}
            for future in as_completed(futures):
                email=futures[future]
                try:
                    result=future.result(); all_items.extend(result.get("items", []))
                except Exception as exc:
                    errors.append(f"{email}: {exc}")
        if order == "oldest": all_items.sort(key=lambda x: str(x.get("date", "")))
        elif order == "newest": all_items.sort(key=lambda x: str(x.get("date", "")), reverse=True)
        elif order == "sender": all_items.sort(key=lambda x: str(x.get("from", "")).lower())
        elif order == "type": all_items.sort(key=lambda x: str((x.get("attachments") or [{}])[0].get("mime", "")))
        else: all_items.sort(key=lambda x: int(x.get("size_bytes", 0) or 0), reverse=True)
        return jsonify({"ok": True, "items": all_items[:300], "errors": errors})

    return app
