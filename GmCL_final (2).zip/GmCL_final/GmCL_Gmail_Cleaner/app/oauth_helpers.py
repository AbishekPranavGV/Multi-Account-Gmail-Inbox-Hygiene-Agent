from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class OAuthConfigError(RuntimeError):
    pass


def load_desktop_oauth_config(path: Path) -> dict[str, Any]:
    """Load and sanitize a Google Desktop OAuth JSON before opening a browser.

    This prevents malformed authorization requests caused by accidentally using
    a Web/Android/iOS credential file or a damaged/edited JSON.
    """
    try:
        raw = json.loads(path.read_text(encoding="utf-8-sig"))
    except OSError as exc:
        raise OAuthConfigError("Google Desktop OAuth file is missing. Run setup and add the downloaded Desktop app JSON.") from exc
    except json.JSONDecodeError as exc:
        raise OAuthConfigError("Google OAuth JSON is damaged or invalid. Download a fresh Desktop app OAuth JSON from Google Cloud.") from exc

    installed = raw.get("installed")
    if not isinstance(installed, dict):
        kind = "Web application" if isinstance(raw.get("web"), dict) else "non-Desktop"
        raise OAuthConfigError(f"Wrong Google OAuth credential type ({kind}). Create an OAuth Client ID with Application type: Desktop app.")

    client_id = str(installed.get("client_id") or "").strip()
    client_secret = str(installed.get("client_secret") or "").strip()
    if not client_id.endswith(".apps.googleusercontent.com") or not client_secret:
        raise OAuthConfigError("Google Desktop OAuth JSON is incomplete. Download a fresh Desktop app OAuth JSON from Google Cloud.")

    # Use Google's current standard endpoints even if an old JSON was edited or
    # contains legacy endpoint values. Keep only fields needed by InstalledAppFlow.
    return {
        "installed": {
            "client_id": client_id,
            "project_id": str(installed.get("project_id") or "gmcl-desktop"),
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
            "client_secret": client_secret,
            "redirect_uris": ["http://localhost"],
        }
    }
