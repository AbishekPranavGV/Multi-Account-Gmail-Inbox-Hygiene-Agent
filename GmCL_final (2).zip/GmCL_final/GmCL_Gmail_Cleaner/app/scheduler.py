from __future__ import annotations

import logging
import threading
from datetime import datetime, timedelta, timezone

from .cleaner import clean_promotions_social, permanently_delete, scan_account
from .store import get_account, list_accounts, upsert_account

LOGGER = logging.getLogger("gmcl.scheduler")


def _parse(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value)
    except ValueError:
        return None


def _end_of_day_parts(value: str | None) -> tuple[int, int]:
    raw = str(value or "23:00").strip()
    try:
        hour_text, minute_text = raw.split(":", 1)
        hour, minute = int(hour_text), int(minute_text)
    except (ValueError, TypeError):
        return 23, 0
    if not 0 <= hour <= 23 or not 0 <= minute <= 59:
        return 23, 0
    return hour, minute


def is_due(account: dict, now: datetime | None = None) -> bool:
    settings = account.get("settings", {})
    if not settings.get("enabled", False):
        return False
    # A revoked/expired Google refresh token needs one interactive login. Keep
    # the user's automation setting ON, but stop noisy repeat failures until the
    # account is reconnected.
    auth_error = str(account.get("error", "") or "").lower()
    if (account.get("auth_reconnect_required") or account.get("connection") == "RECONNECT"
            or "invalid_grant" in auth_error or "expired or revoked" in auth_error):
        return False

    if settings.get("schedule_mode", "interval") == "end_of_day":
        # Use the server PC's local timezone so "end of day" follows the office clock.
        local_now = now or datetime.now().astimezone()
        if local_now.tzinfo is None:
            local_now = local_now.astimezone()
        hour, minute = _end_of_day_parts(settings.get("end_of_day_time"))
        scheduled = local_now.replace(hour=hour, minute=minute, second=0, microsecond=0)
        if local_now < scheduled:
            return False
        today = local_now.date().isoformat()
        if account.get("last_eod_run_date") == today:
            return False
        # A failed run may retry, but not every scheduler minute.
        last_attempt = _parse(account.get("last_eod_attempt_at"))
        if last_attempt:
            try:
                attempt_local = last_attempt.astimezone(local_now.tzinfo)
                if attempt_local.date().isoformat() == today and local_now - attempt_local < timedelta(minutes=30):
                    return False
            except (TypeError, ValueError):
                pass
        return True

    utc_now_value = now or datetime.now(timezone.utc)
    last = _parse(account.get("last_cleanup"))
    return last is None or utc_now_value - last >= timedelta(hours=int(settings.get("every_hours", 1)))


class CleanupScheduler:
    def __init__(self) -> None:
        self._stop = threading.Event()
        self._wake = threading.Event()
        self._thread: threading.Thread | None = None
        self._account_cancel: dict[str, threading.Event] = {}

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._loop, name="gmail-cleanup-scheduler", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        self._wake.set()
        for event in self._account_cancel.values():
            event.set()

    def wake(self) -> None:
        self._wake.set()

    def cancel_account(self, email: str) -> None:
        self._account_cancel.setdefault(email.lower(), threading.Event()).set()

    def _loop(self) -> None:
        while not self._stop.is_set():
            for account in list_accounts():
                if self._stop.is_set():
                    break
                email = account.get("email", "")
                if not email or not is_due(account):
                    continue
                cancel = self._account_cancel.setdefault(email, threading.Event())
                cancel.clear()
                current_settings = account.get("settings", {})
                eod_mode = current_settings.get("schedule_mode", "interval") == "end_of_day"
                if eod_mode:
                    upsert_account(email, last_eod_attempt_at=datetime.now(timezone.utc).isoformat(timespec="seconds"))
                try:
                    result = clean_promotions_social(email, cancel)
                    if cancel.is_set() or self._stop.is_set() or result.get("status") in {"STOPPED", "SKIPPED"}:
                        continue
                    current = get_account(email) or account
                    settings = current.get("settings", {})
                    # End-of-day mode is intentionally Promotions + Social only.
                    # Keep the older permanent Trash purge behavior limited to interval mode.
                    if (
                        settings.get("enabled", False)
                        and settings.get("schedule_mode", "interval") != "end_of_day"
                        and settings.get("auto_purge_trash", False)
                        and not cancel.is_set()
                    ):
                        age = int(settings.get("trash_age_days", 30))
                        phrase = current.get("auto_purge_confirmation", "")
                        if phrase:
                            permanently_delete(
                                email,
                                "trash",
                                phrase,
                                selected_ids=None,
                                maximum=int(settings.get("max_per_run", 2000)),
                                older_than_days=age,
                                cancel=cancel,
                            )
                    if settings.get("schedule_mode", "interval") == "end_of_day" and result.get("status") == "COMPLETE":
                        local_now = datetime.now().astimezone()
                        upsert_account(email, last_eod_run_date=local_now.date().isoformat())
                    scan_account(email)
                except Exception as exc:
                    text = str(exc).lower()
                    quota_limited = any(token in text for token in (
                        "quota exceeded", "ratelimitexceeded", "user rate limit exceeded",
                        "units per minute per user", "usage limits",
                    ))
                    if quota_limited:
                        LOGGER.warning("Scheduled Gmail run is cooling down for %s: %s", email, exc)
                        upsert_account(email, last_result="API COOLING DOWN", error="")
                    else:
                        LOGGER.exception("Scheduled account run failed: %s", email)
                        upsert_account(email, last_result="SCHEDULED ERROR", error=str(exc))
            self._wake.wait(60)
            self._wake.clear()
