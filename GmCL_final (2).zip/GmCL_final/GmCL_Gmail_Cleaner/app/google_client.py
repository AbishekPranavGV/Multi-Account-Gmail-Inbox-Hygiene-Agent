from __future__ import annotations

import json
import threading
from typing import Any

from google.auth.exceptions import RefreshError
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build

from .config import CLIENT_SECRET, SCOPES
from .oauth_helpers import OAuthConfigError, load_desktop_oauth_config
from .store import load_token, save_token, token_path, upsert_account


class SetupError(RuntimeError):
    pass


def require_client_secret() -> None:
    try:
        load_desktop_oauth_config(CLIENT_SECRET)
    except OAuthConfigError as exc:
        raise SetupError(str(exc)) from exc


def _mark_reconnect_required(email: str, reason: str = "invalid_grant") -> SetupError:
    message = "Google login expired or was revoked. Login again once to reconnect this Gmail."
    upsert_account(
        email,
        connection="RECONNECT",
        error=message,
        last_result="LOGIN REQUIRED",
        auth_reconnect_required=True,
        auth_error_code=reason,
    )
    return SetupError(message)


def credentials_for(email: str) -> Credentials:
    raw = load_token(email)
    info = json.loads(raw)
    # Preserve the scopes that Google actually granted to this saved token.
    # Older accounts may have a valid Gmail authorization without the newer
    # optional Drive metadata scope. Forcing today's full SCOPES list during a
    # refresh can turn an otherwise-good Gmail login into an avoidable auth
    # error. Gmail is the required service; Drive statistics are optional.
    creds = Credentials.from_authorized_user_info(info)
    if creds.expired and creds.refresh_token:
        try:
            creds.refresh(Request())
        except RefreshError as exc:
            # Google uses invalid_grant when a refresh token has expired, was
            # revoked, or otherwise can no longer be refreshed. Do not keep
            # retrying a dead token every scheduler cycle; ask for one clean
            # re-login and keep the account/settings intact.
            text = str(exc).lower()
            if "invalid_grant" in text or "expired or revoked" in text:
                raise _mark_reconnect_required(email, "invalid_grant") from exc
            raise
        save_token(email, creds.to_json())
    if not creds.valid:
        raise _mark_reconnect_required(email, "invalid_credentials")
    return creds


_thread_cache = threading.local()


def services_for(email: str) -> tuple[Any, Any]:
    """Return per-thread cached Google service objects.

    google-api-python-client service objects are not safe to share across threads,
    so each worker thread keeps its own cache. Reusing them avoids rebuilding Gmail
    and Drive discovery clients for every dashboard action.
    """
    key = email.lower()
    cache = getattr(_thread_cache, "services", None)
    if cache is None:
        cache = {}
        _thread_cache.services = cache

    path = token_path(key)
    try:
        token_stamp = path.stat().st_mtime_ns
    except OSError:
        token_stamp = -1

    cached = cache.get(key)
    if cached and cached[0] == token_stamp:
        return cached[1], cached[2]

    creds = credentials_for(key)
    # credentials_for may refresh and rewrite the token, so capture the final stamp.
    try:
        token_stamp = path.stat().st_mtime_ns
    except OSError:
        token_stamp = -1
    gmail = build("gmail", "v1", credentials=creds, cache_discovery=False)
    drive = build("drive", "v3", credentials=creds, cache_discovery=False)
    cache[key] = (token_stamp, gmail, drive)
    return gmail, drive

