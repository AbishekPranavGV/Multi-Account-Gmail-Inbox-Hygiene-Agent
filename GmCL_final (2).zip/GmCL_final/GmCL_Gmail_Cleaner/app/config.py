from __future__ import annotations

import os
import platform
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LEGACY_DATA_DIR = ROOT / "data"

# Gmail authorizations and server identity must survive replacing/updating the ZIP.
# On Windows keep them in this Windows user's LocalAppData instead of inside the
# extracted program folder. GMCL_DATA_DIR remains available for advanced/admin use.
def _default_data_dir() -> Path:
    override = os.environ.get("GMCL_DATA_DIR", "").strip()
    if override:
        return Path(override).expanduser()
    if platform.system() == "Windows":
        local_app_data = os.environ.get("LOCALAPPDATA", "").strip()
        if local_app_data:
            return Path(local_app_data) / "GmCL" / "ServerData"
    return LEGACY_DATA_DIR


DATA_DIR = _default_data_dir()
TOKEN_DIR = DATA_DIR / "tokens"
CONFIG_DIR = ROOT / "config"
PERSISTENT_OAUTH_DIR = DATA_DIR / "oauth"
PERSISTENT_CLIENT_SECRET = PERSISTENT_OAUTH_DIR / "client_secret.json"
CONFIG_CLIENT_SECRET = CONFIG_DIR / "client_secret.json"


def _migrate_legacy_state() -> None:
    """Copy saved state from older ZIP-local installs once, without overwriting newer state."""
    if DATA_DIR == LEGACY_DATA_DIR or not LEGACY_DATA_DIR.exists():
        return
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    for name in (
        "accounts.json",
        "activity.jsonl",
        "network_access.key",
        "session_secret.key",
        "server_mode.enabled",
        "validated_version.txt",
    ):
        source = LEGACY_DATA_DIR / name
        target = DATA_DIR / name
        if source.is_file() and not target.exists():
            try:
                shutil.copy2(source, target)
            except OSError:
                pass
    # Preserve the Google Desktop OAuth client as well. This is not a Gmail
    # token, but keeping it outside the extracted ZIP prevents an upgrade from
    # unexpectedly asking the user to set Google Cloud credentials up again.
    legacy_oauth = LEGACY_DATA_DIR / "oauth" / "client_secret.json"
    if legacy_oauth.is_file() and not PERSISTENT_CLIENT_SECRET.exists():
        PERSISTENT_OAUTH_DIR.mkdir(parents=True, exist_ok=True)
        try:
            shutil.copy2(legacy_oauth, PERSISTENT_CLIENT_SECRET)
        except OSError:
            pass

    legacy_tokens = LEGACY_DATA_DIR / "tokens"
    if legacy_tokens.is_dir():
        TOKEN_DIR.mkdir(parents=True, exist_ok=True)
        for source in legacy_tokens.glob("*.token"):
            target = TOKEN_DIR / source.name
            if not target.exists():
                try:
                    shutil.copy2(source, target)
                except OSError:
                    pass


_migrate_legacy_state()

# Same-folder upgrades from v1.6.2 and earlier may already have a working
# config/client_secret.json. Seed the durable copy before choosing CLIENT_SECRET.
if CONFIG_CLIENT_SECRET.is_file() and not PERSISTENT_CLIENT_SECRET.exists():
    PERSISTENT_OAUTH_DIR.mkdir(parents=True, exist_ok=True)
    try:
        shutil.copy2(CONFIG_CLIENT_SECRET, PERSISTENT_CLIENT_SECRET)
    except OSError:
        pass

# Prefer the durable OAuth file once it exists. Smart-Setup keeps this file in
# sync with a newly supplied config/client_secret.json.
CLIENT_SECRET = PERSISTENT_CLIENT_SECRET if PERSISTENT_CLIENT_SECRET.exists() else CONFIG_CLIENT_SECRET
ACCOUNTS_FILE = DATA_DIR / "accounts.json"
LOG_FILE = DATA_DIR / "server.log"
ACTIVITY_FILE = DATA_DIR / "activity.jsonl"
PID_FILE = DATA_DIR / "server.pid"
LOCK_FILE = DATA_DIR / "server.lock"
NETWORK_ACCESS_KEY_FILE = DATA_DIR / "network_access.key"
SESSION_SECRET_FILE = DATA_DIR / "session_secret.key"
SERVER_MODE_FILE = DATA_DIR / "server_mode.enabled"
PORT = int(os.environ.get("GMCL_PORT", "8795"))
# Normal use remains localhost-only. MAKE_THIS_PC_SERVER.bat creates the server
# mode marker so auto-start and later launches listen on the office network.
HOST = os.environ.get(
    "GMCL_HOST",
    os.environ.get(
        "VELOCITYX_HOST",
        "0.0.0.0" if SERVER_MODE_FILE.exists() else "127.0.0.1",
    ),
)
LOCAL_BROWSER_HOST = "127.0.0.1"

SCOPES = [
    "https://mail.google.com/",
    "https://www.googleapis.com/auth/drive.metadata.readonly",
]

DEFAULT_SETTINGS = {
    "enabled": False,
    "business_guard_enabled": False,
    "min_age_days": 7,
    "protect_starred": True,
    "protect_important": True,
    "max_per_run": 2000,
    "every_hours": 1,
    "schedule_mode": "interval",
    "end_of_day_time": "23:00",
    "auto_purge_trash": False,
    "trash_age_days": 30,
}

CANDIDATE_QUERIES = {
    "large": "larger:10M -in:trash -in:spam -in:sent -in:drafts",
    "old_large": "older_than:2y larger:5M -in:trash -in:spam -in:sent -in:drafts",
    "promotions": "category:promotions -in:trash -in:spam -in:sent -in:drafts",
    "social": "category:social -in:trash -in:spam -in:sent -in:drafts",
    "trash": "in:trash",
    "spam": "in:spam",
}

for directory in (DATA_DIR, TOKEN_DIR, CONFIG_DIR, PERSISTENT_OAUTH_DIR):
    directory.mkdir(parents=True, exist_ok=True)
