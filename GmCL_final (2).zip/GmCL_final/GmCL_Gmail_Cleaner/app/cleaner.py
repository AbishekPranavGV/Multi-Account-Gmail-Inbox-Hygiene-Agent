from __future__ import annotations

import logging
import re
import threading
import time
from datetime import datetime, timezone, timedelta
from typing import Any, Callable
from concurrent.futures import ThreadPoolExecutor

from googleapiclient.errors import HttpError

from .config import CANDIDATE_QUERIES, DEFAULT_SETTINGS
from .google_client import services_for
from .store import get_account, upsert_account, utc_now

LOGGER = logging.getLogger("gmcl.cleaner")


# Business Mail Guard -------------------------------------------------------
# GmCL deliberately uses conservative, explainable rules. Business indicators
# always win over cleanup indicators; uncertainty is REVIEW, never auto-delete.
BUSINESS_TERM_GROUPS = {
    "Lead / enquiry": ("enquiry", "inquiry", "requirement", "interested in", "need price", "looking for", "please quote", "send price", "best price", "rfq", "request for quotation"),
    "Quotation / pricing": ("quotation", "quote", "pricing", "commercial offer", "techno-commercial", "proposal", "dealer price", "distributor price"),
    "Order": ("purchase order", "order confirmation", "sales order", "order placed", "order acknowledgement", " po/", " po "),
    "Invoice / accounts": ("invoice", "tax invoice", "gst", "proforma invoice", "debit note", "credit note", "payment", "payment advice", "bank transfer", "remittance"),
    "Supplier": ("stock", "availability", "lead time", "delivery", "dispatch", "catalogue", "catalog", "datasheet", "specification", "technical details"),
    "Service": ("complaint", "service request", "repair", "warranty", "calibration", "breakdown", "installation", " amc ", "support"),
    "Recruiting": ("job application", "new application", "candidate", "resume", "curriculum vitae", "interview", "hiring", "recruitment"),
}
LEAD_TERMS = (
    "enquiry", "inquiry", "requirement", "interested in", "need price", "looking for",
    "please quote", "send price", "best price", "rfq", "request for quotation", "availability",
)
SAFE_CLEAN_TERMS = (
    "unsubscribe", "manage preferences", "email preferences", "view in browser",
    "newsletter", "weekly digest", "daily digest", "monthly digest", "promotional",
    "flash sale", "summer sale", "special sale", "coupon", "promo code", "limited time sale",
    "you appeared in", "people you may know", "new connection", "friend request",
    "activity report", "monthly activity", "notification summary", "security code",
    "verification code", "one-time password", "one time password", " otp ",
    "delivery status notification", "mail delivery failed", "undelivered mail returned to sender", "failure notice",
)
SAFE_SENDER_HINTS = (
    "facebookmail.com", "facebook.com", "linkedin.com", "youtube.com", "googlealerts-noreply",
    "notifications@", "newsletter@", "news@", "marketing@", "offers@", "promo@",
)

def _gmail_terms(terms: tuple[str, ...]) -> str:
    values = []
    for term in terms:
        term = term.strip()
        if not term or len(term) <= 2:
            # Very short tokens such as PO are too broad for a Gmail-wide search.
            # Longer phrases such as "purchase order" still cover the business intent.
            continue
        values.append(f'"{term}"' if " " in term else term)
    return "{" + " ".join(values) + "}"


def _contains_term(text: str, term: str) -> bool:
    token = term.strip().lower()
    if not token:
        return False
    if token.isalnum() and len(token) <= 4:
        return re.search(r"(?<![a-z0-9])" + re.escape(token) + r"(?![a-z0-9])", text) is not None
    return token in text

BUSINESS_QUERY = "-in:trash -in:spam -in:sent -in:drafts " + _gmail_terms(
    tuple(dict.fromkeys(term.strip() for group in BUSINESS_TERM_GROUPS.values() for term in group if term.strip()))
)
MISSED_LEAD_QUERY = "is:unread newer_than:90d -in:trash -in:spam -in:sent -in:drafts " + _gmail_terms(LEAD_TERMS)


def _safe_signal_query(settings: dict[str, Any]) -> str:
    settings = {**DEFAULT_SETTINGS, **(settings or {})}
    query = "{category:promotions category:social} -in:trash -in:spam -in:sent -in:drafts " + _gmail_terms(SAFE_CLEAN_TERMS)
    age = int(settings.get("min_age_days", 0))
    if age:
        query += f" older_than:{age}d"
    if settings.get("protect_starred", True):
        query += " -is:starred"
    if settings.get("protect_important", True):
        query += " -is:important"
    return query


def _message_headers(message: dict[str, Any]) -> dict[str, str]:
    return {
        str(header.get("name", "")).lower(): str(header.get("value", ""))
        for header in message.get("payload", {}).get("headers", [])
    }


def _attachment_names(part: dict[str, Any]) -> list[str]:
    names: list[str] = []
    filename = str(part.get("filename", "") or "").strip()
    if filename:
        names.append(filename)
    for child in part.get("parts", []) or []:
        if isinstance(child, dict):
            names.extend(_attachment_names(child))
    return names


def classify_message(message: dict[str, Any], replied: bool = False) -> dict[str, Any]:
    """Return an explainable Business Mail Guard decision for one Gmail message."""
    labels = set(message.get("labelIds", []))
    headers = _message_headers(message)
    subject = headers.get("subject", "")
    sender = headers.get("from", "")
    snippet = str(message.get("snippet", "") or "")
    attachments = " ".join(_attachment_names(message.get("payload", {}) or {}))
    text = f" {subject} {sender} {snippet} {attachments} ".lower()

    if "STARRED" in labels:
        return {"state": "PROTECTED", "safe_score": 5, "reason": "Starred message", "detection": "Protected"}
    if "IMPORTANT" in labels:
        return {"state": "PROTECTED", "safe_score": 8, "reason": "Gmail Important label", "detection": "Protected"}
    if replied:
        return {"state": "PROTECTED", "safe_score": 8, "reason": "Your company replied in this conversation", "detection": "Conversation"}

    hits: list[str] = []
    detection = "Business mail"
    for group, terms in BUSINESS_TERM_GROUPS.items():
        group_hits = [term.strip() for term in terms if _contains_term(text, term)]
        if group_hits:
            hits.extend(group_hits[:3])
            if group == "Lead / enquiry":
                detection = "Possible lead"
            elif detection != "Possible lead":
                detection = group
    if hits:
        unread = "UNREAD" in labels
        score = 4 if unread and detection == "Possible lead" else 15
        reason = detection + ": " + ", ".join(list(dict.fromkeys(hits))[:3])
        return {"state": "PROTECTED", "safe_score": score, "reason": reason, "detection": detection}

    safe_hits = [term.strip() for term in SAFE_CLEAN_TERMS if _contains_term(text, term)]
    sender_low = sender.lower()
    sender_safe = [hint for hint in SAFE_SENDER_HINTS if hint in sender_low]
    category_social = "CATEGORY_SOCIAL" in labels
    category_promotions = "CATEGORY_PROMOTIONS" in labels
    attachment_list = _attachment_names(message.get("payload", {}) or {})
    important_ext = (".pdf", ".zip", ".xlsx", ".xls", ".csv", ".doc", ".docx", ".ppt", ".pptx")
    has_business_document = any(name.lower().endswith(important_ext) for name in attachment_list)
    very_large = int(message.get("sizeEstimate", 0) or 0) >= 10 * 1024 * 1024
    if (has_business_document or very_large) and (safe_hits or sender_safe):
        reason = "Attachment requires review before cleanup"
        if attachment_list:
            reason += ": " + ", ".join(attachment_list[:2])
        return {"state": "REVIEW", "safe_score": 74, "reason": reason, "detection": "Attachment review"}

    if safe_hits:
        reason = "Low-value automation signal: " + ", ".join(list(dict.fromkeys(safe_hits))[:2])
        return {"state": "SAFE TO CLEAN", "safe_score": 96, "reason": reason, "detection": "Low-value"}
    if sender_safe and (category_social or category_promotions):
        return {"state": "SAFE TO CLEAN", "safe_score": 94, "reason": "Known notification/marketing sender in Gmail category", "detection": "Notification"}
    if "SPAM" in labels:
        return {"state": "SAFE TO CLEAN", "safe_score": 92, "reason": "Gmail Spam label; manual review still required", "detection": "Spam"}

    return {
        "state": "REVIEW",
        "safe_score": 72,
        "reason": "Business intent is uncertain; GmCL will not auto-clean this message",
        "detection": "Needs review",
    }


def _thread_has_company_reply(gmail: Any, thread_id: str | None) -> bool:
    if not thread_id:
        return False
    users = gmail.users()
    threads_method = getattr(users, "threads", None)
    if not callable(threads_method):
        return False
    try:
        thread = retry(
            lambda: threads_method().get(
                userId="me", id=thread_id, format="minimal", fields="messages/labelIds"
            ).execute()
        )
    except Exception as exc:
        LOGGER.debug("Thread reply check skipped for %s: %s", thread_id, exc)
        return False
    return any("SENT" in set(row.get("labelIds", [])) for row in thread.get("messages", []))
_account_locks: dict[str, threading.Lock] = {}
_locks_guard = threading.Lock()
_API_EXECUTOR = ThreadPoolExecutor(max_workers=8, thread_name_prefix="gmcl-api")

# Gmail messages.get is relatively expensive in quota units.  Preview/search tools
# can request many messages very quickly, so pace those GETs per Gmail account.
# This does not slow the Promotions/Social cleaner because that path uses
# messages.list + batchModify and does not fetch every message individually.
_MESSAGE_GET_MIN_INTERVAL = 0.075
_message_get_guard = threading.Lock()
_message_get_next_at: dict[str, float] = {}


def _account_lock(email: str) -> threading.Lock:
    with _locks_guard:
        return _account_locks.setdefault(email.lower(), threading.Lock())


def _wait_for_message_get_slot(email: str) -> None:
    key = email.lower().strip()
    with _message_get_guard:
        now = time.monotonic()
        slot = max(now, _message_get_next_at.get(key, now))
        _message_get_next_at[key] = slot + _MESSAGE_GET_MIN_INTERVAL
    delay = slot - now
    if delay > 0:
        time.sleep(delay)


def _quota_limited(exc: Exception) -> bool:
    if not isinstance(exc, HttpError):
        text = str(exc).lower()
        return "quota exceeded" in text or "ratelimitexceeded" in text or "user rate limit exceeded" in text
    status = int(getattr(exc.resp, "status", 0) or 0)
    if status not in {403, 429}:
        return False
    text = str(exc).lower()
    return any(token in text for token in (
        "quota exceeded", "ratelimitexceeded", "userratelimitexceeded",
        "user rate limit exceeded", "rate limit exceeded", "usage limits",
    ))


def _transient(exc: Exception) -> bool:
    if _quota_limited(exc):
        return True
    if isinstance(exc, HttpError):
        return getattr(exc.resp, "status", 0) in {429, 500, 502, 503, 504}
    text = str(exc).lower()
    return any(token in text for token in ("rate limit", "backenderror", "service unavailable", "internal error"))


def _retry_after_seconds(exc: Exception, attempt: int) -> float:
    if _quota_limited(exc):
        # Gmail may report per-user quota exhaustion as HTTP 403 rather than 429.
        # Respect Retry-After when supplied; otherwise cool down long enough for
        # the rolling per-minute window to recover instead of hammering the API.
        headers = getattr(getattr(exc, "resp", None), "headers", {}) or {}
        raw = headers.get("retry-after") or headers.get("Retry-After")
        try:
            if raw is not None:
                return max(2.0, min(60.0, float(raw)))
        except (TypeError, ValueError):
            pass
        return min(30.0, 4.0 * (2 ** attempt))
    return min(8.0, 0.5 * (2 ** attempt))


def retry(call: Callable[[], Any], attempts: int = 6) -> Any:
    for attempt in range(attempts):
        try:
            return call()
        except Exception as exc:
            if not _transient(exc) or attempt == attempts - 1:
                raise
            delay = _retry_after_seconds(exc, attempt)
            if _quota_limited(exc):
                LOGGER.warning("Gmail API quota cooling down for %.1f seconds: %s", delay, exc)
            time.sleep(delay)
    raise RuntimeError("Unreachable retry state")


def format_bytes(value: int | float | None) -> str:
    number = float(value or 0)
    for unit in ("B", "KB", "MB", "GB", "TB", "PB"):
        if number < 1024 or unit == "PB":
            return f"{number:.0f} {unit}" if unit == "B" else f"{number:.2f} {unit}"
        number /= 1024
    return "0 B"


def cleanup_query(settings: dict[str, Any]) -> str:
    # Promotions + Social cleanup is intentionally absolute. The owner requested
    # every real Gmail message currently classified in either category to be
    # moved to recoverable Trash, including new, starred and Important mail.
    # Business Mail Guard and age/label preferences remain available for the
    # review/permanent-delete tools, but they do not reduce this category clean.
    return "{category:promotions category:social} -in:trash -in:spam -in:sent -in:drafts"


def snapshot_ids(service: Any, query: str, maximum: int) -> list[str]:
    ids: list[str] = []
    seen: set[str] = set()
    page_token: str | None = None
    while len(ids) < maximum:
        kwargs: dict[str, Any] = {
            "userId": "me",
            "q": query,
            "maxResults": min(500, maximum - len(ids)),
        }
        if page_token:
            kwargs["pageToken"] = page_token
        result = retry(lambda: service.users().messages().list(**kwargs).execute())
        added = 0
        for item in result.get("messages", []):
            message_id = str(item.get("id", ""))
            if message_id and message_id not in seen:
                seen.add(message_id)
                ids.append(message_id)
                added += 1
        page_token = result.get("nextPageToken")
        if not page_token or added == 0:
            break
    return ids


def count_query(service: Any, query: str) -> int:
    result = retry(
        lambda: service.users().messages().list(userId="me", q=query, maxResults=1).execute()
    )
    return int(result.get("resultSizeEstimate", len(result.get("messages", []))))


def _parallel_message_gets(
    email: str,
    ids: list[str],
    *,
    format_name: str,
    fields: str,
    metadata_headers: list[str] | None = None,
    workers: int = 8,
) -> list[tuple[str, dict[str, Any] | None]]:
    """Fetch message metadata concurrently while keeping one API client per worker thread."""
    if not ids:
        return []

    def fetch(message_id: str) -> tuple[str, dict[str, Any] | None]:
        gmail, _ = services_for(email)
        kwargs: dict[str, Any] = {
            "userId": "me",
            "id": message_id,
            "format": format_name,
            "fields": fields,
        }
        if metadata_headers:
            kwargs["metadataHeaders"] = metadata_headers
        try:
            _wait_for_message_get_slot(email)
            message = retry(lambda: gmail.users().messages().get(**kwargs).execute())
            return message_id, message
        except HttpError as exc:
            if getattr(exc.resp, "status", 0) == 404:
                return message_id, None
            raise

    # Reuse a process-wide executor so worker threads (and their per-thread Google
    # service caches) survive between Analyze/Preview/Clean operations.
    return list(_API_EXECUTOR.map(fetch, ids))


def _parallel_counts(email: str, queries: dict[str, str], workers: int = 2) -> dict[str, int]:
    """Count Gmail queries with small, quota-safe concurrency per account."""
    items = list(queries.items())
    if not items:
        return {}

    def run(item: tuple[str, str]) -> tuple[str, int]:
        name, query = item
        gmail, _ = services_for(email)
        return name, count_query(gmail, query)

    with ThreadPoolExecutor(max_workers=min(max(1, workers), len(items)), thread_name_prefix="gmcl-count") as pool:
        return dict(pool.map(run, items))


def _eligible_category(message: dict[str, Any], settings: dict[str, Any], now_ms: int) -> bool:
    labels = set(message.get("labelIds", []))
    if not labels.intersection({"CATEGORY_PROMOTIONS", "CATEGORY_SOCIAL"}):
        return False
    if labels.intersection({"TRASH", "SPAM", "SENT", "DRAFT"}):
        return False
    if settings.get("protect_starred", True) and "STARRED" in labels:
        return False
    if settings.get("protect_important", True) and "IMPORTANT" in labels:
        return False
    age = int(settings.get("min_age_days", 0))
    if age:
        internal_date = int(message.get("internalDate", 0) or 0)
        if not internal_date or internal_date >= now_ms - age * 86_400_000:
            return False
    return True


def scan_account(email: str) -> dict[str, Any]:
    gmail, drive = services_for(email)
    profile = retry(lambda: gmail.users().getProfile(userId="me").execute())
    actual_email = str(profile.get("emailAddress", "")).lower()
    if actual_email != email.lower():
        raise RuntimeError(f"Authorization account mismatch: expected {email}, received {actual_email}.")

    drive_warning = ""
    drive_available = True
    try:
        storage_quota = retry(
            lambda: drive.about().get(fields="storageQuota").execute()
        ).get("storageQuota", {})
    except Exception as exc:
        # Gmail cleanup is the core function. Google Workspace administrators can
        # disable Drive, older saved Gmail tokens may not include the optional
        # Drive metadata scope, and Drive can also be temporarily unavailable.
        # Because the Gmail profile above has already succeeded, none of those
        # Drive-only conditions should turn a healthy Gmail account into ANALYZE
        # ERROR or stop Promotions/Social cleanup.
        storage_quota = {}
        drive_available = False
        status = getattr(getattr(exc, "resp", None), "status", 0)
        text = str(exc).lower()
        if status in (401, 403) or "insufficient" in text or "scope" in text:
            drive_warning = "Google Drive storage access is unavailable for this account. Gmail cleaning is connected and will continue normally."
        elif status:
            drive_warning = f"Google Drive storage check is temporarily unavailable (HTTP {status}). Gmail cleaning is connected and will continue normally."
        else:
            drive_warning = "Google Drive storage check is temporarily unavailable. Gmail cleaning is connected and will continue normally."
        LOGGER.warning("Optional Drive storage check failed for %s: %s", email, exc)
    usage = int(storage_quota.get("usage", 0) or 0)
    drive_usage = int(storage_quota.get("usageInDrive", 0) or 0)
    drive_trash = int(storage_quota.get("usageInDriveTrash", 0) or 0)
    limit_raw = storage_quota.get("limit")
    limit_bytes = int(limit_raw) if limit_raw not in (None, "") else None
    settings = (get_account(email) or {}).get("settings", DEFAULT_SETTINGS)
    queries = {
        "promotions": "category:promotions -in:trash -in:spam -in:sent -in:drafts",
        "social": "category:social -in:trash -in:spam -in:sent -in:drafts",
        "trash": "in:trash",
        "large": CANDIDATE_QUERIES["large"],
        "old_large": CANDIDATE_QUERIES["old_large"],
        # Raw candidates are useful for audit, but automatic cleanup now requires
        # a high-confidence low-value signal after Business Mail Guard checks.
        "ready_to_clean": cleanup_query(settings),
        "safe_to_clean": _safe_signal_query(settings),
        "business_protected": BUSINESS_QUERY,
        "missed_leads": MISSED_LEAD_QUERY,
    }
    counts = _parallel_counts(email, queries)

    # The old build fetched up to 50 Trash messages only to estimate their size,
    # but that value is not shown anywhere in the UI. Skip those extra API calls.
    trash_sample_ids: list[str] = []
    trash_sample_bytes = 0

    storage = {
        "available": drive_available,
        "warning": drive_warning,
        "usage_bytes": usage if drive_available else None,
        "limit_bytes": limit_bytes if drive_available else None,
        "used_percent": (usage / limit_bytes) if drive_available and limit_bytes else None,
        "drive_bytes": drive_usage if drive_available else None,
        "drive_trash_bytes": drive_trash if drive_available else None,
        "other_services_bytes": max(0, usage - drive_usage) if drive_available else None,
        "usage_display": format_bytes(usage) if drive_available else "Drive API unavailable",
        "limit_display": (
            format_bytes(limit_bytes) if limit_bytes else "Unlimited / pooled"
        ) if drive_available else "—",
        "drive_display": format_bytes(drive_usage) if drive_available else "—",
        "drive_trash_display": format_bytes(drive_trash) if drive_available else "—",
        "other_services_display": format_bytes(max(0, usage - drive_usage)) if drive_available else "—",
        "scope_note": (
            drive_warning
            if not drive_available
            else (
                "Total Google storage across services."
                if limit_bytes
                else "The API did not return an individual limit; this may be unlimited or organization-pooled storage."
            )
        ),
    }
    stats = {
        "last_scan": utc_now(),
        "gmail_messages": int(profile.get("messagesTotal", 0) or 0),
        "counts": counts,
        "storage": storage,
        "trash_sample": {
            "messages_sampled": len(trash_sample_ids),
            "bytes": trash_sample_bytes,
            "display": "Not sampled",
            "is_complete": counts["trash"] == 0,
            "skipped_for_speed": True,
        },
    }
    upsert_account(
        email,
        connection="CONNECTED",
        last_seen=utc_now(),
        stats=stats,
        last_result=(
            "Analysis completed"
            if drive_available
            else "Analysis completed; Drive storage unavailable"
        ),
        error="",
    )
    return stats


def clean_promotions_social(email: str, cancel: threading.Event | None = None) -> dict[str, Any]:
    """Move every real Promotions/Social message to recoverable Gmail Trash.

    This operation deliberately ignores age, Starred/Important protection and
    Business Mail Guard for these two Gmail categories only. It keeps pulling
    fresh batches until Gmail reports no matching messages, so a run is not
    capped by max_per_run. Other folders and permanent-delete tools are unchanged.
    """
    lock = _account_lock(email)
    if not lock.acquire(blocking=False):
        return {
            "status": "SKIPPED", "moved": 0, "skipped": 0, "protected": 0,
            "review": 0, "message": "This account is already running."
        }
    try:
        account = get_account(email)
        if not account:
            raise KeyError(f"Account is not registered: {email}")
        settings = {**DEFAULT_SETTINGS, **account.get("settings", {})}
        gmail, _ = services_for(email)
        profile = retry(lambda: gmail.users().getProfile(userId="me").execute())
        if str(profile.get("emailAddress", "")).lower() != email.lower():
            raise RuntimeError("Saved authorization belongs to a different Gmail account.")

        query = cleanup_query(settings)
        moved = 0
        skipped = 0
        status = "COMPLETE"
        previous_signature: tuple[str, ...] | None = None
        repeated_same_batch = 0

        # Re-query after each 500-message pass. This is safer than paging through
        # a mailbox while simultaneously changing its labels and guarantees that
        # mailboxes with more than the old 2,000-message run limit are drained.
        while True:
            if cancel and cancel.is_set():
                status = "STOPPED"
                break

            ids = snapshot_ids(gmail, query, 500)
            if not ids:
                break

            signature = tuple(ids)
            if signature == previous_signature:
                repeated_same_batch += 1
            else:
                repeated_same_batch = 0
                previous_signature = signature

            # Gmail label changes are normally immediately visible. If an API
            # cache briefly returns the same page, retry a couple of times rather
            # than looping forever.
            if repeated_same_batch >= 3:
                status = "MORE REMAIN"
                break

            for offset in range(0, len(ids), 100):
                if cancel and cancel.is_set():
                    status = "STOPPED"
                    break
                batch = ids[offset : offset + 100]
                retry(
                    lambda values=batch: gmail.users()
                    .messages()
                    .batchModify(
                        userId="me",
                        body={
                            "ids": values,
                            "addLabelIds": ["TRASH"],
                            "removeLabelIds": ["INBOX"],
                        },
                    )
                    .execute()
                )
                moved += len(batch)

            if status == "STOPPED":
                break

            # Give Gmail a tiny moment to expose the changed category query before
            # requesting the next pass. This keeps large cleanups stable.
            time.sleep(0.10)

        result = {
            "status": status,
            "moved": moved,
            "skipped": skipped,
            "protected": 0,
            "review": 0,
            "guard_enabled": bool(settings.get("business_guard_enabled", False)),
            "guard_applied": False,
            "message": (
                f"{moved} Promotions/Social message(s) moved to recoverable Gmail Trash. "
                "This full category clean includes all ages, Starred and Important messages."
            ),
        }
        upsert_account(
            email,
            last_cleanup=utc_now(),
            last_result=f"{status}: {result['message']}",
            error="",
        )
        return result
    except Exception as exc:
        LOGGER.exception("Cleanup failed for %s", email)
        upsert_account(email, last_cleanup=utc_now(), last_result="ERROR", error=str(exc))
        raise
    finally:
        lock.release()

def _with_date_range(query: str, from_date: str = "", to_date: str = "") -> tuple[str, str, str]:
    """Narrow a Gmail query to an inclusive YYYY-MM-DD date range."""
    raw_from = str(from_date or "").strip()
    raw_to = str(to_date or "").strip()
    start = None
    end = None
    if raw_from:
        try:
            start = datetime.strptime(raw_from, "%Y-%m-%d").date()
        except ValueError as exc:
            raise ValueError("From date must use YYYY-MM-DD.") from exc
    if raw_to:
        try:
            end = datetime.strptime(raw_to, "%Y-%m-%d").date()
        except ValueError as exc:
            raise ValueError("To date must use YYYY-MM-DD.") from exc
    if start and end and start > end:
        raise ValueError("From date cannot be after To date.")
    if start:
        query += f" after:{start.strftime('%Y/%m/%d')}"
    if end:
        # Gmail's before: operator is exclusive, so add one day to keep To date inclusive.
        query += f" before:{(end + timedelta(days=1)).strftime('%Y/%m/%d')}"
    return query, raw_from, raw_to



def _attachment_details(part: dict[str, Any]) -> list[dict[str, str]]:
    details: list[dict[str, str]] = []
    filename = str(part.get("filename", "") or "").strip()
    mime = str(part.get("mimeType", "") or "").strip()
    if filename:
        details.append({"name": filename, "mime": mime})
    for child in part.get("parts", []) or []:
        if isinstance(child, dict):
            details.extend(_attachment_details(child))
    return details


def search_messages(email: str, query: str, limit: int = 80, attachments_only: bool = False, from_date: str = "", to_date: str = "") -> dict[str, Any]:
    """Search Gmail text plus attachment filenames using Gmail's own index."""
    account = get_account(email)
    if not account:
        raise KeyError(f"Account is not registered: {email}")
    raw = str(query or "").strip()
    if len(raw) > 300:
        raise ValueError("Search text is too long.")
    if not raw and not str(from_date or "").strip() and not str(to_date or "").strip():
        raise ValueError("Enter something to search for or choose a date range.")

    gmail, _ = services_for(email)
    base = raw or "in:anywhere"
    first_query = f"has:attachment {base}" if attachments_only else base
    first_query, normalized_from, normalized_to = _with_date_range(first_query, from_date, to_date)
    queries = [first_query]
    # Gmail's normal search already searches message text. For simple user text,
    # also issue an attachment-filename search so PDFs/images/other files whose
    # filename contains the term are surfaced even when message text does not.
    if raw and not any(op in raw for op in (":", "{", "}")):
        quoted = raw.replace('"', " ").strip()
        if quoted:
            filename_query, _, _ = _with_date_range(f'filename:"{quoted}"', from_date, to_date)
            queries.append(filename_query)
            if not attachments_only:
                attachment_query, _, _ = _with_date_range(f'has:attachment "{quoted}"', from_date, to_date)
                queries.append(attachment_query)

    ids: list[str] = []
    seen: set[str] = set()
    estimates = 0
    for q in queries:
        result = retry(lambda q=q: gmail.users().messages().list(userId="me", q=q, maxResults=min(100, max(20, limit))).execute())
        estimates = max(estimates, int(result.get("resultSizeEstimate", 0) or 0))
        for row in result.get("messages", []) or []:
            message_id = str(row.get("id", "") or "")
            if message_id and message_id not in seen:
                seen.add(message_id)
                ids.append(message_id)
                if len(ids) >= limit:
                    break
        if len(ids) >= limit:
            break

    fetched = _parallel_message_gets(
        email,
        ids,
        format_name="full",
        metadata_headers=["Subject", "From", "Date"],
        fields="id,threadId,labelIds,internalDate,sizeEstimate,snippet,payload(mimeType,headers,filename,parts(mimeType,filename,parts(mimeType,filename,parts(mimeType,filename))))",
    )
    items: list[dict[str, Any]] = []
    for _message_id, message in fetched:
        if message is None:
            continue
        attachments = _attachment_details(message.get("payload", {}) or {})
        if attachments_only and not attachments:
            continue
        headers = _message_headers(message)
        items.append({
            "id": message["id"],
            "account": email,
            "subject": headers.get("subject") or "(No subject)",
            "from": headers.get("from") or "(Unknown sender)",
            "date": datetime.fromtimestamp(int(message.get("internalDate", 0) or 0) / 1000, tz=timezone.utc).isoformat(timespec="seconds") if message.get("internalDate") else headers.get("date", ""),
            "size_bytes": int(message.get("sizeEstimate", 0) or 0),
            "size_display": format_bytes(int(message.get("sizeEstimate", 0) or 0)),
            "snippet": str(message.get("snippet", "") or ""),
            "attachments": attachments,
            "link": f"https://mail.google.com/mail/?authuser={email}#all/{message['id']}",
        })
    return {"query": raw, "estimate": estimates, "shown": len(items), "from_date": normalized_from, "to_date": normalized_to, "items": items}

def list_candidates(
    email: str,
    candidate_type: str,
    limit: int = 100,
    from_date: str = "",
    to_date: str = "",
) -> dict[str, Any]:
    account = get_account(email)
    if not account:
        raise KeyError(f"Account is not registered: {email}")
    settings = {**DEFAULT_SETTINGS, **account.get("settings", {})}
    guard_enabled = bool(settings.get("business_guard_enabled", False))
    special_queries = {
        "protected": BUSINESS_QUERY,
        "missed_leads": MISSED_LEAD_QUERY,
        "review": cleanup_query(settings),
        "safe": _safe_signal_query(settings),
        "date_range": "-in:trash -in:spam -in:sent -in:drafts",
    }
    if candidate_type in special_queries:
        query = special_queries[candidate_type]
    elif candidate_type in CANDIDATE_QUERIES:
        query = CANDIDATE_QUERIES[candidate_type]
    else:
        raise ValueError("Unknown candidate type.")

    query, from_date, to_date = _with_date_range(query, from_date, to_date)
    gmail, _ = services_for(email)
    source_limit = min(300, max(100, limit * 3)) if candidate_type in {"review", "safe", "date_range"} else min(max(1, limit), 100)
    result = retry(lambda: gmail.users().messages().list(userId="me", q=query, maxResults=source_limit).execute())
    items: list[dict[str, Any]] = []
    ids = [str(row.get("id", "")) for row in result.get("messages", []) if row.get("id")]
    fetched = _parallel_message_gets(
        email,
        ids,
        format_name="full",
        metadata_headers=["Subject", "From", "Date"],
        fields="id,threadId,labelIds,internalDate,sizeEstimate,snippet,payload(mimeType,headers,filename,parts(mimeType,filename,parts(mimeType,filename,parts(mimeType,filename))))",
    )
    reply_cache: dict[str, bool] = {}
    for _message_id, message in fetched:
        if message is None:
            continue
        decision = classify_message(message)
        if guard_enabled and candidate_type in {"safe", "date_range"} and decision["state"] == "SAFE TO CLEAN":
            thread_id = str(message.get("threadId", "") or "")
            if thread_id:
                if thread_id not in reply_cache:
                    reply_cache[thread_id] = _thread_has_company_reply(gmail, thread_id)
                if reply_cache[thread_id]:
                    decision = classify_message(message, replied=True)

        if candidate_type == "protected" and decision["state"] != "PROTECTED":
            continue
        if candidate_type == "missed_leads" and decision.get("detection") != "Possible lead":
            continue
        if candidate_type == "review" and decision["state"] != "REVIEW":
            continue
        if candidate_type == "safe" and decision["state"] != "SAFE TO CLEAN":
            continue

        headers = _message_headers(message)
        guard_locked = guard_enabled and decision["state"] != "SAFE TO CLEAN" and candidate_type not in {"spam", "trash"}
        item = {
            "id": message["id"],
            "account": email,
            "subject": headers.get("subject") or "(No subject)",
            "from": headers.get("from") or "(Unknown sender)",
            "date": datetime.fromtimestamp(int(message.get("internalDate", 0) or 0) / 1000, tz=timezone.utc).isoformat(timespec="seconds") if message.get("internalDate") else headers.get("date", ""),
            "size_bytes": int(message.get("sizeEstimate", 0) or 0),
            "size_display": format_bytes(int(message.get("sizeEstimate", 0) or 0)),
            "labels": message.get("labelIds", []),
            "snippet": str(message.get("snippet", "") or ""),
            "attachments": _attachment_details(message.get("payload", {}) or {}),
            "link": f"https://mail.google.com/mail/?authuser={email}#all/{message['id']}",
            "classification": decision,
            "guard_enabled": guard_enabled,
            "locked": guard_locked,
        }
        items.append(item)
        if len(items) >= limit:
            break

    permanent = candidate_type in {"trash", "spam"}
    allow_cleanup = (not guard_enabled) or candidate_type not in {"protected", "missed_leads"}
    estimate = int(result.get("resultSizeEstimate", len(items)))
    if candidate_type in {"review", "safe", "protected", "missed_leads"}:
        estimate = len(items)
    return {
        "type": candidate_type,
        "query": query,
        "estimate": estimate,
        "shown": len(items),
        "permanent": permanent,
        "allow_cleanup": allow_cleanup,
        "guard_enabled": guard_enabled,
        "from_date": from_date,
        "to_date": to_date,
        "items": items,
    }

def move_selected_to_trash(email: str, ids: list[str]) -> dict[str, int]:
    selected = list(dict.fromkeys(map(str, ids)))[:100]
    if not selected:
        raise ValueError("Select at least one email.")
    account = get_account(email)
    if not account:
        raise KeyError(f"Account is not registered: {email}")
    settings = {**DEFAULT_SETTINGS, **account.get("settings", {})}
    guard_enabled = bool(settings.get("business_guard_enabled", False))
    gmail, _ = services_for(email)
    allowed: list[str] = []
    protected = 0
    review = 0
    fetched = _parallel_message_gets(
        email,
        selected,
        format_name="full" if guard_enabled else "minimal",
        metadata_headers=["Subject", "From", "Date"] if guard_enabled else None,
        fields=(
            "id,threadId,labelIds,internalDate,sizeEstimate,snippet,payload(headers,filename,parts(filename,parts(filename,parts(filename))))"
            if guard_enabled else "id,labelIds"
        ),
    )
    reply_cache: dict[str, bool] = {}
    for message_id, message in fetched:
        if message is None:
            continue
        labels = set(message.get("labelIds", []))
        if labels.intersection({"TRASH", "SPAM", "SENT", "DRAFT"}):
            continue
        if guard_enabled:
            decision = classify_message(message)
            if decision["state"] == "SAFE TO CLEAN":
                thread_id = str(message.get("threadId", "") or "")
                if thread_id:
                    if thread_id not in reply_cache:
                        reply_cache[thread_id] = _thread_has_company_reply(gmail, thread_id)
                    if reply_cache[thread_id]:
                        decision = classify_message(message, replied=True)
            if decision["state"] == "PROTECTED":
                protected += 1
                continue
            if decision["state"] != "SAFE TO CLEAN":
                review += 1
                continue
        allowed.append(message_id)
    for offset in range(0, len(allowed), 100):
        batch = allowed[offset : offset + 100]
        retry(lambda values=batch: gmail.users().messages().batchModify(userId="me", body={"ids": values, "addLabelIds": ["TRASH"], "removeLabelIds": ["INBOX"]}).execute())
    result = {"moved": len(allowed), "skipped": len(selected) - len(allowed)}
    if guard_enabled:
        result.update({"protected": protected, "review": review})
    return result

def mark_selected_not_spam(email: str, ids: list[str]) -> dict[str, int]:
    """Restore only manually selected messages that are still in Gmail Spam."""
    selected = list(dict.fromkeys(map(str, ids)))[:100]
    if not selected:
        raise ValueError("Select at least one email.")
    lock = _account_lock(email)
    if not lock.acquire(blocking=False):
        raise RuntimeError("This account is already running.")
    try:
        gmail, _ = services_for(email)
        profile = retry(lambda: gmail.users().getProfile(userId="me").execute())
        if str(profile.get("emailAddress", "")).lower() != email.lower():
            raise RuntimeError("Saved authorization belongs to a different Gmail account.")
        allowed: list[str] = []
        for message_id, message in _parallel_message_gets(
            email, selected, format_name="minimal", fields="id,labelIds"
        ):
            if message is not None and "SPAM" in set(message.get("labelIds", [])):
                allowed.append(message_id)
        for offset in range(0, len(allowed), 100):
            batch = allowed[offset : offset + 100]
            retry(
                lambda values=batch: gmail.users()
                .messages()
                .batchModify(
                    userId="me",
                    body={"ids": values, "addLabelIds": ["INBOX"], "removeLabelIds": ["SPAM"]},
                )
                .execute()
            )
        return {"restored": len(allowed), "skipped": len(selected) - len(allowed)}
    finally:
        lock.release()


def permanent_phrase(email: str) -> str:
    return f"PERMANENTLY DELETE {email.lower()}"


def permanently_delete(
    email: str,
    folder: str,
    confirmation: str,
    selected_ids: list[str] | None = None,
    maximum: int = 2000,
    older_than_days: int | None = None,
    cancel: threading.Event | None = None,
) -> dict[str, Any]:
    if folder not in {"trash", "spam"}:
        raise ValueError("Permanent deletion is restricted to Gmail Trash or Spam.")
    if confirmation != permanent_phrase(email):
        raise ValueError("Confirmation text did not match. Nothing was deleted.")
    lock = _account_lock(email)
    if not lock.acquire(blocking=False):
        raise RuntimeError("This account is already running.")
    try:
        account = get_account(email)
        settings = {**DEFAULT_SETTINGS, **(account or {}).get("settings", {})}
        guard_enabled = bool(settings.get("business_guard_enabled", False))
        gmail, _ = services_for(email)
        profile = retry(lambda: gmail.users().getProfile(userId="me").execute())
        if str(profile.get("emailAddress", "")).lower() != email.lower():
            raise RuntimeError("Saved authorization belongs to a different Gmail account.")
        purge_query = f"in:{folder}"
        if older_than_days is not None:
            if not 1 <= int(older_than_days) <= 3650:
                raise ValueError("Permanent cleanup age must be 1–3650 days.")
            purge_query += f" older_than:{int(older_than_days)}d"
        ids = (
            list(dict.fromkeys(map(str, selected_ids)))[:100]
            if selected_ids is not None
            else snapshot_ids(gmail, purge_query, maximum)
        )
        required_label = "TRASH" if folder == "trash" else "SPAM"
        deleted = 0
        skipped = 0
        reply_cache: dict[str, bool] = {}
        for offset in range(0, len(ids), 100):
            if cancel and cancel.is_set():
                break
            valid: list[str] = []
            chunk = ids[offset : offset + 100]
            fetch_format = "full" if (folder == "spam" or guard_enabled) else "minimal"
            fetch_fields = (
                "id,threadId,labelIds,internalDate,sizeEstimate,snippet,payload(headers,filename,parts(filename,parts(filename,parts(filename))))"
                if (folder == "spam" or guard_enabled) else "id,labelIds"
            )
            for message_id, message in _parallel_message_gets(
                email, chunk, format_name=fetch_format, fields=fetch_fields,
                metadata_headers=["Subject", "From", "Date"] if (folder == "spam" or guard_enabled) else None,
            ):
                if message is None or required_label not in set(message.get("labelIds", [])):
                    skipped += 1
                    continue
                if guard_enabled:
                    decision = classify_message(message)
                    if decision["state"] == "SAFE TO CLEAN":
                        thread_id = str(message.get("threadId", "") or "")
                        if thread_id:
                            if thread_id not in reply_cache:
                                reply_cache[thread_id] = _thread_has_company_reply(gmail, thread_id)
                            if reply_cache[thread_id]:
                                decision = classify_message(message, replied=True)
                    if decision["state"] != "SAFE TO CLEAN":
                        skipped += 1
                        continue
                valid.append(message_id)
            if cancel and cancel.is_set():
                break
            if valid:
                retry(
                    lambda batch=valid: gmail.users()
                    .messages()
                    .batchDelete(userId="me", body={"ids": batch})
                    .execute()
                )
                deleted += len(valid)
        status = "LIMIT REACHED" if selected_ids is None and len(ids) >= maximum else "COMPLETE"
        if cancel and cancel.is_set():
            status = "STOPPED"
        upsert_account(
            email,
            last_cleanup=utc_now(),
            last_result=f"{status}: permanently deleted {deleted} {folder} message(s)",
            error="",
        )
        return {"status": status, "deleted": deleted, "skipped": skipped}
    except Exception as exc:
        upsert_account(email, last_result="PERMANENT DELETE ERROR", error=str(exc))
        raise
    finally:
        lock.release()
