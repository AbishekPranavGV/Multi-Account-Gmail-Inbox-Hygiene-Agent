@echo off
setlocal EnableExtensions
pushd "%~dp0"
if errorlevel 1 exit /b 1
title GmCL - Make This PC Server

echo ==========================================================
echo        GmCL - SERVER SETUP
echo ==========================================================
echo.
echo This PC will host the dashboard and Gmail data.
echo Client PCs use the generated application to add their Gmail.
echo.

call "%~dp0ONE_CLICK_START.bat"
if errorlevel 1 (
  echo Setup is incomplete. Resolve the error above and run again.
  pause
  exit /b 1
)

powershell.exe -NoProfile -Command "$p=New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent()); if($p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){exit 0}else{exit 1}" >nul 2>&1
if errorlevel 1 (
  echo Administrator permission is required once to open the Windows Firewall port.
  echo Requesting Administrator permission...
  powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b 0
)

echo [1/5] Enabling server mode and creating the protected client access link...
set "GMCL_DATA_DIR=%LOCALAPPDATA%\GmCL\ServerData"
if not exist "%GMCL_DATA_DIR%" mkdir "%GMCL_DATA_DIR%" >nul 2>nul
>"%GMCL_DATA_DIR%\server_mode.enabled" echo enabled
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0launcher\Create-Client-Links.ps1"
if errorlevel 1 goto failed

echo [2/5] Configuring Windows Firewall for trusted local-network clients...
netsh advfirewall firewall delete rule name="GmCL Server" >nul 2>nul
netsh advfirewall firewall delete rule name="VelocityX Gmail Cleaner Server" >nul 2>nul
netsh advfirewall firewall add rule name="GmCL Server" dir=in action=allow protocol=TCP localport=8795 profile=any remoteip=localsubnet,100.64.0.0/10 >nul
if errorlevel 1 goto failed

echo [3/5] Restarting GmCL in server mode...
set "CLEANER_ROOT=%CD%"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$pidFile=Join-Path $env:LOCALAPPDATA 'GmCL\ServerData\server.pid'; if(Test-Path -LiteralPath $pidFile){ try { $serverPid=[int](Get-Content -LiteralPath $pidFile -Raw); $p=Get-CimInstance Win32_Process -Filter ('ProcessId='+$serverPid) -ErrorAction SilentlyContinue; if($p -and $p.CommandLine -like ('*'+$env:CLEANER_ROOT+'*app.py*')){Stop-Process -Id $serverPid -Force -ErrorAction SilentlyContinue; Start-Sleep -Milliseconds 800} } catch {} Remove-Item -LiteralPath $pidFile -Force -ErrorAction SilentlyContinue }"
set "GMCL_PYTHONW=%LOCALAPPDATA%\GmCL\Runtime\venv\Scripts\pythonw.exe"
start "" /b "%GMCL_PYTHONW%" "%~dp0app.py" --no-browser

echo [4/5] Waiting for the server...
set "READY=0"
for /L %%G in (1,1,20) do (
  powershell.exe -NoProfile -Command "try { $r=Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:8795/api/state' -TimeoutSec 1; if($r.StatusCode -eq 200){exit 0}else{exit 1} } catch { exit 1 }" >nul 2>nul
  if not errorlevel 1 (
    set "READY=1"
    goto server_ready
  )
  timeout /t 1 /nobreak >nul
)

:server_ready
if "%READY%"=="0" (
  echo ERROR: GmCL server did not start.
  echo Check %LOCALAPPDATA%\GmCL\ServerData\server.log.
  pause
  exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0launcher\Verify-Server.ps1"
if errorlevel 1 goto failed
call "%~dp0INSTALL_AUTO_START.bat" /silent
if errorlevel 1 goto failed
echo [5/5] Server is ready. Auto-start at Windows sign-in is installed.
echo.
start "" "http://127.0.0.1:8795"
echo ==========================================================
echo SERVER READY
echo.
echo COMMON / TAILSCALE ALL-ACCOUNT DASHBOARD:
echo   START_COMMON_TAILSCALE_DASHBOARD.bat
echo.
echo TO ADD / OPEN AN INDIVIDUAL GMAIL ON A STAFF PC:
echo   CLIENT_ACCESS\GmCL_CLIENT_APPLICATION\START_GMCL_CLIENT.bat
echo.
echo The server details are also saved in:
echo   URL.txt
echo ==========================================================
echo.
type "%~dp0URL.txt"
echo.
pause
exit /b 0

:failed
echo.
echo ERROR: Server configuration failed.
echo Make sure you approved the Administrator prompt and try again.
pause
exit /b 1
