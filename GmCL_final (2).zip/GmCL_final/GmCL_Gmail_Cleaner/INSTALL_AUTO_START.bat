@echo off
setlocal EnableExtensions
pushd "%~dp0"
if errorlevel 1 exit /b 1
title Install GmCL Auto Start

set "GMCL_VENV=%LOCALAPPDATA%\GmCL\Runtime\venv"
set "GMCL_RUNTIME=%LOCALAPPDATA%\GmCL\Runtime"
set "GMCL_RUNNER_SOURCE=%~dp0launcher\AutoStart-Runner.ps1"
set "GMCL_RUNNER_LOCAL=%GMCL_RUNTIME%\AutoStart-Runner.ps1"
set "GMCL_ROOT_FILE=%GMCL_RUNTIME%\autostart_root.txt"
set "GMCL_STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
set "GMCL_STARTUP_FILE=%GMCL_STARTUP%\GmCL_AutoStart.cmd"

if not exist "%GMCL_VENV%\Scripts\pythonw.exe" (
  echo Run SETUP_AND_START.bat first.
  if /I not "%~1"=="/silent" pause
  exit /b 2
)
if not exist "%GMCL_RUNNER_SOURCE%" (
  echo GmCL auto-start helper is missing.
  if /I not "%~1"=="/silent" pause
  exit /b 3
)

if /I not "%~1"=="/silent" (
  echo GmCL will start automatically when THIS Windows user signs in.
  echo Administrator permission is not required.
  echo It cannot run while this PC is shut down.
  echo.
  choice /c YN /n /m "Install or replace GmCL auto start? [Y/N]: "
  if errorlevel 2 exit /b 0
)

if not exist "%GMCL_RUNTIME%" mkdir "%GMCL_RUNTIME%" >nul 2>nul
if not exist "%GMCL_STARTUP%" mkdir "%GMCL_STARTUP%" >nul 2>nul
copy /Y "%GMCL_RUNNER_SOURCE%" "%GMCL_RUNNER_LOCAL%" >nul
if errorlevel 1 goto failed

>"%GMCL_ROOT_FILE%" echo %~dp0
if errorlevel 1 goto failed

>"%GMCL_STARTUP_FILE%" echo @echo off
>>"%GMCL_STARTUP_FILE%" echo powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "%%LOCALAPPDATA%%\GmCL\Runtime\AutoStart-Runner.ps1"
if errorlevel 1 goto failed

rem Best-effort cleanup of old scheduled tasks. Failure is intentionally ignored:
rem some Windows PCs protect Task Scheduler from standard users.
schtasks.exe /Delete /TN "VelocityX Gmail Multi Cleaner" /F >nul 2>nul
schtasks.exe /Delete /TN "GmCL" /F >nul 2>nul

call "%~dp0START_BACKGROUND.bat" >nul 2>nul

echo GmCL auto start is installed for this Windows user.
echo It will start automatically after Windows sign-in without Task Scheduler permission.
if /I not "%~1"=="/silent" pause
exit /b 0

:failed
echo Could not install GmCL auto start for this Windows user.
echo Check that this Windows profile can write to AppData, then try again.
if /I not "%~1"=="/silent" pause
exit /b 1
