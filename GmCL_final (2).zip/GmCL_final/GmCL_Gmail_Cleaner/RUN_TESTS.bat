@echo off
setlocal
pushd "%~dp0"
if errorlevel 1 exit /b 1
set "GMCL_PYTHON=%LOCALAPPDATA%\GmCL\Runtime\venv\Scripts\python.exe"
if exist "%GMCL_PYTHON%" (
  "%GMCL_PYTHON%" -m unittest discover -s tests -v
) else (
  py -3 -m unittest discover -s tests -v
)
set "TEST_RESULT=%errorlevel%"
pause
exit /b %TEST_RESULT%
