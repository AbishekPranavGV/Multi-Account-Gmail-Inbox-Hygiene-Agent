from __future__ import annotations

import argparse
import atexit
import logging
import os
import sys
import threading
import time
import webbrowser

from waitress import serve

from app.config import HOST, LOCAL_BROWSER_HOST, LOCK_FILE, LOG_FILE, PID_FILE, PORT
from app.scheduler import CleanupScheduler
from app.web import create_app


def acquire_instance_lock():
    LOCK_FILE.parent.mkdir(parents=True, exist_ok=True)
    handle = open(LOCK_FILE, "a+b")
    try:
        if sys.platform == "win32":
            import msvcrt

            handle.seek(0)
            if not handle.read(1):
                handle.seek(0)
                handle.write(b"0")
                handle.flush()
            handle.seek(0)
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl

            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        return handle
    except OSError:
        handle.close()
        return None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args()
    instance = acquire_instance_lock()
    if instance is None:
        if not args.no_browser:
            webbrowser.open(f"http://{LOCAL_BROWSER_HOST}:{PORT}")
        print("GmCL is already running.")
        return 0

    logging.basicConfig(
        filename=LOG_FILE,
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
        encoding="utf-8",
    )
    PID_FILE.write_text(str(os.getpid()), encoding="ascii")
    scheduler = CleanupScheduler()
    scheduler.start()

    def cleanup():
        scheduler.stop()
        try:
            if PID_FILE.exists() and PID_FILE.read_text(encoding="ascii").strip() == str(os.getpid()):
                PID_FILE.unlink()
        except OSError:
            pass
        try:
            instance.close()
        except OSError:
            pass

    atexit.register(cleanup)
    if not args.no_browser:
        threading.Thread(
            target=lambda: (time.sleep(0.35), webbrowser.open(f"http://{LOCAL_BROWSER_HOST}:{PORT}")),
            daemon=True,
        ).start()
    print(f"GmCL server: http://{LOCAL_BROWSER_HOST}:{PORT}")
    serve(create_app(scheduler), host=HOST, port=PORT, threads=16, channel_timeout=120)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

