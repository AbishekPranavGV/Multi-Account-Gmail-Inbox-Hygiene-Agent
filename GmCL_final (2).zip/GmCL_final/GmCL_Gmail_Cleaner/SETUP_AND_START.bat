@echo off
call "%~dp0ONE_CLICK_START.bat"
exit /b %errorlevel%
