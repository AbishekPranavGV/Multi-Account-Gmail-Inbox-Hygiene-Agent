@echo off
setlocal
pushd "%~dp0"
if errorlevel 1 exit /b 1
set "GMCL_PYTHONW=%LOCALAPPDATA%\GmCL\Runtime\venv\Scripts\pythonw.exe"
if not exist "%GMCL_PYTHONW%" exit /b 2
start "" /b "%GMCL_PYTHONW%" "%~dp0app.py" --no-browser
exit /b 0

