GmCL V1.8.3 COMMON / TAILSCALE MODE
- V1.8.3 opens in Simple Mode by default. Use More Tools only when advanced functions are needed. No existing advanced function was removed.
- Run MAKE_THIS_PC_SERVER.bat once on the main server PC.
- From the trusted Common folder, any office/Tailscale PC can run START_COMMON_TAILSCALE_DASHBOARD.bat to open the SAME central dashboard with all connected Gmail accounts.
- Do not run a second server on staff PCs. Gmail tokens and the End-of-Day scheduler stay on the main server.
- Add another Gmail from a staff PC with CLIENT_ACCESS\GmCL_CLIENT_APPLICATION\CONNECT_GMAIL.bat.

GmCL 1.7.1 - SERVER AND PRIVATE CLIENT APPLICATION

SERVER PC (Windows 10/11, Internet needed for Google and initial installation)
1. Extract the full ZIP to a local folder, such as C:\GmCL.
2. For an upgrade, stop the old GmCL process first. Back up its folder, then copy
   these files into the existing folder. Keep existing config and data files.
3. Run MAKE_THIS_PC_SERVER.bat. Approve Windows elevation for the firewall.
4. If needed, supply the Google Desktop OAuth JSON and complete Google sign-in.
5. The server opens at http://127.0.0.1:8795 and sees ALL connected accounts.
6. Auto-start is installed for this Windows user's sign-in. Keep that user signed
   in and the server PC awake. This is not a boot-time Windows service.

CLIENT PC
1. On the server, open CLIENT_ACCESS.
2. Copy the entire GmCL_CLIENT_APPLICATION folder to each client PC.
3. On the client, double-click START_GMCL_CLIENT.bat.
4. Existing Python 3.10+ is reused when available; otherwise Python 3.12 is installed through winget.
   The client runtime is saved in LocalAppData so later starts do not reinstall packages.
5. Choose the Gmail account in Google sign-in and approve access once.
6. The server retrieves that authorized account and the client's dashboard opens.
7. Later use the GmCL Client desktop shortcut. The saved private dashboard access
   is reused with no forced 30-day Google re-login.
8. Run CONNECT_GMAIL.bat only if Google access was revoked, the account was removed,
   or you intentionally want to connect another Gmail. Prior accounts/settings stay saved.

CLIENT PRIVACY
A client dashboard can view and manage only its currently connected Gmail.
The server administrator can view and manage every connected Gmail.
Google sign-in proves account access; GmCL never extracts browser cookies or
silently discovers accounts. Reconnect each account you want the server to manage.
Old shared dashboard links are disabled. Generate and copy the new client folder.
Clients can close their PC after authorization; the server performs scheduled work.

NETWORK
Use a trusted office LAN or an already configured trusted VPN. HTTP is used;
this package does not provide TLS and must not be exposed on the public Internet.
Keep generated client folders and account dashboard links private.
Port 8795 must be free. The server checks its network listener and generated
addresses; the client verifies reachability from its own PC. Router isolation,
blocked routing, sleeping PCs, or stale IP addresses can still prevent access.
If server addresses change, regenerate CLIENT_ACCESS and recopy the client folder.

CLEANUP
Automation starts only when enabled for an account. Defaults: Promotions/Social
older than 7 days; protect starred/important; maximum 2000 per run; hourly.
Normal cleanup moves mail to Trash. Empty Trash and permanent deletion are
irreversible and run without a confirmation popup, preserving the existing flow.
Auto-purge is OFF by default. Its age filter uses the MESSAGE age, not time spent
in Trash; enabling it can permanently delete an old email just moved to Trash.
Stop prevents subsequent scheduled purge batches; an API request already sent
cannot be undone. Manual cleanup actions are separate from the scheduled Stop.
Google sign-in, OAuth project setup and Google authorization cannot be bypassed.

VALIDATION
See docs/VALIDATION_REPORT.txt. Real Windows, Google consent and office-network
verification must be performed on the actual computers; those were not available
in the build environment.

SAVED GMAIL LOGIN (v1.6.3)
- After the first successful Google approval, Gmail authorization is saved securely for this Windows user.
- Server account data and signing keys are stored in %LOCALAPPDATA%\GmCL\ServerData, so replacing/updating the ZIP does not remove logged-in Gmail accounts.
- Gmail authorization stays saved; temporary dashboard access is refreshed automatically from %LOCALAPPDATA%\GmCL\ClientState without another Google login.
- Existing v1.6.0/v1.6.1/v1.6.2 data is reused automatically from LocalAppData; older ZIP-local state is migrated when found.
- Client PCs reuse their saved private dashboard access and do not ask for Google login again unless the account is removed, Google access is revoked, or CONNECT_GMAIL.bat is deliberately used.
- The Google Desktop OAuth client JSON is also saved under %LOCALAPPDATA%\GmCL\ServerData\oauth, so future ZIP updates do not lose it.
- A temporary server/network error no longer triggers a fresh Google login; GmCL preserves the saved session and asks you to retry.
- Client sign-in opens in the normal Windows default browser/profile so an already signed-in Google session can be reused.
- Google may omit refresh_token on a repeat approval; GmCL keeps the previously saved refresh token instead of replacing it with a short-lived token.

GOOGLE SIGN-IN NOTE
Every Gmail must complete Google sign-in/consent successfully once. GmCL cannot bypass Google's password, 2-Step Verification, security challenge, or a Google-hosted "Something went wrong" error. After Google returns a reusable authorization, GmCL saves it for future starts. For long-term external Gmail refresh tokens, publish the OAuth consent app in Google Cloud instead of leaving it in Testing.

------------------------------------------------------------
V1.7.0 BUSINESS MAIL GUARD UPDATE
------------------------------------------------------------
The dashboard uses a File Manager-style UI. Business Mail Guard is now a manual per-Gmail ON/OFF setting; when ON it checks cleanup actions before mail is removed.
Automatic cleanup only moves high-confidence low-value Promotions/Social messages to
recoverable Trash. Business-looking or uncertain mail is protected/reviewed first.
See BUSINESS_GUARD_V1_7_0.txt for details.


FAST START (v1.7.1)
- The server Python runtime is stored in %LOCALAPPDATA%\GmCL\Runtime\venv.
- A compatible runtime from an older GmCL/VelocityX package is reused on the first upgrade when available.
- Future ZIP updates reuse that persistent runtime and skip package installation when requirements are already present.
- Safety tests run once per version and are then skipped on normal starts.
- OAuth lookup no longer recursively scans the entire Downloads folder.

AUTO START (V1.8.8): INSTALL_AUTO_START.bat now uses the current-user Windows Startup folder and does not require Administrator permission.


API QUOTA RELIABILITY (V1.9.0): Analyze/Review/Search now pace Gmail API calls and automatically cool down/retry if Google returns a per-user quota limit. This temporary condition does not require reconnecting the Gmail account.
