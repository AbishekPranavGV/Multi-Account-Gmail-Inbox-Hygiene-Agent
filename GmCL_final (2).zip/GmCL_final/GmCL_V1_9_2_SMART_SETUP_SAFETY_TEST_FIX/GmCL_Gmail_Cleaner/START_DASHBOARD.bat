@echo off
setlocal EnableExtensions
call "%~dp0OPEN_GMCL_ANYWHERE.bat"
exit /b %errorlevel%
