@echo off
setlocal EnableExtensions EnableDelayedExpansion
pushd "%~dp0"
if errorlevel 1 exit /b 1
title Connect Gmail to GmCL


rem On a LAN/Tailscale client PC, Google sign-in must happen on THIS PC and the
rem new token is then registered with the central GmCL server. Do not create a
rem separate local account database.
if not exist "%LOCALAPPDATA%\GmCL\ServerData\server_mode.enabled" if exist "%~dp0CLIENT_ACCESS\GmCL_CLIENT_APPLICATION\CONNECT_GMAIL.bat" (
  call "%~dp0CLIENT_ACCESS\GmCL_CLIENT_APPLICATION\CONNECT_GMAIL.bat"
  exit /b !errorlevel!
)
set "GMCL_PYTHON=%LOCALAPPDATA%\GmCL\Runtime\venv\Scripts\python.exe"
if not exist "%GMCL_PYTHON%" (
  echo GmCL is not set up yet. Running the one-time setup first...
  call "%~dp0ONE_CLICK_START.bat"
  if errorlevel 1 exit /b 2
)

set "PERSISTENT_OAUTH=%LOCALAPPDATA%\GmCL\ServerData\oauth\client_secret.json"
if not exist "config\client_secret.json" if exist "%PERSISTENT_OAUTH%" (
  copy /Y "%PERSISTENT_OAUTH%" "config\client_secret.json" >nul
)
if not exist "config\client_secret.json" if not exist "%PERSISTENT_OAUTH%" (
  echo Missing Google Desktop OAuth JSON.
  echo Run ONE_CLICK_START.bat and place the downloaded client_secret JSON in Downloads.
  start "" notepad.exe "%~dp0README_FIRST.txt"
  pause
  exit /b 2
)

"%GMCL_PYTHON%" "%~dp0add_account.py"
set "ADD_RESULT=%errorlevel%"
pause
exit /b %ADD_RESULT%
