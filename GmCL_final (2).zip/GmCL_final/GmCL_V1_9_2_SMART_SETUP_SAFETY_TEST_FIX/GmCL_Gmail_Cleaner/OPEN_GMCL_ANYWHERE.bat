@echo off
setlocal EnableExtensions EnableDelayedExpansion
pushd "%~dp0" >nul 2>nul
if errorlevel 1 exit /b 1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0launcher\Open-Anywhere.ps1"
set "RC=%errorlevel%"
if "%RC%"=="0" (popd & exit /b 0)
if "%RC%"=="10" (
  call "%~dp0ONE_CLICK_START.bat" /server-resume
  set "RC=!errorlevel!"
  popd
  exit /b !RC!
)
if "%RC%"=="11" (
  echo.
  echo GmCL central server has not been configured in this folder yet.
  echo On the MAIN PC run MAKE_THIS_PC_SERVER.bat once.
  echo After that, this same OPEN_GMCL_ANYWHERE.bat works from LAN or Tailscale PCs.
  echo.
  pause
  popd
  exit /b 11
)
echo.
echo The central GmCL server could not be reached.
echo Keep the main server PC ON and connected to LAN or Tailscale, then retry.
echo.
pause
popd
exit /b %RC%
