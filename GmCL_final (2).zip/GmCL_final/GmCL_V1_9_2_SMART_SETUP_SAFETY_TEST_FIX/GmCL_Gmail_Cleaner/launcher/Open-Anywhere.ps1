[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$DataDir = if ($env:GMCL_DATA_DIR) { $env:GMCL_DATA_DIR } else { Join-Path $env:LOCALAPPDATA 'GmCL\ServerData' }
$ServerMarker = Join-Path $DataDir 'server_mode.enabled'
$VersionFile = Join-Path $Root 'VERSION.txt'
$ExpectedVersion = if (Test-Path -LiteralPath $VersionFile) { (Get-Content -LiteralPath $VersionFile -Raw -Encoding ASCII).Trim() } else { '' }
$SharedCandidates = @(
    (Join-Path $Root 'CLIENT_ACCESS\shared_command_center.json'),
    (Join-Path $Root 'shared_command_center.json')
)
$SharedConfig = $SharedCandidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
$SharedOwner = ''
if ($SharedConfig) {
    try {
        $cfg = Get-Content -LiteralPath $SharedConfig -Raw -Encoding UTF8 | ConvertFrom-Json
        $SharedOwner = [string]$cfg.generated_by
    } catch {}
}

function Get-LocalGmclVersion {
    try {
        $r = Invoke-RestMethod -Method Get -Uri 'http://127.0.0.1:8795/api/state?startup_probe=1' -TimeoutSec 1
        if ($r.ok) { return [string]$r.version }
    } catch {}
    return ''
}

$ThisPcIsServer = Test-Path -LiteralPath $ServerMarker
if ($SharedOwner -and $SharedOwner -eq $env:COMPUTERNAME) { $ThisPcIsServer = $true }

# If a central-server config exists and this is NOT that server PC, always use
# the central dashboard first. This intentionally ignores any accidental/stale
# local GmCL process so a client PC can never open a separate empty database.
if ($SharedConfig -and -not $ThisPcIsServer) {
    & (Join-Path $PSScriptRoot 'Open-Shared-Command-Center.ps1')
    exit $LASTEXITCODE
}

# The real server PC may open localhost, but only when it is running this exact
# package version. Otherwise return 10 so the BAT restarts the correct build.
$localVersion = Get-LocalGmclVersion
if ($ThisPcIsServer) {
    if ($localVersion -and ((-not $ExpectedVersion) -or $localVersion -eq $ExpectedVersion)) {
        Start-Process 'http://127.0.0.1:8795'
        exit 0
    }
    exit 10
}

# Standalone backward compatibility: if no central config exists and an exact
# local instance is already running, open it. New shared deployments should use
# MAKE_THIS_PC_SERVER.bat once to establish the central identity.
if (-not $SharedConfig -and $localVersion -and ((-not $ExpectedVersion) -or $localVersion -eq $ExpectedVersion)) {
    Start-Process 'http://127.0.0.1:8795'
    exit 0
}

exit 11
