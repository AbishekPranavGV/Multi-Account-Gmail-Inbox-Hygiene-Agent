[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$DataDir = if ($env:GMCL_DATA_DIR) { $env:GMCL_DATA_DIR } else { Join-Path $env:LOCALAPPDATA "GmCL\ServerData" }
$OutputDir = Join-Path $Root "CLIENT_ACCESS"
$AppDir = Join-Path $OutputDir "GmCL_CLIENT_APPLICATION"
$KeyFile = Join-Path $DataDir "network_access.key"
$Port = 8795

New-Item -ItemType Directory -Path $DataDir -Force | Out-Null
New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
New-Item -ItemType Directory -Path $AppDir -Force | Out-Null

if (-not (Test-Path -LiteralPath $KeyFile)) {
    $bytes = New-Object byte[] 32
    $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
    $key = ($bytes | ForEach-Object { $_.ToString("x2") }) -join ""
    [IO.File]::WriteAllText($KeyFile, $key, [Text.Encoding]::ASCII)
} else {
    $key = (Get-Content -LiteralPath $KeyFile -Raw -Encoding ASCII).Trim()
}

if ([string]::IsNullOrWhiteSpace($key) -or $key.Length -lt 32) {
    throw "The network access key is invalid. Delete $DataDir\network_access.key and run this tool again."
}

$computerName = $env:COMPUTERNAME
$ip = $null
try {
    $configs = Get-NetIPConfiguration -ErrorAction Stop | Where-Object {
        $_.IPv4DefaultGateway -and $_.IPv4Address
    }
    foreach ($config in $configs) {
        $candidate = $config.IPv4Address | Where-Object {
            $_.IPAddress -and $_.IPAddress -notlike "169.254.*" -and $_.IPAddress -ne "127.0.0.1"
        } | Select-Object -First 1
        if ($candidate) {
            $ip = $candidate.IPAddress
            break
        }
    }
} catch {
    $ip = $null
}

if (-not $ip) {
    try {
        $ip = [Net.Dns]::GetHostAddresses([Net.Dns]::GetHostName()) |
            Where-Object { $_.AddressFamily -eq [Net.Sockets.AddressFamily]::InterNetwork -and $_.IPAddressToString -notlike "169.254.*" -and $_.IPAddressToString -ne "127.0.0.1" } |
            Select-Object -First 1 -ExpandProperty IPAddressToString
    } catch {
        $ip = $null
    }
}

$hostBase = "http://${computerName}:$Port"
$ipBase = if ($ip) { "http://${ip}:$Port" } else { $null }
$candidateUrls = @()
# Prefer Tailscale for the shared Common launcher so the same shortcut also
# works away from the local LAN. MagicDNS is added when available, followed by
# the stable Tailscale IPv4 address, LAN IP and Windows hostname.
try {
    $ts = Get-Command tailscale.exe -ErrorAction Stop
    $tsJson = & $ts.Source status --json 2>$null | ConvertFrom-Json
    $dns = [string]$tsJson.Self.DNSName
    if ($dns) { $candidateUrls += "http://$($dns.TrimEnd('.')):$Port" }
} catch {}
try {
    $tailscaleIp = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
        Where-Object { $_.IPAddress -match '^100\.' } |
        Select-Object -First 1 -ExpandProperty IPAddress
    if ($tailscaleIp) { $candidateUrls += "http://${tailscaleIp}:$Port" }
} catch {}
if ($ipBase) { $candidateUrls += $ipBase }
$candidateUrls += $hostBase
$candidateUrls = @($candidateUrls | Select-Object -Unique)

Get-ChildItem -LiteralPath $OutputDir -Filter '*.url' | Remove-Item -Force
$persistentOauth = Join-Path $DataDir "oauth\client_secret.json"
$oauthSource = if (Test-Path -LiteralPath $persistentOauth) { $persistentOauth } else { Join-Path $Root "config\client_secret.json" }
if (Test-Path -LiteralPath $oauthSource) {
    Copy-Item -LiteralPath $oauthSource -Destination (Join-Path $AppDir "client_secret.json") -Force
}
$clientConfig = @{ server_url = $candidateUrls[0]; server_candidates = $candidateUrls; access_key = $key } | ConvertTo-Json -Depth 3
[IO.File]::WriteAllText((Join-Path $AppDir "client_config.json"), $clientConfig, [Text.Encoding]::UTF8)
# This small trusted-folder config lets START_COMMON_TAILSCALE_DASHBOARD.bat
# find the one central server. It contains no Gmail OAuth token/password.
$sharedConfig = @{ server_candidates = $candidateUrls; access_key = $key; generated_by = $computerName; port = $Port } | ConvertTo-Json -Depth 3
[IO.File]::WriteAllText((Join-Path $OutputDir "shared_command_center.json"), $sharedConfig, [Text.Encoding]::UTF8)
[IO.File]::WriteAllText((Join-Path $Root "shared_command_center.json"), $sharedConfig, [Text.Encoding]::UTF8)
Copy-Item -LiteralPath (Join-Path $PSScriptRoot "client_connect.py") -Destination (Join-Path $AppDir "client_connect.py") -Force
Copy-Item -LiteralPath (Join-Path $PSScriptRoot "CLIENT_CONNECT_GMAIL.bat") -Destination (Join-Path $AppDir "CLIENT_CONNECT_GMAIL.bat") -Force
[IO.File]::WriteAllText((Join-Path $AppDir "requirements-client.txt"), "google-auth-oauthlib==1.4.1`r`nrequests==2.32.5`r`ncryptography>=44,<47`r`n", [Text.Encoding]::ASCII)

foreach ($name in @('Client-Setup.ps1','START_GMCL_CLIENT.bat','CONNECT_GMAIL.bat')) {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination (Join-Path $AppDir $name) -Force
}
$instructions = @"
GmCL CLIENT SETUP
Copy the entire GmCL_CLIENT_APPLICATION folder to the client PC.
Double-click START_GMCL_CLIENT.bat. Python is installed if needed through winget.
Select Gmail and approve Google access once. Your account appears on the server.
Later: use the GmCL Client desktop shortcut to open your own dashboard.
To reconnect or choose another Gmail: run CONNECT_GMAIL.bat.
The individual GmCL Client shortcut keeps the signed-in account private.
For the trusted all-account dashboard, run START_COMMON_TAILSCALE_DASHBOARD.bat from the main package in the Common folder.
Use only on your trusted office LAN or existing trusted VPN/Tailscale. Keep this folder private.
Server: $computerName, TCP port $Port. The server must remain on and running.
"@
[IO.File]::WriteAllText((Join-Path $OutputDir 'README_CLIENT.txt'), $instructions, [Text.Encoding]::UTF8)
[IO.File]::WriteAllText((Join-Path $AppDir 'README_CLIENT.txt'), $instructions, [Text.Encoding]::UTF8)
[IO.File]::WriteAllText((Join-Path $Root 'URL.txt'), "SERVER ADMIN: http://127.0.0.1:$Port`r`nANY COMPUTER / LAN / TAILSCALE: run OPEN_GMCL_ANYWHERE.bat`r`nCOMMON / TAILSCALE ALL-ACCOUNT DASHBOARD: run START_COMMON_TAILSCALE_DASHBOARD.bat`r`nINDIVIDUAL CLIENT: run START_GMCL_CLIENT.bat in CLIENT_ACCESS\GmCL_CLIENT_APPLICATION", [Text.Encoding]::UTF8)
Write-Host "Client application ready: $AppDir"
