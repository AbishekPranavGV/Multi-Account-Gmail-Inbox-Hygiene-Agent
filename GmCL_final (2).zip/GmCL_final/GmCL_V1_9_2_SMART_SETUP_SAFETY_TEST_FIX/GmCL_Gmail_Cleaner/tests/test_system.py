from __future__ import annotations

import json
import base64
import hashlib
import tempfile
import threading
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch
from cryptography.fernet import Fernet

from app import cleaner, scheduler, store, web


class FakeRequest:
    def __init__(self, fn):
        self.fn = fn

    def execute(self):
        return self.fn()


class FakeMessages:
    def __init__(self, messages):
        self.data = {m["id"]: json.loads(json.dumps(m)) for m in messages}
        self.writes = []
        self.deletes = []

    def _matches(self, message, query):
        labels = set(message.get("labelIds", []))
        positive_query = query.replace("-in:trash", "").replace("-in:spam", "")
        if "category:promotions" in query and "category:social" not in query and "CATEGORY_PROMOTIONS" not in labels:
            return False
        if "category:social" in query and "category:promotions" not in query and "CATEGORY_SOCIAL" not in labels:
            return False
        if "{category:promotions category:social}" in query and not labels.intersection({"CATEGORY_PROMOTIONS", "CATEGORY_SOCIAL"}):
            return False
        if "in:trash" in positive_query and "TRASH" not in labels:
            return False
        if "in:spam" in positive_query and "SPAM" not in labels:
            return False
        if "-in:trash" in query and "TRASH" in labels:
            return False
        if "-in:spam" in query and "SPAM" in labels:
            return False
        if "-in:sent" in query and "SENT" in labels:
            return False
        if "-in:drafts" in query and "DRAFT" in labels:
            return False
        if "-is:starred" in query and "STARRED" in labels:
            return False
        if "-is:important" in query and "IMPORTANT" in labels:
            return False
        if "larger:10M" in query and int(message.get("sizeEstimate", 0)) <= 10 * 1024 * 1024:
            return False
        if "larger:5M" in query and int(message.get("sizeEstimate", 0)) <= 5 * 1024 * 1024:
            return False
        if "older_than:" in query:
            token = query.split("older_than:", 1)[1].split()[0]
            if token.endswith("d"):
                age_days = int(token[:-1])
            elif token.endswith("y"):
                age_days = int(token[:-1]) * 365
            else:
                age_days = 0
            cutoff = int((datetime.now(timezone.utc) - timedelta(days=age_days)).timestamp() * 1000)
            if int(message.get("internalDate", 0)) >= cutoff:
                return False
        return True

    def list(self, **kwargs):
        query = kwargs.get("q", "")
        matched = [m for m in self.data.values() if self._matches(m, query)]
        start = int(kwargs.get("pageToken", "0"))
        maximum = int(kwargs.get("maxResults", 100))
        page = matched[start : start + maximum]
        result = {
            "messages": [{"id": m["id"]} for m in page],
            "resultSizeEstimate": len(matched),
        }
        if start + maximum < len(matched):
            result["nextPageToken"] = str(start + maximum)
        return FakeRequest(lambda: result)

    def get(self, **kwargs):
        message_id = kwargs["id"]
        return FakeRequest(lambda: json.loads(json.dumps(self.data[message_id])))

    def batchModify(self, **kwargs):
        body = kwargs["body"]

        def run():
            self.writes.append(list(body["ids"]))
            for message_id in body["ids"]:
                labels = set(self.data[message_id].get("labelIds", []))
                labels.update(body.get("addLabelIds", []))
                labels.difference_update(body.get("removeLabelIds", []))
                self.data[message_id]["labelIds"] = list(labels)
            return {}

        return FakeRequest(run)

    def batchDelete(self, **kwargs):
        ids = list(kwargs["body"]["ids"])

        def run():
            self.deletes.append(ids)
            for message_id in ids:
                self.data.pop(message_id, None)
            return {}

        return FakeRequest(run)


class FakeUsers:
    def __init__(self, messages, email):
        self._messages = messages
        self.email = email

    def messages(self):
        return self._messages

    def getProfile(self, **kwargs):
        return FakeRequest(lambda: {"emailAddress": self.email, "messagesTotal": len(self._messages.data)})


class FakeGmail:
    def __init__(self, messages, email="one@example.com"):
        self.messages_api = FakeMessages(messages)
        self.users_api = FakeUsers(self.messages_api, email)

    def users(self):
        return self.users_api


class FakeAbout:
    def get(self, **kwargs):
        return FakeRequest(
            lambda: {
                "storageQuota": {
                    "usage": str(12 * 1024**3),
                    "limit": str(15 * 1024**3),
                    "usageInDrive": str(4 * 1024**3),
                    "usageInDriveTrash": str(512 * 1024**2),
                }
            }
        )


class FakeDrive:
    def about(self):
        return FakeAbout()


def message(message_id, labels=None, days_old=40, size=1024):
    return {
        "id": str(message_id),
        "threadId": "thread-" + str(message_id),
        "snippet": "Newsletter notification summary",
        "labelIds": labels or ["CATEGORY_PROMOTIONS", "INBOX"],
        "internalDate": str(int((datetime.now(timezone.utc) - timedelta(days=days_old)).timestamp() * 1000)),
        "sizeEstimate": size,
        "payload": {
            "headers": [
                {"name": "Subject", "value": f"Subject {message_id}"},
                {"name": "From", "value": "newsletter@example.com"},
            ]
        },
    }


class SystemTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        self.account_patch = patch.multiple(
            store,
            ACCOUNTS_FILE=root / "accounts.json",
            TOKEN_DIR=root / "tokens",
        )
        self.account_patch.start()
        self.addCleanup(self.account_patch.stop)
        self.activity_patch = patch.object(web, "ACTIVITY_FILE", root / "activity.jsonl")
        self.activity_patch.start()
        self.addCleanup(self.activity_patch.stop)

    def register(self, email="one@example.com", settings=None):
        return store.upsert_account(email, settings=settings or {})

    def services(self, gmail):
        return patch.object(cleaner, "services_for", return_value=(gmail, FakeDrive()))

    def test_multiple_accounts_stay_separate(self):
        self.register("one@example.com", {"min_age_days": 7})
        self.register("two@example.com", {"min_age_days": 30})
        rows = store.list_accounts()
        self.assertEqual([r["email"] for r in rows], ["one@example.com", "two@example.com"])
        self.assertEqual(rows[0]["settings"]["min_age_days"], 7)
        self.assertEqual(rows[1]["settings"]["min_age_days"], 30)
        self.assertNotEqual(store.token_path(rows[0]["email"]), store.token_path(rows[1]["email"]))

    def test_cleanup_query_cleans_all_promotions_social_only(self):
        query = cleaner.cleanup_query(
            {"min_age_days": 7, "protect_starred": True, "protect_important": True}
        )
        self.assertIn("{category:promotions category:social}", query)
        # Full category clean intentionally ignores age and Starred/Important
        # preferences, while still excluding non-target system folders.
        self.assertNotIn("older_than:", query)
        self.assertNotIn("-is:starred", query)
        self.assertNotIn("-is:important", query)
        self.assertIn("-in:trash", query)
        self.assertIn("-in:spam", query)
        self.assertIn("-in:sent", query)
        self.assertIn("-in:drafts", query)

    def test_batch_cleanup_205_messages_uses_three_writes(self):
        self.register()
        gmail = FakeGmail([message(i) for i in range(205)])
        with self.services(gmail):
            result = cleaner.clean_promotions_social("one@example.com")
        self.assertEqual(result["moved"], 205)
        self.assertEqual(len(gmail.messages_api.writes), 3)
        self.assertTrue(
            all("TRASH" in m["labelIds"] and "INBOX" not in m["labelIds"] for m in gmail.messages_api.data.values())
        )

    def test_all_category_messages_cleaned_but_unrelated_and_sent_are_not(self):
        self.register()
        data = [
            message("star", ["CATEGORY_PROMOTIONS", "STARRED", "INBOX"]),
            message("important", ["CATEGORY_SOCIAL", "IMPORTANT", "INBOX"]),
            message("primary", ["CATEGORY_PERSONAL", "INBOX"]),
            message("sent", ["CATEGORY_SOCIAL", "SENT"]),
            message("eligible", ["CATEGORY_SOCIAL", "INBOX"]),
        ]
        gmail = FakeGmail(data)
        with self.services(gmail):
            result = cleaner.clean_promotions_social("one@example.com")
        self.assertEqual(result["moved"], 3)
        self.assertIn("TRASH", gmail.messages_api.data["eligible"]["labelIds"])
        self.assertIn("TRASH", gmail.messages_api.data["star"]["labelIds"])
        self.assertIn("TRASH", gmail.messages_api.data["important"]["labelIds"])
        self.assertNotIn("TRASH", gmail.messages_api.data["primary"]["labelIds"])
        self.assertNotIn("TRASH", gmail.messages_api.data["sent"]["labelIds"])

    def test_business_mail_guard_does_not_reduce_full_category_clean(self):
        self.register(settings={"min_age_days": 0, "business_guard_enabled": True})
        lead = message("lead", ["CATEGORY_PROMOTIONS", "INBOX", "UNREAD"])
        lead["payload"]["headers"][0]["value"] = "Need price for pH meter"
        lead["payload"]["headers"][1]["value"] = "newcustomer@gmail.com"
        lead["snippet"] = "Please quote your best price and availability"
        gmail = FakeGmail([lead, message("newsletter", ["CATEGORY_PROMOTIONS", "INBOX"])])
        with self.services(gmail):
            result = cleaner.clean_promotions_social("one@example.com")
        self.assertEqual(result["moved"], 2)
        self.assertEqual(result["protected"], 0)
        self.assertFalse(result["guard_applied"])
        self.assertIn("TRASH", gmail.messages_api.data["lead"]["labelIds"])
        self.assertIn("TRASH", gmail.messages_api.data["newsletter"]["labelIds"])

    def test_business_mail_guard_can_be_manually_disabled(self):
        self.register(settings={"min_age_days": 0, "business_guard_enabled": False})
        lead = message("lead-off", ["CATEGORY_PROMOTIONS", "INBOX", "UNREAD"])
        lead["payload"]["headers"][0]["value"] = "Need price for pH meter"
        lead["snippet"] = "Please quote your best price"
        gmail = FakeGmail([lead])
        with self.services(gmail):
            result = cleaner.clean_promotions_social("one@example.com")
        self.assertEqual(result["moved"], 1)
        self.assertFalse(result["guard_enabled"])
        self.assertIn("TRASH", gmail.messages_api.data["lead-off"]["labelIds"])

    def test_classifier_sends_unknown_promotion_to_review(self):
        msg = message("unknown", ["CATEGORY_PROMOTIONS", "INBOX"])
        msg["payload"]["headers"][0]["value"] = "Hello"
        msg["payload"]["headers"][1]["value"] = "person@example.com"
        msg["snippet"] = "Just checking in"
        decision = cleaner.classify_message(msg)
        self.assertEqual(decision["state"], "REVIEW")

    def test_full_category_clean_includes_new_and_old_messages(self):
        self.register(settings={"min_age_days": 7})
        gmail = FakeGmail([message("new", days_old=1), message("old", days_old=8)])
        with self.services(gmail):
            result = cleaner.clean_promotions_social("one@example.com")
        self.assertEqual(result["moved"], 2)
        self.assertIn("TRASH", gmail.messages_api.data["new"]["labelIds"])
        self.assertIn("TRASH", gmail.messages_api.data["old"]["labelIds"])

    def test_scan_reports_storage_and_opportunities(self):
        self.register()
        gmail = FakeGmail(
            [
                message("promo"),
                message("social", ["CATEGORY_SOCIAL", "INBOX"]),
                message("trash", ["TRASH"], size=3 * 1024**2),
                message("spam", ["SPAM"]),
                message("large", ["CATEGORY_PERSONAL", "INBOX"], size=11 * 1024**2),
                message("oldlarge", ["CATEGORY_PERSONAL", "INBOX"], days_old=800, size=6 * 1024**2),
            ]
        )
        with self.services(gmail):
            stats = cleaner.scan_account("one@example.com")
        self.assertEqual(stats["counts"]["promotions"], 1)
        self.assertEqual(stats["counts"]["social"], 1)
        self.assertEqual(stats["counts"]["trash"], 1)
        self.assertNotIn("spam", stats["counts"])
        self.assertEqual(stats["storage"]["usage_bytes"], 12 * 1024**3)
        self.assertEqual(stats["storage"]["drive_trash_bytes"], 512 * 1024**2)
        self.assertEqual(stats["storage"]["other_services_bytes"], 8 * 1024**3)

    def test_wrong_permanent_phrase_deletes_nothing(self):
        self.register()
        gmail = FakeGmail([message("trash", ["TRASH"])])
        with self.services(gmail):
            with self.assertRaisesRegex(ValueError, "did not match"):
                cleaner.permanently_delete("one@example.com", "trash", "DELETE")
        self.assertEqual(gmail.messages_api.deletes, [])

    def test_permanent_delete_revalidates_folder(self):
        self.register()
        gmail = FakeGmail(
            [
                message("trash", ["TRASH"]),
                message("inbox", ["CATEGORY_PERSONAL", "INBOX"]),
            ]
        )
        with self.services(gmail):
            result = cleaner.permanently_delete(
                "one@example.com",
                "trash",
                cleaner.permanent_phrase("one@example.com"),
                selected_ids=["trash", "inbox"],
            )
        self.assertEqual(result["deleted"], 1)
        self.assertNotIn("trash", gmail.messages_api.data)
        self.assertIn("inbox", gmail.messages_api.data)

    def test_auto_purge_query_is_age_limited(self):
        self.register()
        gmail = FakeGmail(
            [
                message("recent", ["TRASH"], days_old=2),
                message("old", ["TRASH"], days_old=31),
            ]
        )
        with self.services(gmail):
            result = cleaner.permanently_delete(
                "one@example.com",
                "trash",
                cleaner.permanent_phrase("one@example.com"),
                older_than_days=30,
            )
        self.assertEqual(result["deleted"], 1)
        self.assertIn("recent", gmail.messages_api.data)
        self.assertNotIn("old", gmail.messages_api.data)

    def test_move_selected_is_recoverable_and_rejects_trash(self):
        self.register()
        gmail = FakeGmail(
            [message("inbox", ["CATEGORY_PERSONAL", "INBOX"]), message("trash", ["TRASH"])]
        )
        with self.services(gmail):
            result = cleaner.move_selected_to_trash("one@example.com", ["inbox", "trash"])
        self.assertEqual(result, {"moved": 1, "skipped": 1})
        self.assertIn("TRASH", gmail.messages_api.data["inbox"]["labelIds"])

    def test_manual_not_spam_restores_only_selected_spam(self):
        self.register()
        gmail = FakeGmail(
            [message("lead", ["SPAM"]), message("ordinary", ["CATEGORY_PERSONAL", "INBOX"])]
        )
        with self.services(gmail):
            result = cleaner.mark_selected_not_spam(
                "one@example.com", ["lead", "ordinary"]
            )
        self.assertEqual(result, {"restored": 1, "skipped": 1})
        self.assertIn("INBOX", gmail.messages_api.data["lead"]["labelIds"])
        self.assertNotIn("SPAM", gmail.messages_api.data["lead"]["labelIds"])
        self.assertIn("INBOX", gmail.messages_api.data["ordinary"]["labelIds"])

    def test_spam_is_excluded_from_automatic_cleanup(self):
        self.register(settings={"min_age_days": 0, "protect_important": False})
        gmail = FakeGmail(
            [
                message("spam-lead", ["CATEGORY_PROMOTIONS", "SPAM"]),
                message("promo", ["CATEGORY_PROMOTIONS", "INBOX"]),
            ]
        )
        with self.services(gmail):
            result = cleaner.clean_promotions_social("one@example.com")
        self.assertEqual(result["moved"], 1)
        self.assertIn("SPAM", gmail.messages_api.data["spam-lead"]["labelIds"])
        self.assertNotIn("TRASH", gmail.messages_api.data["spam-lead"]["labelIds"])

    def test_one_click_setup_automates_only_safe_local_steps(self):
        root = Path(__file__).resolve().parents[1]
        batch = (root / "ONE_CLICK_START.bat").read_text(encoding="utf-8")
        script = (root / "launcher" / "Smart-Setup.ps1").read_text(encoding="utf-8")
        legacy = (root / "SETUP_AND_START.bat").read_text(encoding="utf-8")
        self.assertIn("Smart-Setup.ps1", batch)
        self.assertIn("ONE_CLICK_START.bat", legacy)
        self.assertIn("Python.Python.3.12", script)
        self.assertIn("Test-DesktopOAuthJson", script)
        self.assertIn("client_secret|credentials", script)
        self.assertIn('Name -notmatch "\\.example\\."', script)
        self.assertIn("-m unittest discover", script)
        self.assertIn("add_account.py", script)
        self.assertNotIn("batchDelete", script)
        self.assertNotIn("PERMANENTLY DELETE", script)

    def test_account_lock_blocks_overlap(self):
        self.register()
        lock = cleaner._account_lock("one@example.com")
        lock.acquire()
        try:
            result = cleaner.clean_promotions_social("one@example.com")
        finally:
            lock.release()
        self.assertEqual(result["status"], "SKIPPED")

    def test_scheduler_due_logic(self):
        account = {
            "settings": {"enabled": True, "every_hours": 6},
            "last_cleanup": (datetime.now(timezone.utc) - timedelta(hours=7)).isoformat(),
        }
        self.assertTrue(scheduler.is_due(account))
        account["last_cleanup"] = datetime.now(timezone.utc).isoformat()
        self.assertFalse(scheduler.is_due(account))
        account["settings"]["enabled"] = False
        self.assertFalse(scheduler.is_due(account))

    def test_scheduler_end_of_day_due_once_per_day(self):
        ist = timezone(timedelta(hours=5, minutes=30))
        account = {
            "settings": {
                "enabled": True,
                "schedule_mode": "end_of_day",
                "end_of_day_time": "23:00",
            }
        }
        self.assertFalse(scheduler.is_due(account, datetime(2026, 9, 16, 22, 59, tzinfo=ist)))
        self.assertTrue(scheduler.is_due(account, datetime(2026, 9, 16, 23, 0, tzinfo=ist)))
        account["last_eod_run_date"] = "2026-09-16"
        self.assertFalse(scheduler.is_due(account, datetime(2026, 9, 16, 23, 30, tzinfo=ist)))
        account["last_eod_run_date"] = "2026-09-15"
        account["last_eod_attempt_at"] = "2026-09-16T17:35:00+00:00"
        self.assertFalse(scheduler.is_due(account, datetime(2026, 9, 16, 23, 20, tzinfo=ist)))
        self.assertTrue(scheduler.is_due(account, datetime(2026, 9, 16, 23, 40, tzinfo=ist)))

    def test_web_csrf_blocks_untrusted_post(self):
        app = web.create_app(scheduler.CleanupScheduler())
        app.config.update(TESTING=True)
        client = app.test_client()
        response = client.post("/api/accounts/scan", json={"email": "one@example.com"})
        self.assertEqual(response.status_code, 403)

    def test_web_state_hides_permanent_confirmation(self):
        self.register()
        store.upsert_account(
            "one@example.com",
            auto_purge_confirmation=cleaner.permanent_phrase("one@example.com"),
        )
        app = web.create_app(scheduler.CleanupScheduler())
        app.config.update(TESTING=True)
        client = app.test_client()
        data = client.get("/api/state").get_json()
        self.assertTrue(data["ok"])
        self.assertNotIn("auto_purge_confirmation", data["accounts"][0])

    def test_client_reconnect_refreshes_token_preserves_settings(self):
        self.register("one@example.com")
        root = Path(self.temp.name)
        key = "a" * 64
        (root / "network.key").write_text(key, encoding="ascii")
        token = {"token": "test", "refresh_token": "refresh", "token_uri": "https://oauth2.googleapis.com/token", "client_id": "id", "client_secret": "secret"}
        cipher_key = base64.urlsafe_b64encode(hashlib.sha256(key.encode("ascii")).digest())
        encrypted = Fernet(cipher_key).encrypt(json.dumps(token).encode()).decode()
        with patch.object(web, "NETWORK_ACCESS_KEY_FILE", root / "network.key"), patch.object(web, "SESSION_SECRET_FILE", root / "session.key"), patch("google.oauth2.credentials.Credentials.from_authorized_user_info"), patch("googleapiclient.discovery.build", return_value=FakeGmail([], "one@example.com")), patch.object(web, "save_token") as save:
            app = web.create_app(scheduler.CleanupScheduler())
            app.config.update(TESTING=True)
            response = app.test_client().post(
                "/api/client/register",
                headers={"X-GmCL-Access-Key": key},
                json={"encrypted_token": encrypted},
                environ_base={"REMOTE_ADDR": "192.168.1.50"},
            )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()["status"], "reconnected")
        self.assertTrue(response.get_json()["account_access"])
        save.assert_called_once()
        self.assertEqual(store.get_account("one@example.com")["settings"]["min_age_days"], 7)

    def test_client_ping_requires_key_and_confirms_service(self):
        root = Path(self.temp.name)
        key = "b" * 64
        (root / "network.key").write_text(key, encoding="ascii")
        with patch.object(web, "NETWORK_ACCESS_KEY_FILE", root / "network.key"), patch.object(web, "SESSION_SECRET_FILE", root / "session.key"):
            app = web.create_app(scheduler.CleanupScheduler())
            app.config.update(TESTING=True)
            client = app.test_client()
            denied = client.get("/api/client/ping", environ_base={"REMOTE_ADDR": "192.168.1.50"})
            accepted = client.get("/api/client/ping", headers={"X-GmCL-Access-Key": key}, environ_base={"REMOTE_ADDR": "192.168.1.50"})
        self.assertEqual(denied.status_code, 403)
        self.assertEqual(accepted.status_code, 200)
        self.assertEqual(accepted.get_json()["service"], "GmCL")

    def test_saved_client_access_refreshes_without_google_relogin(self):
        root = Path(__file__).resolve().parents[1]
        connector = (root / "launcher" / "client_connect.py").read_text(encoding="utf-8")
        web_source = (root / "app" / "web.py").read_text(encoding="utf-8")
        # Browser grants remain temporary, while a separate signed saved-client
        # token refreshes them automatically without repeating Google OAuth.
        self.assertIn("signer.loads(dashboard_token, max_age=30 * 86400)", web_source)
        self.assertIn("/api/client/resume", web_source)
        self.assertIn("resume_signer", web_source)
        self.assertIn("/api/client/resume", connector)
        self.assertIn("resume_token", connector)
        self.assertIn('"GmCL" / "ClientState"', connector)

    def test_windows_server_state_uses_localappdata(self):
        root = Path(__file__).resolve().parents[1]
        config_source = (root / "app" / "config.py").read_text(encoding="utf-8")
        self.assertIn('Path(local_app_data) / "GmCL" / "ServerData"', config_source)
        self.assertIn("_migrate_legacy_state()", config_source)

    def test_oauth_client_is_persisted_outside_zip(self):
        root = Path(__file__).resolve().parents[1]
        config_source = (root / "app" / "config.py").read_text(encoding="utf-8")
        setup = (root / "launcher" / "Smart-Setup.ps1").read_text(encoding="utf-8")
        generator = (root / "launcher" / "Create-Client-Links.ps1").read_text(encoding="utf-8")
        self.assertIn('PERSISTENT_CLIENT_SECRET = PERSISTENT_OAUTH_DIR / "client_secret.json"', config_source)
        self.assertIn(r'Join-Path $DataDir "oauth\client_secret.json"', setup)
        self.assertIn('Saved Google Desktop OAuth file restored from LocalAppData', setup)
        self.assertIn('$persistentOauth', generator)

    def test_client_uses_normal_default_browser_and_does_not_reauth_on_transient_resume_error(self):
        root = Path(__file__).resolve().parents[1]
        connector = (root / "launcher" / "client_connect.py").read_text(encoding="utf-8")
        self.assertNotIn("browser=preferred_browser()", connector)
        self.assertIn('oauth_prompt = "consent" if "--connect" in sys.argv else "select_account"', connector)
        self.assertIn("A temporary server problem must never force the user through", connector)
        self.assertIn("Could not restore the saved GmCL login", connector)

    def test_repeat_authorization_keeps_saved_refresh_token(self):
        root = Path(__file__).resolve().parents[1]
        server_source = (root / "app" / "web.py").read_text(encoding="utf-8")
        add_source = (root / "add_account.py").read_text(encoding="utf-8")
        self.assertIn('old_token.get("refresh_token")', server_source)
        self.assertIn('token_value["refresh_token"] = old_token["refresh_token"]', server_source)
        self.assertIn("_merge_saved_refresh_token", add_source)
        self.assertIn("previously saved refresh token", add_source)

    def test_client_package_has_automatic_connection_recovery(self):
        root = Path(__file__).resolve().parents[1]
        connector = (root / "launcher" / "client_connect.py").read_text(encoding="utf-8")
        generator = (root / "launcher" / "Create-Client-Links.ps1").read_text(encoding="utf-8")
        client_batch = (root / "launcher" / "CLIENT_CONNECT_GMAIL.bat").read_text(encoding="utf-8")
        self.assertIn("discover_server", connector)
        self.assertIn("/api/client/ping", connector)
        self.assertIn("preferred_browser", connector)
        self.assertIn("server_candidates", generator)
        self.assertIn("8795", generator)
        self.assertIn("Client-Setup.ps1", client_batch)

    def test_settings_enables_automatic_purge_without_browser_confirmation(self):
        self.register()
        app = web.create_app(scheduler.CleanupScheduler())
        app.config.update(TESTING=True)
        client = app.test_client()
        csrf = client.get("/api/state").get_json()["csrf"]
        response = client.post(
            "/api/accounts/settings",
            headers={"X-CSRF-Token": csrf},
            json={
                "email": "one@example.com",
                "auto_purge_trash": True,
                "trash_age_days": 45,
            },
        )
        self.assertEqual(response.status_code, 200)
        account = store.get_account("one@example.com")
        self.assertTrue(account["settings"]["auto_purge_trash"])
        self.assertEqual(account["settings"]["trash_age_days"], 45)
        self.assertEqual(
            account["auto_purge_confirmation"],
            cleaner.permanent_phrase("one@example.com"),
        )

    def test_cleanup_ui_has_no_permanent_delete_or_clean_confirmation_popup(self):
        root = Path(__file__).resolve().parents[1]
        script = (root / "app" / "static" / "app.js").read_text(encoding="utf-8")
        self.assertNotIn("PERMANENTLY DELETE", script)
        self.assertNotIn("Move matching Promotions and Social messages", script)
        self.assertNotIn("Move \" + chosen.length + \" selected message", script)

    def test_candidate_preview_is_capped_and_marks_permanent_folders(self):
        self.register()
        gmail = FakeGmail([message(i, ["TRASH"]) for i in range(130)])
        with self.services(gmail):
            result = cleaner.list_candidates("one@example.com", "trash", limit=500)
        self.assertTrue(result["permanent"])
        self.assertEqual(result["shown"], 100)
        self.assertEqual(result["estimate"], 130)

    def test_remove_account_deletes_only_local_token_and_record(self):
        self.register()
        store.save_token("one@example.com", '{"refresh_token":"fake"}')
        self.assertTrue(store.token_path("one@example.com").exists())
        self.assertTrue(store.remove_account("one@example.com"))
        self.assertFalse(store.token_path("one@example.com").exists())
        self.assertIsNone(store.get_account("one@example.com"))


if __name__ == "__main__":
    unittest.main()
